#pragma once

#include "rtwtypes.h"
#include "emlrt.h"
#include "mex.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>

void calc_rice_k_wrapper_fixpt_hdl_mex_atexit();

void calc_rice_k_wrapper_fixpt_hdl_mex_terminate();
