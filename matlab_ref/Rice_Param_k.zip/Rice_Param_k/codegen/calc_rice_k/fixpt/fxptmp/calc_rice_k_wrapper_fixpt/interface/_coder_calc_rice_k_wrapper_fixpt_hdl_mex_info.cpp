#include "_coder_calc_rice_k_wrapper_fixpt_hdl_mex_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

static const mxArray *c_emlrtMexFcnResolvedFunctionsI();

static const mxArray *c_emlrtMexFcnResolvedFunctionsI()
{
  const mxArray *nameCaptureInfo;
  const char_T *data[8]{
      "789ced59bf53134114de84808022a171624769c53940913604709420c1640487718ef3b2"
      "0947eed7dc2518a8f80fb4b4b4a4b4b4b4a4b474c6f13fb17093dc0b"
      "97471e77121231dc9bd9ecbdfb76dff7deeededb9d2c8b3ddf8c31c61eb2b63452ed7ac6"
      "d3935e1d67dd82f1985727900e32ee213308ffe0d5aa65d678a3d656",
      "4cc5e09d9e9a69d76bc5639bbb4271b86be947bcd442ca9ace8b9ac10b7ee5655333d67d"
      "50476942cde7ec0157ab85bac19c03f7c243ddaf74c6639f8837c1ba"
      "05e358f078e076c0777a4d3eb0ff38800f7055d155d9d1542e57e5f78e62dbdc91cb5ac3"
      "ae217f7e107c73c83ee68b791e6f66b70a6d7da2a5bb3547332bbef5",
      "46d8079d11f804e2c5fc80a72e5efd8a7bedfc05fc382778c28ebb4af89144f8deda5b69"
      "3353cc6556e6571ded884bab4a4dce5a862daf725554d2abe69ce415"
      "4731e4aaa45a255ee1a6e49b2da9354b12397f0b468b2768fdce868c8b1adf1936d9aa57"
      "7efe3e1c261fc85de1a3be8fb0ebf211c19744787939bdf4e664a99e",
      "2de8ae99b1dd6df7452ebf72e1473e8027c80f46e8c3b23faadf77bfeb630ee9382ec0fd"
      "fedca57d029ec18f6f044fd8f1de23fc48227c10eb28da1f468f6f58"
      "fb435559dcd856d69cba5d3cc9d75f97adad4c213742fbc33ed17f50e7fc7ee72d8574cc"
      "07f8a5ef5fd6ad4a853ba39eb7c75877defe4ef0841d6f8df02389f0",
      "9bcadb65f1235a53d3e765f1e1e51d3dcae303e51b561ecf6ce8b5869a5b3ccc2c2feeac"
      "95d6cb87eeb34236cae358a23c7e3bf278824579bc29511eff3ff8a2"
      "3c7e33f6cfa77bf79f0a69ff60bab7fd38c219baff484ff5b61bf6fe835a2f70ff318570"
      "d021ff82803f6793bdf9fe3eaf77db69de83ec78ff2bc93ebe34c117",
      "34af382e6a5e3fc5aeee4fd94fc7aeb61f47ed12debbb428bba27c162525b0795f79228a"
      "621e77f63a4af0dc033f14ace382ef1dc668aaaeb8a8e738f17e8c78"
      "8f730fe67bea6bfc10e1a07ff1eaebe6d169a4e3f67984c7091dce0bf7bcbac42c5667ef"
      "98ceb82816ab881d5c658a78eef6ff6b9ffedf0ff07f37a4ff6007fc",
      "e7cc10de731147a9f5bbc0ca2282cb91049df3c2c6318b74dcbe81701c07ac311c07e861"
      "e2e9dd8675c579da679cd43d34b49f0f8813a4b3df11792b282f62bb"
      "947d3ba03f653f683f857de7b6f3ef13f61f04f0078def38714e8be673b0fc93d7dce7c1"
      "de19613f8e707c7efb48d8fd57e737903f1ddea637",
      ""};
  nameCaptureInfo = nullptr;
  emlrtNameCaptureMxArrayR2016a(&data[0], 9064U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties()
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *epFieldName[7]{
      "QualifiedName",    "NumberOfInputs", "NumberOfOutputs", "ConstantInputs",
      "ResolvedFilePath", "TimeStamp",      "Visible"};
  const char_T *propFieldName[7]{
      "Version",      "ResolvedFunctions", "Checksum", "EntryPoints",
      "CoverageInfo", "IsPolymorphic",     "AuxData"};
  uint8_T v[216]{
      0U,   1U,   73U,  77U,  0U,   0U,   0U,   0U,   14U,  0U,   0U,   0U,
      200U, 0U,   0U,   0U,   6U,   0U,   0U,   0U,   8U,   0U,   0U,   0U,
      2U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,   5U,   0U,   0U,   0U,
      8U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,
      1U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,   5U,   0U,   4U,   0U,
      17U,  0U,   0U,   0U,   1U,   0U,   0U,   0U,   17U,  0U,   0U,   0U,
      67U,  108U, 97U,  115U, 115U, 69U,  110U, 116U, 114U, 121U, 80U,  111U,
      105U, 110U, 116U, 115U, 0U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,
      14U,  0U,   0U,   0U,   112U, 0U,   0U,   0U,   6U,   0U,   0U,   0U,
      8U,   0U,   0U,   0U,   2U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,
      5U,   0U,   0U,   0U,   8U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,
      0U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,
      5U,   0U,   4U,   0U,   14U,  0U,   0U,   0U,   1U,   0U,   0U,   0U,
      56U,  0U,   0U,   0U,   81U,  117U, 97U,  108U, 105U, 102U, 105U, 101U,
      100U, 78U,  97U,  109U, 101U, 0U,   77U,  101U, 116U, 104U, 111U, 100U,
      115U, 0U,   0U,   0U,   0U,   0U,   0U,   0U,   80U,  114U, 111U, 112U,
      101U, 114U, 116U, 105U, 101U, 115U, 0U,   0U,   0U,   0U,   72U,  97U,
      110U, 100U, 108U, 101U, 0U,   0U,   0U,   0U,   0U,   0U,   0U,   0U};
  xEntryPoints =
      emlrtCreateStructMatrix(1, 2, 7, (const char_T **)&epFieldName[0]);
  xInputs = emlrtCreateLogicalMatrix(1, 2);
  emlrtSetField(xEntryPoints, 0, "QualifiedName",
                emlrtMxCreateString("calc_rice_k_wrapper_fixpt"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(2.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 0, "ResolvedFilePath",
      emlrtMxCreateString("/MATLAB "
                          "Drive/Dat_Comp_Decomp/Rice_Param_k/codegen/"
                          "calc_rice_k/fixpt/calc_rice_k_wrapper_fixpt.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp",
                emlrtMxCreateDoubleScalar(740303.954837963));
  emlrtSetField(xEntryPoints, 0, "Visible", emlrtMxCreateLogicalScalar(true));
  xInputs = emlrtCreateLogicalMatrix(1, 0);
  emlrtSetField(xEntryPoints, 1, "QualifiedName",
                emlrtMxCreateString("calc_rice_k_fixpt_logger"));
  emlrtSetField(xEntryPoints, 1, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 1, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 1, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 1, "ResolvedFilePath",
                emlrtMxCreateString(
                    "/MATLAB "
                    "Drive/Dat_Comp_Decomp/Rice_Param_k/codegen/calc_rice_k/"
                    "fixpt/fxptmp/calc_rice_k_fixpt_logger.m"));
  emlrtSetField(xEntryPoints, 1, "TimeStamp",
                emlrtMxCreateDoubleScalar(740303.955324074));
  emlrtSetField(xEntryPoints, 1, "Visible", emlrtMxCreateLogicalScalar(true));
  xResult =
      emlrtCreateStructMatrix(1, 1, 7, (const char_T **)&propFieldName[0]);
  emlrtSetField(xResult, 0, "Version",
                emlrtMxCreateString("26.2.0.3468271 (R2026b) Update 2"));
  emlrtSetField(xResult, 0, "ResolvedFunctions",
                (mxArray *)c_emlrtMexFcnResolvedFunctionsI());
  emlrtSetField(xResult, 0, "Checksum",
                emlrtMxCreateString("eu1n1TivdYnnP8BdREYPrD"));
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  emlrtSetField(xResult, 0, "AuxData",
                emlrtMxCreateRowVectorUINT8((const uint8_T *)&v, 216U));
  return xResult;
}
