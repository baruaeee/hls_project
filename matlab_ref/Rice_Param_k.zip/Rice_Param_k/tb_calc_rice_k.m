% tb_calc_rice_k.m
% Testbench for calc_rice_k.m using unsigned_residuals.txt as stimulus.

clear; clc;

% 1. Load Unsigned Residuals from Step 3
filename = 'unsigned_residuals.txt';
if ~isfile(filename)
    error('Cannot find %s in the current folder.', filename);
end

u_vals = double(load(filename));
num_samples = length(u_vals);
k_vals = zeros(num_samples, 1);

% 2. Stream Unsigned Values through Adaptive k Estimator
for n = 1:num_samples
    rst = (n == 1);
    k_vals(n) = calc_rice_k(u_vals(n), rst);
end

% 3. Save Dynamic k Values for Step 5 (Quotient & Remainder Split)
out_filename = 'rice_k_values.txt';
fid = fopen(out_filename, 'w');
fprintf(fid, '%d\n', k_vals);
fclose(fid);

% 4. Evaluate Compression Efficiency: Adaptive k vs. Fixed k
% Golomb-Rice bit length for value u with parameter k is: floor(u / 2^k) + 1 + k
adaptive_bits = sum(floor(u_vals ./ (2 .^ k_vals)) + 1 + k_vals);
fixed_k0_bits = sum(floor(u_vals ./ (2 ^ 0)) + 1 + 0);
fixed_k4_bits = sum(floor(u_vals ./ (2 ^ 4)) + 1 + 4);
raw_12bit_total = num_samples * 12;

fprintf('=== Dynamic Rice Parameter (k) Verification ===\n');
fprintf('Total Samples Processed      : %d\n', num_samples);
fprintf('Selected k Range             : [%d, %d] (Mean k = %.2f)\n', min(k_vals), max(k_vals), mean(k_vals));
fprintf('Uncompressed (12-bit fixed)  : %d bits\n', raw_12bit_total);
fprintf('Compressed (Fixed k = 0)     : %d bits\n', fixed_k0_bits);
fprintf('Compressed (Fixed k = 4)     : %d bits\n', fixed_k4_bits);
fprintf('Compressed (Adaptive k)      : %d bits (Ratio = %.2fx)\n', adaptive_bits, raw_12bit_total / adaptive_bits);
fprintf('Saved dynamic k stream to    : %s\n', out_filename);

% 5. Visual Verification Plot
figure('Name', 'Adaptive Rice Parameter k Tracking', 'Position', [100, 100, 850, 500]);

subplot(2,1,1);
plot(1:num_samples, u_vals, 'm-', 'LineWidth', 1.2);
title('Input: Unsigned Mapped Residuals u[n]');
xlabel('Sample Index [n]');
ylabel('u[n]');
grid on;

subplot(2,1,2);
stairs(1:num_samples, k_vals, 'k-', 'LineWidth', 1.5);
title('Output: Dynamically Adapted Rice Parameter k[n]');
xlabel('Sample Index [n]');
ylabel('Rice Parameter k');
ylim([-0.5, 8.5]);
grid on;