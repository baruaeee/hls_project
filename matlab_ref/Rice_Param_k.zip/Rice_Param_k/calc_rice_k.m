function k_out = calc_rice_k(u_in, reset)
% CALC_RICE_K Dynamically estimates optimal Golomb-Rice parameter k
% using a power-of-two moving window sum and priority encoder (no division/log2).
%
% Backward-adaptive: computes k from past 8 samples so the decoder can
% independently track the exact same k without side-channel overhead.

WIN_SIZE = 8;   % Must be power of 2 (2^3)
INV_WIN  = 1/8; % Bit-shift right by 3 in fixed-point
K_MAX    = 8;   % Upper bound on Rice parameter k

persistent u_hist win_sum;

u_val = double(u_in);

if isempty(u_hist) || reset
    % Initialize window with small default values (e.g., 4 -> initial k = 1)
    u_hist  = repmat(4, WIN_SIZE, 1);
    win_sum = 4 * WIN_SIZE;
end

% 1. Compute running mean of PAST window samples (shift right by 3)
avg_u = floor(win_sum * INV_WIN);

% 2. Priority Encoder: Select k such that 2^k <= avg_u < 2^(k+1)
% Synthesizes to a fast parallel comparator tree (0 DSPs, 1 cycle)
if avg_u >= 256
    k_out = 8;
elseif avg_u >= 128
    k_out = 7;
elseif avg_u >= 64
    k_out = 6;
elseif avg_u >= 32
    k_out = 5;
elseif avg_u >= 16
    k_out = 4;
elseif avg_u >= 8
    k_out = 3;
elseif avg_u >= 4
    k_out = 2;
elseif avg_u >= 2
    k_out = 1;
else
    k_out = 0;
end

% Clamp to K_MAX
if k_out > K_MAX
    k_out = K_MAX;
end

% 3. Update sliding window sum & shift register for NEXT sample
oldest  = u_hist(WIN_SIZE);
win_sum = win_sum + u_val - oldest;

coder.hdl.loopspec('unroll');
for i = WIN_SIZE:-1:2
    u_hist(i) = u_hist(i-1);
end
u_hist(1) = u_val;
end