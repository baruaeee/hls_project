function [q_out, r_out] = split_quotient_remainder(u_in, k_in)
% SPLIT_QUOTIENT_REMAINDER Zero-divider, zero-DSP Golomb-Rice splitter.
% Uses constant power-of-two scaling inside each switch branch so HDL Coder
% and Vitis HLS synthesize pure barrel-shifter & bit-masking multiplexers.

u_val = double(u_in);
k_val = double(k_in);

switch k_val
    case 0
        q_out = u_val;
        r_out = 0;
    case 1
        q_out = floor(u_val * 0.5);        % u >> 1
        r_out = u_val - (q_out * 2);       % u(0)
    case 2
        q_out = floor(u_val * 0.25);       % u >> 2
        r_out = u_val - (q_out * 4);       % u(1:0)
    case 3
        q_out = floor(u_val * 0.125);      % u >> 3
        r_out = u_val - (q_out * 8);       % u(2:0)
    case 4
        q_out = floor(u_val * 0.0625);     % u >> 4
        r_out = u_val - (q_out * 16);      % u(3:0)
    case 5
        q_out = floor(u_val * 0.03125);    % u >> 5
        r_out = u_val - (q_out * 32);      % u(4:0)
    case 6
        q_out = floor(u_val * 0.015625);   % u >> 6
        r_out = u_val - (q_out * 64);      % u(5:0)
    case 7
        q_out = floor(u_val * 0.0078125);  % u >> 7
        r_out = u_val - (q_out * 128);     % u(6:0)
    otherwise % k = 8
        q_out = floor(u_val * 0.00390625); % u >> 8
        r_out = u_val - (q_out * 256);     % u(7:0)
end
end