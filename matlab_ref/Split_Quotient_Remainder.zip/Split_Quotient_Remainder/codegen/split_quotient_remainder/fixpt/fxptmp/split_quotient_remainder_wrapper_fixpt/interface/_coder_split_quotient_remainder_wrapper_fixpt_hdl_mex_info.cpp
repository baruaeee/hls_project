#include "_coder_split_quotient_remainder_wrapper_fixpt_hdl_mex_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

static const mxArray *c_emlrtMexFcnResolvedFunctionsI();

static const mxArray *c_emlrtMexFcnResolvedFunctionsI()
{
  const mxArray *nameCaptureInfo;
  const char_T *data[8]{
      "789ced594b531341109e2c81220818cb2a0b2f16172d4f04c5c25c030902657805cba865"
      "6dd6641216b30f361b249ef486273c72f4c8cff0e84ff0e29da3472f"
      "56b949b6f368d3cc42205061bb6a32dbfbcdf6d73d3de9d96458602919608c8db3ba64ee"
      "d6fb31570fbbbdc4da05e301b70f221d64d045c6107ee0f65943b7f9",
      "9e5d577445e38d2755dd2cdb9b1593971cc5e225a3b8cb733524af16f9a6aaf154abb252"
      "d5b48516a8a154a1eaf5fc16cfbe4f9535666d959a1e165b95e67c10"
      "f10659bb601c0b9e0f3c0ef8f6cfc807f61f08f8002f9945d59677ca86ad72dd962dae29"
      "aa9ee396fcc1524cd3e9f3ea9e6937fdfa49f0de423c9837e07a9e9c",
      "5f4dd5f5a13abf6da97aa1697f8fb00f3a23f021c48bf9019f68defa25b9e35a1bf8f19b"
      "e0f13aff5f083fc2087f93781b49c6369fc7e626e396bacb2371c596"
      "e70dcd94e33ceb7491542d41eb90a00d4850246be47881eb112a83915ae648b83dc1539a"
      "eb8f68bddff4183f958731365cebd3a1bfdbbde403b92e7cd4f7c8eb",
      "fabd43f085116edbcb462ef66ae6f56ac59eae44f3db8bb38af1ace9c79a8047e40723f4"
      "5ed9bfee75e05397f1df13c40f38e9de35d97fe01afc382678bccefb"
      "67c28f30c22f6fddf9fb4e3ff2f56adf594826772a1bb1c7b1f89317734f556565f6632c"
      "df47fb4e8678feaafedeb82fe003fce47220178d42815bacffebfd00",
      "3bdfdf1b074867681ce0175eeff3ce8763c6539e9deadfab3a65fb75ff42f97a55f797d6"
      "135145d312dba5f423239a58b296d7e2cb7eddff4ffcba7f35eb7e90"
      "f975dfaffbfdc3e7d7fdf3b17f3cd2f9f99047fbfb239ded4b0867e89c271dea6cd7eb39"
      "0fb55ee09c278470d0a13e83803f3f863bf39dbeeeb7dba99ef7bc74",
      "ffe9925bf8d2049f28af382e2aaf8781939fa7ec470327db97d0b8a07b2feab4b4d3be39"
      "6dc2c1265bda43a7297aa5b1175282730ffcd0b08e1b3e5719a0a9da"
      "e2a2ae25e2fe00711fd71ecc37dd32781ce1a01fb9fd59eb285e1f78fc22c225421f427d"
      "8e19acccdeb122e36dd7e0f7f72efd1e15f89df1e8f70dd473a6399e",
      "567dced53ea7589ea9c4ddaa403c7fba8ce7b6209e43413cb096703cddc4779abba2ffe1"
      "bdce03751e0fe32705f300d2d80f89ba26aa9bd82e65df143c4fd917"
      "edb7b02f5d75fe0c617f94b5cb69e77790788ff3f379b1fcc3677c0f007b47480791108e"
      "dfefbe12762febfd0ee41fd11d1623",
      ""};
  nameCaptureInfo = nullptr;
  emlrtNameCaptureMxArrayR2016a(&data[0], 9328U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties()
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *epFieldName[7]{
      "QualifiedName",    "NumberOfInputs", "NumberOfOutputs", "ConstantInputs",
      "ResolvedFilePath", "TimeStamp",      "Visible"};
  const char_T *propFieldName[7]{
      "Version",      "ResolvedFunctions", "Checksum", "EntryPoints",
      "CoverageInfo", "IsPolymorphic",     "AuxData"};
  uint8_T v[216]{
      0U,   1U,   73U,  77U,  0U,   0U,   0U,   0U,   14U,  0U,   0U,   0U,
      200U, 0U,   0U,   0U,   6U,   0U,   0U,   0U,   8U,   0U,   0U,   0U,
      2U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,   5U,   0U,   0U,   0U,
      8U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,
      1U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,   5U,   0U,   4U,   0U,
      17U,  0U,   0U,   0U,   1U,   0U,   0U,   0U,   17U,  0U,   0U,   0U,
      67U,  108U, 97U,  115U, 115U, 69U,  110U, 116U, 114U, 121U, 80U,  111U,
      105U, 110U, 116U, 115U, 0U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,
      14U,  0U,   0U,   0U,   112U, 0U,   0U,   0U,   6U,   0U,   0U,   0U,
      8U,   0U,   0U,   0U,   2U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,
      5U,   0U,   0U,   0U,   8U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,
      0U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,
      5U,   0U,   4U,   0U,   14U,  0U,   0U,   0U,   1U,   0U,   0U,   0U,
      56U,  0U,   0U,   0U,   81U,  117U, 97U,  108U, 105U, 102U, 105U, 101U,
      100U, 78U,  97U,  109U, 101U, 0U,   77U,  101U, 116U, 104U, 111U, 100U,
      115U, 0U,   0U,   0U,   0U,   0U,   0U,   0U,   80U,  114U, 111U, 112U,
      101U, 114U, 116U, 105U, 101U, 115U, 0U,   0U,   0U,   0U,   72U,  97U,
      110U, 100U, 108U, 101U, 0U,   0U,   0U,   0U,   0U,   0U,   0U,   0U};
  xEntryPoints =
      emlrtCreateStructMatrix(1, 2, 7, (const char_T **)&epFieldName[0]);
  xInputs = emlrtCreateLogicalMatrix(1, 2);
  emlrtSetField(xEntryPoints, 0, "QualifiedName",
                emlrtMxCreateString("split_quotient_remainder_wrapper_fixpt"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(2.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(2.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 0, "ResolvedFilePath",
      emlrtMxCreateString(
          "/MATLAB "
          "Drive/Dat_Comp_Decomp/Split_Quotient_Remainder/codegen/"
          "split_quotient_remainder/fixpt/split_quotient_remainder_wrapper_f"
          "ixpt.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp",
                emlrtMxCreateDoubleScalar(740304.0913888889));
  emlrtSetField(xEntryPoints, 0, "Visible", emlrtMxCreateLogicalScalar(true));
  xInputs = emlrtCreateLogicalMatrix(1, 0);
  emlrtSetField(xEntryPoints, 1, "QualifiedName",
                emlrtMxCreateString("split_quotient_remainder_fixpt_logger"));
  emlrtSetField(xEntryPoints, 1, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 1, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 1, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 1, "ResolvedFilePath",
      emlrtMxCreateString(
          "/MATLAB "
          "Drive/Dat_Comp_Decomp/Split_Quotient_Remainder/codegen/"
          "split_quotient_remainder/fixpt/fxptmp/split_quotient_remainder_fi"
          "xpt_logger.m"));
  emlrtSetField(xEntryPoints, 1, "TimeStamp",
                emlrtMxCreateDoubleScalar(740304.091712963));
  emlrtSetField(xEntryPoints, 1, "Visible", emlrtMxCreateLogicalScalar(true));
  xResult =
      emlrtCreateStructMatrix(1, 1, 7, (const char_T **)&propFieldName[0]);
  emlrtSetField(xResult, 0, "Version",
                emlrtMxCreateString("26.2.0.3468271 (R2026b) Update 2"));
  emlrtSetField(xResult, 0, "ResolvedFunctions",
                (mxArray *)c_emlrtMexFcnResolvedFunctionsI());
  emlrtSetField(xResult, 0, "Checksum",
                emlrtMxCreateString("imDEY1obm6rLbRyb87HfV"));
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  emlrtSetField(xResult, 0, "AuxData",
                emlrtMxCreateRowVectorUINT8((const uint8_T *)&v, 216U));
  return xResult;
}
