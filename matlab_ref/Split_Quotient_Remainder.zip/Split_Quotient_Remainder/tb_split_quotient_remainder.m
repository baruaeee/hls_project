% tb_split_quotient_remainder.m
% Standalone testbench for split_quotient_remainder.m

clear; clc;

% 1. Load Testbench Stimulus Files from Steps 3 & 4
u_file = 'unsigned_residuals.txt';
k_file = 'rice_k_values.txt';

if ~isfile(u_file) || ~isfile(k_file)
    error('Missing %s or %s in current folder.', u_file, k_file);
end

u_vals = double(load(u_file));
k_vals = double(load(k_file));
num_samples = length(u_vals);

q_vals = zeros(num_samples, 1);
r_vals = zeros(num_samples, 1);

% 2. Stream Inputs through Hardware Module
for n = 1:num_samples
    [q_vals(n), r_vals(n)] = split_quotient_remainder(u_vals(n), k_vals(n));
end

% 3. Save [q, r, k] Vectors for Step 6 (Bitstream Encoder Unit Test)
out_filename = 'qr_data.txt';
fid = fopen(out_filename, 'w');
for n = 1:num_samples
    fprintf(fid, '%d %d %d\n', q_vals(n), r_vals(n), k_vals(n));
end
fclose(fid);

% 4. Lossless Reconstruction Check: u_rec = q * 2^k + r
u_reconstructed = (q_vals .* (2 .^ k_vals)) + r_vals;
max_err = max(abs(u_vals - u_reconstructed));

fprintf('=== Quotient & Remainder Split Verification ===\n');
fprintf('Total Samples Processed : %d\n', num_samples);
fprintf('Quotient (q) Range      : [%d, %d]\n', min(q_vals), max(q_vals));
fprintf('Remainder (r) Range     : [%d, %d]\n', min(r_vals), max(r_vals));
fprintf('Max Reconstruction Err  : %d (Must be 0)\n', max_err);
fprintf('Saved [q, r, k] data to : %s\n', out_filename);

if max_err ~= 0
    error('Verification failed: u ~= q * 2^k + r!');
end

% 5. Visual Plot
figure('Name', 'Golomb-Rice Quotient & Remainder Split', 'Position', [100, 100, 850, 550]);

subplot(3,1,1);
plot(1:num_samples, u_vals, 'm-', 'LineWidth', 1.2);
title('Input Unsigned Value u[n]');
ylabel('u[n]'); grid on;

subplot(3,1,2);
stem(1:num_samples, q_vals, 'b', 'MarkerSize', 3);
title('Quotient q[n] = floor(u / 2^k)  [Unary Coded]');
ylabel('q[n]'); grid on;

subplot(3,1,3);
stem(1:num_samples, r_vals, 'g', 'MarkerSize', 3);
title('Remainder r[n] = u mod 2^k  [k-bit Binary Coded]');
xlabel('Sample Index [n]'); ylabel('r[n]'); grid on;