% tb_signed_to_unsigned.m
% Testbench for signed_to_unsigned.m using residuals_data.txt as stimulus.

clear; clc;

% 1. Load Residuals Stimulus Data
filename = 'residuals_data.txt';
if ~isfile(filename)
    error('Cannot find %s in the current folder.', filename);
end

residuals = double(load(filename));
num_samples = length(residuals);

% Preallocate output
unsigned_vals = zeros(num_samples, 1);

% 2. Stream Residuals Sample-by-Sample through Hardware Module
for n = 1:num_samples
    unsigned_vals(n) = signed_to_unsigned(residuals(n));
end

% 3. Save Mapped Output for Step 4 (Rice Parameter & Quotient/Remainder)
out_filename = 'unsigned_residuals.txt';
fid = fopen(out_filename, 'w');
fprintf(fid, '%d\n', unsigned_vals);
fclose(fid);

% 4. Lossless Verification (Inverse ZigZag Check)
reconstructed = zeros(num_samples, 1);
for n = 1:num_samples
    u = unsigned_vals(n);
    if mod(u, 2) == 0
        reconstructed(n) = u / 2;
    else
        reconstructed(n) = -(u + 1) / 2;
    end
end

max_err = max(abs(residuals - reconstructed));
fprintf('=== Signed-to-Unsigned (ZigZag) Verification ===\n');
fprintf('Total Samples Processed : %d\n', num_samples);
fprintf('Input Range (Signed)    : [%d, %d]\n', min(residuals), max(residuals));
fprintf('Output Range (Unsigned) : [%d, %d]\n', min(unsigned_vals), max(unsigned_vals));
fprintf('Lossless Round-Trip Err : %d (Must be 0)\n', max_err);
fprintf('Saved mapped stream to  : %s\n', out_filename);

if max_err ~= 0
    error('Verification failed: Round-trip reconstruction mismatch!');
end

% 5. Visual Comparison Plot
figure('Name', 'Signed to Unsigned ZigZag Mapping', 'Position', [100, 100, 850, 500]);

subplot(2,1,1);
plot(1:num_samples, residuals, 'b-', 'LineWidth', 1.2);
title('Input: Signed Residual Errors e[n]');
xlabel('Sample Index [n]');
ylabel('Signed Value');
grid on;

subplot(2,1,2);
plot(1:num_samples, unsigned_vals, 'm-', 'LineWidth', 1.2);
title('Output: Unsigned Mapped Values u[n] (Non-Negative)');
xlabel('Sample Index [n]');
ylabel('Unsigned Value');
grid on;