function u_out = signed_to_unsigned(e_in)
% SIGNED_TO_UNSIGNED Maps signed prediction residuals to unsigned integers
% using Rice (ZigZag) mapping for Golomb-Rice entropy coding.
%
% Mapping rule:
%   e >= 0  -->  2 * e
%   e <  0  --> -2 * e - 1

e_val = double(e_in);

if e_val >= 0
    u_out = 2 * e_val;
else
    u_out = (-2 * e_val) - 1;
end
end