% test_neuron.m (Stable Version)
clear; clc; close all;

% 1. Load Stimulus Data and normalize to [-1, 1] range for stability
stimulus_file = 'stimulus_data.txt';
if ~exist(stimulus_file, 'file')
    error('Stimulus file %s not found. Run generate_stimulus.m first!', stimulus_file);
end
raw_signal = load(stimulus_file);
raw_signal = double(raw_signal) / max(abs(raw_signal)); % Normalized input
num_samples = length(raw_signal);

% 2. Initialize Neuron Parameters
num_taps = 4;                           
w = zeros(num_taps, 1);                 
b = 0;                                  
mu = 0.5;                               % NLMS can handle higher learning rates safely (e.g., 0.1 to 0.8)

x_history = zeros(num_taps, 1);
predicted_signal = zeros(num_samples, 1);
residuals = zeros(num_samples, 1);

% 3. Stream Processing Simulation Loop
for n = 1:num_samples
    current_val = raw_signal(n);

    % Run Stable Adaptive Neuron Module
    [pred_y, error_e, w, b] = adaptive_neuron(x_history, w, b, current_val, mu);

    predicted_signal(n) = pred_y;
    residuals(n) = error_e;

    % Shift delay line
    x_history = [current_val; x_history(1:end-1)];
end

% 4. Quantitative Metrics
var_raw = var(raw_signal);
var_res = var(residuals);
variance_reduction_db = 10 * log10(var_raw / var_res);

fprintf('==================================================\n');
fprintf('       STABLE PREDICTIVE CODING PERFORMANCE       \n');
fprintf('==================================================\n');
fprintf('Variance of Raw Input Signal : %.4f\n', var_raw);
fprintf('Variance of Residual Errors  : %.4f\n', var_res);
fprintf('Prediction Gain (Variance Reduction): %.2f dB\n', variance_reduction_db);
fprintf('==================================================\n');

% Save clean residuals for Step 3 (Golomb-Rice)
writematrix(residuals, 'residual_data.txt');
disp('[INFO] Clean residual error stream saved to residual_data.txt.');

% 5. Visualization Comparison
figure('Name', 'Stable Neuron Predictive Coding', 'Position', [100, 100, 900, 600]);

subplot(2,1,1);
plot(raw_signal, 'b', 'LineWidth', 1.5); hold on;
plot(predicted_signal, 'r--', 'LineWidth', 1.2);
title('Normalized Input Stream vs. Adaptive Neuron Prediction');
legend('Raw Signal (x)', 'Predicted Signal (\hat{x})');
xlabel('Sample Index [n]'); ylabel('Amplitude');
grid on;

subplot(2,1,2);
plot(residuals, 'k', 'LineWidth', 1);
title(['Prediction Residual Errors (e[n]) (Variance Reduction: ', sprintf('%.1f dB', variance_reduction_db), ')']);
legend('Residual Error');
xlabel('Sample Index [n]'); ylabel('Error Amplitude');
grid on;