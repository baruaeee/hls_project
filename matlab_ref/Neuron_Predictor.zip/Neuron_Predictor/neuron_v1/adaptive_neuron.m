function [pred_y, error_e, w_next, b_next] = adaptive_neuron(x_history, w, b, current_val, mu)
% ADAPTIVE_NEURON Stable predictive coding neuron using Normalized LMS (NLMS).

coder.hdl.literaltext("#pragma HLS ARRAY_PARTITION variable=x_history complete dim=1");
coder.hdl.literaltext("#pragma HLS ARRAY_PARTITION variable=w complete dim=1");
coder.hdl.literaltext("#pragma HLS PIPELINE II=1");

% 1. Forward Pass: Compute prediction (y_hat = b + sum(w_i * x_i))
pred_y = b;
coder.hdl.loopspec('unroll');
for i = 1:numel(x_history)
    pred_y = pred_y + (x_history(i) * w(i));
end

% 2. Compute Prediction Error (Residual)
error_e = current_val - pred_y;

% 3. Backward Pass: Normalized LMS Adaptation (Prevents overflow/instability)
% Small epsilon to prevent division by zero when signal is quiet
eps_val = 1e-6; 
norm_factor = sum(x_history.^2) + eps_val;

% Update weights and bias safely
w_next = w + (mu * error_e * x_history) / norm_factor;
b_next = b + (mu * error_e);
end