#pragma once

#include <fstream>
#include <sstream>
#include "rtwtypes.hpp"
#include <cmath>
#include <cstring>
#include <type_traits>

struct input_struct {
  ap_fixed<14,1> x_history[4];
  ap_fixed<14,4> w[4];
  ap_fixed<14,2> b;
  ap_fixed<14,1> current_val;
  ap_ufixed<14,0> mu;
};

struct output_struct {
  ap_fixed<14,3> pred_y;
  ap_fixed<14,2> error_e;
  ap_fixed<14,4> w_next[4];
  ap_fixed<14,2> b_next;
};

class adaptive_neuron_fixptClass_tb
{
 private:
  int num_test_cases;
  int input_test_cases;
  int output_test_cases;
  int failed_test_cases;
  bool sim_passes;
  bool stimuli_done;
  bool checker_done;
  bool test_point_failed;
  std::ifstream fstream_x_history;
  std::ifstream fstream_w;
  std::ifstream fstream_b;
  std::ifstream fstream_current_val;
  std::ifstream fstream_pred_y_expected;
  std::ifstream fstream_error_e_expected;
  std::ifstream fstream_w_next_expected;
  std::ifstream fstream_b_next_expected;
 public:
  adaptive_neuron_fixptClass_tb()
  {
    num_test_cases = 256;
    input_test_cases = 0;
    output_test_cases = 0;
    failed_test_cases = 0;
    sim_passes = true;
    stimuli_done = false;
    checker_done = false;
    test_point_failed = false;
    fstream_x_history.open("x_history.dat");
    fstream_w.open("w.dat");
    fstream_b.open("b.dat");
    fstream_current_val.open("current_val.dat");
    fstream_pred_y_expected.open("pred_y_expected.dat");
    fstream_error_e_expected.open("error_e_expected.dat");
    fstream_w_next_expected.open("w_next_expected.dat");
    fstream_b_next_expected.open("b_next_expected.dat");
  }

  ~adaptive_neuron_fixptClass_tb()
  {
    fstream_x_history.close();
    fstream_w.close();
    fstream_b.close();
    fstream_current_val.close();
    fstream_pred_y_expected.close();
    fstream_error_e_expected.close();
    fstream_w_next_expected.close();
    fstream_b_next_expected.close();
  }

  int get_num_test_cases()
  {
    return num_test_cases;
  }

  int get_num_test_cases_passed()
  {
    return (num_test_cases - failed_test_cases);
  }

  int get_num_test_cases_failed()
  {
    return failed_test_cases;
  }

  bool is_sim_passing()
  {
    return sim_passes;
  }

  bool is_stimuli_done()
  {
    return stimuli_done;
  }

  bool is_checker_done()
  {
    return checker_done;
  }

  void print_pass_fail()
  {
    if (sim_passes) {
      std::cout << "### Total Testpoints   : "<< num_test_cases << std::endl;
      std::cout << "### Tests Passed       : "<< get_num_test_cases_passed() <<
        std::endl;
      std::cout << "**************TEST COMPLETED (PASSED)**************" << std::
        endl;
    } else {
      std::cout << "### Total Testpoints   : "<< num_test_cases << std::endl;
      std::cout << "### Tests Failed       : "<< get_num_test_cases_failed() <<
        std::endl;
      std::cout << "**************TEST COMPLETED (FAILED)**************" << std::
        endl;
    }
  }

  template<typename T>
    void get_next_value(std::istream& fs, T (&in))
  {
    std::string ref_str;
    fs >> ref_str;
    ref_str = "0x" + ref_str;
    in = ref_str.c_str();
  }

  void get_next_value(std::istream& fs, boolean_T (&in))
  {
    std::string ref_str;
    fs >> ref_str;
    in = std::stoi(ref_str);
  }

  void get_next_value(std::istream& fs, real_T (&in))
  {
    std::string ref_str;
    fs >> ref_str;
    ref_str = "0x" + ref_str;
    uint64_T ref_int = (uint64_T)std::stoull(ref_str, nullptr, 16);
    std::memcpy(&in, &ref_int, sizeof(real_T));
  }

  void get_next_value(std::istream& fs, real32_T (&in))
  {
    std::string ref_str;
    fs >> ref_str;
    ref_str = "0x" + ref_str;
    uint32_T ref_int = (uint32_T)std::stoull(ref_str, nullptr, 16);
    std::memcpy(&in, &ref_int, sizeof(real32_T));
  }

  template<int wl, int iwl>
    void get_next_value(std::istream& fs, ap_ufixed<wl,iwl> (&in))
  {
    std::string ref_str;
    fs >> ref_str;
    ref_str = "0x" + ref_str;
    in.range() = ref_str.c_str();
  }

  template<int wl, int iwl>
    void get_next_value(std::istream& fs, ap_fixed<wl,iwl> (&in))
  {
    std::string ref_str;
    fs >> ref_str;
    ref_str = "0x" + ref_str;
    in.range() = ref_str.c_str();
  }

  template<typename T>
    void read_scalar_input(std::istream& fs, T (&in))
  {
    get_next_value(fs,in);
  }

  template<typename T, size_t dim_1>
    void read_vector_input(std::istream& fs, T (&in)[dim_1])
  {
    for (int j_1 = 0; j_1 < dim_1; j_1++) {
      read_scalar_input(fs, in[j_1]);
    }
  }

  template<typename T, size_t dim_1, size_t dim_2>
    void read_2Dmatrix_input(std::istream& fs, T (&in)[dim_1][dim_2])
  {
    for (int j_2 = 0; j_2 < dim_2; j_2++) {
      for (int j_1 = 0; j_1 < dim_1; j_1++) {
        read_scalar_input(fs, in[j_1][j_2]);
      }
    }
  }

  template<typename T, size_t dim_1, size_t dim_2, size_t dim_3>
    void read_3Dmatrix_input(std::istream& fs, T (&in)[dim_1][dim_2][dim_3])
  {
    for (int j_3 = 0; j_3 < dim_3; j_3++) {
      for (int j_1 = 0; j_1 < dim_1; j_1++) {
        for (int j_2 = 0; j_2 < dim_2; j_2++) {
          read_scalar_input(fs, in[j_1][j_2][j_3]);
        }
      }
    }
  }

  void read_struct_field_from_line(std::string& line, size_t& pos, real_T& field)
  {
    std::string hex_str = line.substr(pos, 16);
    pos += 16;
    hex_str = "0x" + hex_str;
    uint64_T ref_int = (uint64_T)std::stoull(hex_str, nullptr, 16);
    std::memcpy(&field, &ref_int, sizeof(real_T));
  }

  void read_struct_field_from_line(std::string& line, size_t& pos, real32_T
    & field)
  {
    std::string hex_str = line.substr(pos, 8);
    pos += 8;
    hex_str = "0x" + hex_str;
    uint32_T ref_int = (uint32_T)std::stoull(hex_str, nullptr, 16);
    std::memcpy(&field, &ref_int, sizeof(real32_T));
  }

  void read_struct_field_from_line(std::string& line, size_t& pos, boolean_T
    & field)
  {
    std::string hex_str = line.substr(pos, 1);
    pos += 1;
    field = std::stoi(hex_str, nullptr, 16);
  }

  template<int wl, int iwl>
    void read_struct_field_from_line(std::string& line, size_t& pos, ap_fixed<wl,
    iwl>& field)
  {
    int hex_chars = (wl + 3) / 4;
    std::string hex_str = line.substr(pos, hex_chars);
    pos += hex_chars;
    hex_str = "0x" + hex_str;
    field.range() = hex_str.c_str();
  }

  template<int wl, int iwl>
    void read_struct_field_from_line(std::string& line, size_t& pos, ap_ufixed<
    wl,iwl>& field)
  {
    int hex_chars = (wl + 3) / 4;
    std::string hex_str = line.substr(pos, hex_chars);
    pos += hex_chars;
    hex_str = "0x" + hex_str;
    field.range() = hex_str.c_str();
  }

  template<int wl>
    void read_struct_field_from_line(std::string& line, size_t& pos, ap_int<wl>&
    field)
  {
    int hex_chars = (wl + 3) / 4;
    std::string hex_str = line.substr(pos, hex_chars);
    pos += hex_chars;
    hex_str = "0x" + hex_str;
    field = hex_str.c_str();
  }

  template<int wl>
    void read_struct_field_from_line(std::string& line, size_t& pos, ap_uint<wl>
    & field)
  {
    int hex_chars = (wl + 3) / 4;
    std::string hex_str = line.substr(pos, hex_chars);
    pos += hex_chars;
    hex_str = "0x" + hex_str;
    field = hex_str.c_str();
  }

  template<typename T>
    void read_struct_field(std::string& line, size_t& pos, T& field)
  {
    read_struct_field_from_line(line, pos, field);
  }

  template<typename T, size_t dim_1>
    void read_struct_field(std::string& line, size_t& pos, T (&field)[dim_1])
  {
    for (int j_1 = 0; j_1 < dim_1; j_1++) {
      read_struct_field(line, pos, field[j_1]);
    }
  }

  template<typename T, size_t dim_1, size_t dim_2>
    void read_struct_field(std::string& line, size_t& pos, T (&field)[dim_1]
    [dim_2])
  {
    for (int j_2 = 0; j_2 < dim_2; j_2++) {
      for (int j_1 = 0; j_1 < dim_1; j_1++) {
        read_struct_field(line, pos, field[j_1][j_2]);
      }
    }
  }

  template<typename T, size_t dim_1, size_t dim_2, size_t dim_3>
    void read_struct_field(std::string& line, size_t& pos, T (&field)[dim_1]
    [dim_2][dim_3])
  {
    for (int j_3 = 0; j_3 < dim_3; j_3++) {
      for (int j_1 = 0; j_1 < dim_1; j_1++) {
        for (int j_2 = 0; j_2 < dim_2; j_2++) {
          read_struct_field(line, pos, field[j_1][j_2][j_3]);
        }
      }
    }
  }

  void generate_stimulus(input_struct& in)
  {
    read_vector_input(fstream_x_history, in.x_history);
    read_vector_input(fstream_w, in.w);
    read_scalar_input(fstream_b, in.b);
    read_scalar_input(fstream_current_val, in.current_val);
    ap_ufixed<14,0> in_mu_loc;
    in_mu_loc.range() = "0x2000";
    in.mu = in_mu_loc;
    input_test_cases++;
    if (input_test_cases == num_test_cases) {
      stimuli_done = true;
    }
  }

  template<typename T>
    void check_scalar_output(T (&ref), T (&act), const std::string outName)
  {
    if (act != ref) {
      std::cout << "TestPoint: ";
      sim_passes = false;
      test_point_failed = true;
      std::cout << std::to_string(output_test_cases + 1);
      std::cout << " Output mismatch: " << outName;
      std::cout << " Expected: " << ref;
      std::cout << " Actual: " << act;
      std::cout << std::endl;
    }
  }

  template<typename T>
    void check_scalar_output(std::istream& fs, T (&out), const std::string
    outName)
  {
    T ref;
    get_next_value(fs, ref);
    check_scalar_output(ref,out,outName);
  }

  template<typename T, size_t dim_1>
    void check_vector_output(std::istream& fs, T (&out)[dim_1], const std::
    string outName)
  {
    for (int j_1 = 0; j_1 < dim_1; j_1++) {
      check_scalar_output(fs, out[j_1], outName);
    }
  }

  template<typename T, size_t dim_1>
    void check_vector_output(T (&out_ref)[dim_1], T (&out)[dim_1], const std::
    string outName)
  {
    for (int j_1 = 0; j_1 < dim_1; j_1++) {
      check_scalar_output(out_ref[j_1], out[j_1], outName);
    }
  }

  template<typename T, size_t dim_1, size_t dim_2>
    void check_2Dmatrix_output(std::istream& fs, T (&out)[dim_1][dim_2], const
    std::string outName)
  {
    for (int j_2 = 0; j_2 < dim_2; j_2++) {
      for (int j_1 = 0; j_1 < dim_1; j_1++) {
        check_scalar_output(fs, out[j_1][j_2], outName);
      }
    }
  }

  template<typename T, size_t dim_1, size_t dim_2>
    void check_2Dmatrix_output(T (&out_ref)[dim_1][dim_2], T (&out)[dim_1][dim_2],
    const std::string outName)
  {
    for (int j_2 = 0; j_2 < dim_2; j_2++) {
      for (int j_1 = 0; j_1 < dim_1; j_1++) {
        check_scalar_output(out_ref[j_1][j_2], out[j_1][j_2], outName);
      }
    }
  }

  template<typename T, size_t dim_1, size_t dim_2, size_t dim_3>
    void check_3Dmatrix_output(std::istream& fs, T (&out)[dim_1][dim_2][dim_3],
    const std::string outName)
  {
    for (int j_3 = 0; j_3 < dim_3; j_3++) {
      for (int j_1 = 0; j_1 < dim_1; j_1++) {
        for (int j_2 = 0; j_2 < dim_2; j_2++) {
          check_scalar_output(fs, out[j_1][j_2][j_3], outName);
        }
      }
    }
  }

  template<typename T, size_t dim_1, size_t dim_2, size_t dim_3>
    void check_3Dmatrix_output(T (&out_ref)[dim_1][dim_2][dim_3], T (&out)[dim_1]
    [dim_2][dim_3], const std::string outName)
  {
    for (int j_3 = 0; j_3 < dim_3; j_3++) {
      for (int j_1 = 0; j_1 < dim_1; j_1++) {
        for (int j_2 = 0; j_2 < dim_2; j_2++) {
          check_scalar_output(out_ref[j_1][j_2][j_3], out[j_1][j_2][j_3],
                              outName);
        }
      }
    }
  }

  void check_output(output_struct& out)
  {
    test_point_failed = false;
    check_scalar_output(fstream_pred_y_expected, out.pred_y, "pred_y");
    check_scalar_output(fstream_error_e_expected, out.error_e, "error_e");
    check_vector_output(fstream_w_next_expected, out.w_next, "w_next");
    check_scalar_output(fstream_b_next_expected, out.b_next, "b_next");
    if (test_point_failed) {
      failed_test_cases++;
    }

    output_test_cases++;
    if (output_test_cases == num_test_cases) {
      checker_done = true;
    }
  }
};
