#include "adaptive_neuron_fixptClass.hpp"
#include "adaptive_neuron_fixptClass_tb.hpp"

int main()
{
  adaptive_neuron_fixptClass dut;
  adaptive_neuron_fixptClass_tb tb;
  input_struct inputs;
  output_struct outputs;
  while (!tb.is_stimuli_done()) {
    tb.generate_stimulus(inputs);
    adaptive_neuron_fixpt_wrapper(inputs.x_history, inputs.w, inputs.b,
      inputs.current_val, inputs.mu, outputs.pred_y, outputs.error_e,
      outputs.w_next, outputs.b_next);
    tb.check_output(outputs);
  }

  tb.print_pass_fail();
  if (tb.is_sim_passing()) {
    return 0;
  } else {
    return 1;
  }
}
