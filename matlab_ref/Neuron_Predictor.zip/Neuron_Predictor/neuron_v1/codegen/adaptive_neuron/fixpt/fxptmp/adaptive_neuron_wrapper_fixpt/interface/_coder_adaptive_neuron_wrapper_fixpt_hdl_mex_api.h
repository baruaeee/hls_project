#pragma once

#include "rtwtypes.h"
#include "emlrt.h"
#include "mex.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>

void d_adaptive_neuron_fixpt_logger_(const mxArray **plhs);

void d_adaptive_neuron_wrapper_fixpt(const mxArray *const prhs[5], int32_T nlhs,
                                     const mxArray *plhs[4]);
