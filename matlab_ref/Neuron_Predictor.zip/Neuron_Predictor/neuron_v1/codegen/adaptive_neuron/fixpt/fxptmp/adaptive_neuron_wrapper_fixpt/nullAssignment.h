#pragma once

#include "rtwtypes.h"
#include "coder_array.h"
#include "emlrt.h"
#include "mex.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>

namespace coder {
namespace internal {
void nullAssignment(const emlrtStack &sp, array<int16_T, 1U> &x,
                    const array<int32_T, 1U> &idx);

void nullAssignment(const emlrtStack &sp, array<int16_T, 2U> &x,
                    const array<int32_T, 1U> &idx);

} // namespace internal
} // namespace coder
