#include "adaptive_neuron_fixpt_logger.h"
#include "adaptive_neuron_wrapper_fixpt_hdl_mex_data.h"
#include "adaptive_neuron_wrapper_fixpt_hdl_mex_types.h"
#include "nullAssignment.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <cstring>
#include <emmintrin.h>

static real_T iterCount;

static boolean_T iterCount_not_empty;

static coder::array<int16_T, 1U> p;

static boolean_T p_not_empty;

static coder::array<int16_T, 1U> b_p;

static boolean_T b_p_not_empty;

static coder::array<int16_T, 2U> c_p;

static boolean_T c_p_not_empty;

static coder::array<int16_T, 2U> d_p;

static boolean_T d_p_not_empty;

static coder::array<uint16_T, 2U> e_p;

static boolean_T e_p_not_empty;

static coder::array<int16_T, 2U> f_p;

static boolean_T f_p_not_empty;

static coder::array<int16_T, 2U> g_p;

static boolean_T g_p_not_empty;

static coder::array<int16_T, 1U> h_p;

static boolean_T h_p_not_empty;

static coder::array<int16_T, 2U> i_p;

static boolean_T i_p_not_empty;

static emlrtRSInfo c_emlrtRSI{
    13, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRSInfo d_emlrtRSI{
    14, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRSInfo e_emlrtRSI{
    15, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRSInfo f_emlrtRSI{
    16, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRSInfo g_emlrtRSI{
    17, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRSInfo h_emlrtRSI{
    18, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRSInfo i_emlrtRSI{
    19, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRSInfo j_emlrtRSI{
    20, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRSInfo k_emlrtRSI{
    21, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRSInfo l_emlrtRSI{
    32, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRSInfo m_emlrtRSI{
    33, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRSInfo n_emlrtRSI{
    34, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRSInfo o_emlrtRSI{
    35, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRSInfo p_emlrtRSI{
    36, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRSInfo q_emlrtRSI{
    37, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRSInfo r_emlrtRSI{
    38, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRSInfo s_emlrtRSI{
    39, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRSInfo t_emlrtRSI{
    40, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRSInfo u_emlrtRSI{
    87, "x_history_TB_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRSInfo eb_emlrtRSI{
    134, "w_TB_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRSInfo fb_emlrtRSI{
    181, "b_TB_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRSInfo gb_emlrtRSI{
    228, "current_val_TB_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRSInfo hb_emlrtRSI{
    275, "mu_TB_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRSInfo ib_emlrtRSI{
    322, "pred_y_TB_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRSInfo jb_emlrtRSI{
    369, "error_e_TB_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRSInfo kb_emlrtRSI{
    416, "w_next_TB_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRSInfo lb_emlrtRSI{
    463, "b_next_TB_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtMCInfo b_emlrtMCI{
    25, 20, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtMCInfo c_emlrtMCI{
    25, 13, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRTEInfo emlrtRTEI{
    31, 9, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRTEInfo b_emlrtRTEI{
    82, 9, "x_history_TB_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRTEInfo f_emlrtRTEI{
    129, 9, "w_TB_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRTEInfo g_emlrtRTEI{
    176, 9, "b_TB_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRTEInfo h_emlrtRTEI{
    223, 9, "current_val_TB_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRTEInfo j_emlrtRTEI{
    270, 9, "mu_TB_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRTEInfo k_emlrtRTEI{
    317, 9, "pred_y_TB_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRTEInfo l_emlrtRTEI{
    364, 9, "error_e_TB_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRTEInfo m_emlrtRTEI{
    411, 9, "w_next_TB_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRTEInfo n_emlrtRTEI{
    458, 9, "b_next_TB_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static const int32_T iv[4]{0, 1, 2, 3};

static emlrtRSInfo mb_emlrtRSI{
    25, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRTEInfo o_emlrtRTEI{
    44, 16, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRTEInfo p_emlrtRTEI{
    91, 16, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRTEInfo q_emlrtRTEI{
    138, 16, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRTEInfo r_emlrtRTEI{
    185, 16, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRTEInfo s_emlrtRTEI{
    232, 16, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRTEInfo t_emlrtRTEI{
    279, 16, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRTEInfo u_emlrtRTEI{
    326, 16, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRTEInfo v_emlrtRTEI{
    373, 16, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static emlrtRTEInfo w_emlrtRTEI{
    420, 16, "adaptive_neuron_fixpt_logger",
    "/MATLAB "
    "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/fixpt/fxptmp/"
    "adaptive_neuron_fixpt_logger.m"};

static const mxArray *MException(const emlrtStack &sp, const mxArray *m,
                                 const mxArray *m1, emlrtMCInfo &location);

static void b_throw(const emlrtStack &sp, const mxArray *m,
                    emlrtMCInfo &location);

namespace coder {
static void b_TB_logger(const emlrtStack &sp, array<int16_T, 2U> &out);

static void b_TB_logger(const emlrtStack &sp, int16_T v);

static void b_next_TB_logger(const emlrtStack &sp, array<int16_T, 2U> &out);

static void b_next_TB_logger(const emlrtStack &sp, int16_T v);

static void current_val_TB_logger(const emlrtStack &sp,
                                  array<int16_T, 2U> &out);

static void current_val_TB_logger(const emlrtStack &sp, int16_T v);

static void error_e_TB_logger(const emlrtStack &sp, array<int16_T, 2U> &out);

static void error_e_TB_logger(const emlrtStack &sp, int16_T v);

static void mu_TB_logger(const emlrtStack &sp, array<uint16_T, 2U> &out);

static void mu_TB_logger(const emlrtStack &sp, uint16_T v);

static void pred_y_TB_logger(const emlrtStack &sp, array<int16_T, 2U> &out);

static void pred_y_TB_logger(const emlrtStack &sp, int16_T v);

static void w_TB_logger(const emlrtStack &sp, const int16_T v[4]);

static void w_TB_logger(const emlrtStack &sp, array<int16_T, 1U> &out);

static void w_next_TB_logger(const emlrtStack &sp, const int16_T v[4]);

static void w_next_TB_logger(const emlrtStack &sp, array<int16_T, 1U> &out);

static void x_history_TB_logger(const emlrtStack &sp, array<int16_T, 1U> &out);

static void x_history_TB_logger(const emlrtStack &sp, const int16_T v[4]);

} // namespace coder

static const mxArray *MException(const emlrtStack &sp, const mxArray *m,
                                 const mxArray *m1, emlrtMCInfo &location)
{
  const mxArray *pArrays[2];
  const mxArray *m2;
  pArrays[0] = m;
  pArrays[1] = m1;
  return emlrtCallMATLABR2012b((emlrtConstCTX)&sp, 1, &m2, 2, &pArrays[0],
                               "MException", true, &location);
}

static void b_throw(const emlrtStack &sp, const mxArray *m,
                    emlrtMCInfo &location)
{
  emlrtCallMATLABR2012b((emlrtConstCTX)&sp, 0, nullptr, 1, &m, "throw", true,
                        &location);
}

namespace coder {
static void b_TB_logger(const emlrtStack &sp, array<int16_T, 2U> &out)
{
  array<int32_T, 1U> r;
  emlrtStack st;
  int32_T loop_ub;
  int32_T scalarLB;
  int32_T vectorUB;
  st.prev = &sp;
  st.tls = sp.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  if (!c_p_not_empty) {
    emlrtErrorWithMessageIdR2018a(&sp, &g_emlrtRTEI,
                                  "Coder:builtins:AssertionFailed",
                                  "Coder:builtins:AssertionFailed", 0);
  }
  loop_ub = c_p.size(1);
  out.set_size(&q_emlrtRTEI, &sp, 1, c_p.size(1));
  for (int32_T i{0}; i < loop_ub; i++) {
    out[i] = c_p[i];
  }
  r.set_size(&q_emlrtRTEI, &sp, c_p.size(1));
  scalarLB = (c_p.size(1) / 4) << 2;
  vectorUB = scalarLB - 4;
  for (int32_T i{0}; i <= vectorUB; i += 4) {
    _mm_storeu_si128(
        (__m128i *)&r[i],
        _mm_add_epi32(_mm_add_epi32(_mm_set1_epi32(i),
                                    _mm_loadu_si128((const __m128i *)&iv[0])),
                      _mm_set1_epi32(1)));
  }
  for (int32_T i{scalarLB}; i < loop_ub; i++) {
    r[i] = i + 1;
  }
  st.site = &fb_emlrtRSI;
  internal::nullAssignment(st, c_p, r);
  c_p_not_empty = (c_p.size(1) != 0);
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

static void b_TB_logger(const emlrtStack &sp, int16_T v)
{
  if (!c_p_not_empty) {
    c_p.set_size(&q_emlrtRTEI, &sp, 1, 1);
    c_p[0] = v;
    c_p_not_empty = true;
  } else {
    int32_T i;
    i = c_p.size(1);
    c_p.set_size(&q_emlrtRTEI, &sp, c_p.size(0), c_p.size(1) + 1);
    c_p[i] = v;
  }
}

static void b_next_TB_logger(const emlrtStack &sp, int16_T v)
{
  if (!i_p_not_empty) {
    i_p.set_size(&w_emlrtRTEI, &sp, 1, 1);
    i_p[0] = v;
    i_p_not_empty = true;
  } else {
    int32_T i;
    i = i_p.size(1);
    i_p.set_size(&w_emlrtRTEI, &sp, i_p.size(0), i_p.size(1) + 1);
    i_p[i] = v;
  }
}

static void b_next_TB_logger(const emlrtStack &sp, array<int16_T, 2U> &out)
{
  array<int32_T, 1U> r;
  emlrtStack st;
  int32_T loop_ub;
  int32_T scalarLB;
  int32_T vectorUB;
  st.prev = &sp;
  st.tls = sp.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  if (!i_p_not_empty) {
    emlrtErrorWithMessageIdR2018a(&sp, &n_emlrtRTEI,
                                  "Coder:builtins:AssertionFailed",
                                  "Coder:builtins:AssertionFailed", 0);
  }
  loop_ub = i_p.size(1);
  out.set_size(&w_emlrtRTEI, &sp, 1, i_p.size(1));
  for (int32_T i{0}; i < loop_ub; i++) {
    out[i] = i_p[i];
  }
  r.set_size(&w_emlrtRTEI, &sp, i_p.size(1));
  scalarLB = (i_p.size(1) / 4) << 2;
  vectorUB = scalarLB - 4;
  for (int32_T i{0}; i <= vectorUB; i += 4) {
    _mm_storeu_si128(
        (__m128i *)&r[i],
        _mm_add_epi32(_mm_add_epi32(_mm_set1_epi32(i),
                                    _mm_loadu_si128((const __m128i *)&iv[0])),
                      _mm_set1_epi32(1)));
  }
  for (int32_T i{scalarLB}; i < loop_ub; i++) {
    r[i] = i + 1;
  }
  st.site = &lb_emlrtRSI;
  internal::nullAssignment(st, i_p, r);
  i_p_not_empty = (i_p.size(1) != 0);
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

static void current_val_TB_logger(const emlrtStack &sp, array<int16_T, 2U> &out)
{
  array<int32_T, 1U> idx;
  array<boolean_T, 2U> b;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack e_st;
  emlrtStack st;
  int32_T k0;
  int32_T loop_ub;
  int32_T nxout;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  e_st.prev = &d_st;
  e_st.tls = d_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  if (!d_p_not_empty) {
    emlrtErrorWithMessageIdR2018a(&sp, &h_emlrtRTEI,
                                  "Coder:builtins:AssertionFailed",
                                  "Coder:builtins:AssertionFailed", 0);
  }
  loop_ub = d_p.size(1);
  out.set_size(&r_emlrtRTEI, &sp, 1, d_p.size(1));
  for (int32_T k{0}; k < loop_ub; k++) {
    out[k] = d_p[k];
  }
  st.site = &gb_emlrtRSI;
  idx.set_size(&r_emlrtRTEI, &st, d_p.size(1));
  nxout = (d_p.size(1) / 4) << 2;
  k0 = nxout - 4;
  for (int32_T k{0}; k <= k0; k += 4) {
    _mm_storeu_si128(
        (__m128i *)&idx[k],
        _mm_add_epi32(_mm_add_epi32(_mm_set1_epi32(k),
                                    _mm_loadu_si128((const __m128i *)&iv[0])),
                      _mm_set1_epi32(1)));
  }
  for (int32_T k{nxout}; k < loop_ub; k++) {
    idx[k] = k + 1;
  }
  b_st.site = &v_emlrtRSI;
  d_p_not_empty = true;
  nxout = 0;
  while (nxout <= d_p.size(1) - 1) {
    if (idx[nxout] > d_p.size(1)) {
      d_p_not_empty = false;
      break;
    } else {
      nxout++;
    }
  }
  if (!d_p_not_empty) {
    emlrtErrorWithMessageIdR2018a(&b_st, &c_emlrtRTEI,
                                  "MATLAB:subsdeldimmismatch",
                                  "MATLAB:subsdeldimmismatch", 0);
  }
  b_st.site = &w_emlrtRSI;
  c_st.site = &x_emlrtRSI;
  b.set_size(&r_emlrtRTEI, &c_st, 1, d_p.size(1));
  if (loop_ub - 1 >= 0) {
    std::memset(&b[0], 0, static_cast<uint32_T>(loop_ub) * sizeof(boolean_T));
  }
  d_st.site = &bb_emlrtRSI;
  if (d_p.size(1) > 2147483646) {
    e_st.site = &cb_emlrtRSI;
    emlrtErrorWithMessageIdR2018a(
        &e_st, &e_emlrtRTEI, "Coder:toolbox:int_forloop_overflow",
        "Coder:toolbox:int_forloop_overflow", 3, 4, 5, "int32");
  }
  for (int32_T k{0}; k < loop_ub; k++) {
    b[idx[k] - 1] = true;
  }
  c_st.site = &y_emlrtRSI;
  nxout = 0;
  d_st.site = &db_emlrtRSI;
  if (b.size(1) > 2147483646) {
    e_st.site = &cb_emlrtRSI;
    emlrtErrorWithMessageIdR2018a(
        &e_st, &e_emlrtRTEI, "Coder:toolbox:int_forloop_overflow",
        "Coder:toolbox:int_forloop_overflow", 3, 4, 5, "int32");
  }
  for (int32_T k{0}; k < loop_ub; k++) {
    nxout += b[k];
  }
  nxout = d_p.size(1) - nxout;
  k0 = -1;
  c_st.site = &ab_emlrtRSI;
  if (d_p.size(1) > 2147483646) {
    d_st.site = &cb_emlrtRSI;
    emlrtErrorWithMessageIdR2018a(
        &d_st, &e_emlrtRTEI, "Coder:toolbox:int_forloop_overflow",
        "Coder:toolbox:int_forloop_overflow", 3, 4, 5, "int32");
  }
  for (int32_T k{0}; k < loop_ub; k++) {
    if ((k + 1 > b.size(1)) || !b[k]) {
      k0++;
      d_p[k0] = d_p[k];
    }
  }
  if (nxout > d_p.size(1)) {
    emlrtErrorWithMessageIdR2018a(&b_st, &i_emlrtRTEI,
                                  "Coder:builtins:AssertionFailed",
                                  "Coder:builtins:AssertionFailed", 0);
  }
  if (nxout < 1) {
    nxout = 0;
  }
  d_p.set_size(&r_emlrtRTEI, &b_st, d_p.size(0), nxout);
  d_p_not_empty = (d_p.size(1) != 0);
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

static void current_val_TB_logger(const emlrtStack &sp, int16_T v)
{
  if (!d_p_not_empty) {
    d_p.set_size(&r_emlrtRTEI, &sp, 1, 1);
    d_p[0] = v;
    d_p_not_empty = true;
  } else {
    int32_T i;
    i = d_p.size(1);
    d_p.set_size(&r_emlrtRTEI, &sp, d_p.size(0), d_p.size(1) + 1);
    d_p[i] = v;
  }
}

static void error_e_TB_logger(const emlrtStack &sp, array<int16_T, 2U> &out)
{
  array<int32_T, 1U> r;
  emlrtStack st;
  int32_T loop_ub;
  int32_T scalarLB;
  int32_T vectorUB;
  st.prev = &sp;
  st.tls = sp.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  if (!g_p_not_empty) {
    emlrtErrorWithMessageIdR2018a(&sp, &l_emlrtRTEI,
                                  "Coder:builtins:AssertionFailed",
                                  "Coder:builtins:AssertionFailed", 0);
  }
  loop_ub = g_p.size(1);
  out.set_size(&u_emlrtRTEI, &sp, 1, g_p.size(1));
  for (int32_T i{0}; i < loop_ub; i++) {
    out[i] = g_p[i];
  }
  r.set_size(&u_emlrtRTEI, &sp, g_p.size(1));
  scalarLB = (g_p.size(1) / 4) << 2;
  vectorUB = scalarLB - 4;
  for (int32_T i{0}; i <= vectorUB; i += 4) {
    _mm_storeu_si128(
        (__m128i *)&r[i],
        _mm_add_epi32(_mm_add_epi32(_mm_set1_epi32(i),
                                    _mm_loadu_si128((const __m128i *)&iv[0])),
                      _mm_set1_epi32(1)));
  }
  for (int32_T i{scalarLB}; i < loop_ub; i++) {
    r[i] = i + 1;
  }
  st.site = &jb_emlrtRSI;
  internal::nullAssignment(st, g_p, r);
  g_p_not_empty = (g_p.size(1) != 0);
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

static void error_e_TB_logger(const emlrtStack &sp, int16_T v)
{
  if (!g_p_not_empty) {
    g_p.set_size(&u_emlrtRTEI, &sp, 1, 1);
    g_p[0] = v;
    g_p_not_empty = true;
  } else {
    int32_T i;
    i = g_p.size(1);
    g_p.set_size(&u_emlrtRTEI, &sp, g_p.size(0), g_p.size(1) + 1);
    g_p[i] = v;
  }
}

static void mu_TB_logger(const emlrtStack &sp, array<uint16_T, 2U> &out)
{
  array<int32_T, 1U> idx;
  array<boolean_T, 2U> b;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack e_st;
  emlrtStack st;
  int32_T k0;
  int32_T loop_ub;
  int32_T nxout;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  e_st.prev = &d_st;
  e_st.tls = d_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  if (!e_p_not_empty) {
    emlrtErrorWithMessageIdR2018a(&sp, &j_emlrtRTEI,
                                  "Coder:builtins:AssertionFailed",
                                  "Coder:builtins:AssertionFailed", 0);
  }
  loop_ub = e_p.size(1);
  out.set_size(&s_emlrtRTEI, &sp, 1, e_p.size(1));
  for (int32_T k{0}; k < loop_ub; k++) {
    out[k] = e_p[k];
  }
  st.site = &hb_emlrtRSI;
  idx.set_size(&s_emlrtRTEI, &st, e_p.size(1));
  nxout = (e_p.size(1) / 4) << 2;
  k0 = nxout - 4;
  for (int32_T k{0}; k <= k0; k += 4) {
    _mm_storeu_si128(
        (__m128i *)&idx[k],
        _mm_add_epi32(_mm_add_epi32(_mm_set1_epi32(k),
                                    _mm_loadu_si128((const __m128i *)&iv[0])),
                      _mm_set1_epi32(1)));
  }
  for (int32_T k{nxout}; k < loop_ub; k++) {
    idx[k] = k + 1;
  }
  b_st.site = &v_emlrtRSI;
  e_p_not_empty = true;
  nxout = 0;
  while (nxout <= e_p.size(1) - 1) {
    if (idx[nxout] > e_p.size(1)) {
      e_p_not_empty = false;
      break;
    } else {
      nxout++;
    }
  }
  if (!e_p_not_empty) {
    emlrtErrorWithMessageIdR2018a(&b_st, &c_emlrtRTEI,
                                  "MATLAB:subsdeldimmismatch",
                                  "MATLAB:subsdeldimmismatch", 0);
  }
  b_st.site = &w_emlrtRSI;
  c_st.site = &x_emlrtRSI;
  b.set_size(&s_emlrtRTEI, &c_st, 1, e_p.size(1));
  if (loop_ub - 1 >= 0) {
    std::memset(&b[0], 0, static_cast<uint32_T>(loop_ub) * sizeof(boolean_T));
  }
  d_st.site = &bb_emlrtRSI;
  if (e_p.size(1) > 2147483646) {
    e_st.site = &cb_emlrtRSI;
    emlrtErrorWithMessageIdR2018a(
        &e_st, &e_emlrtRTEI, "Coder:toolbox:int_forloop_overflow",
        "Coder:toolbox:int_forloop_overflow", 3, 4, 5, "int32");
  }
  for (int32_T k{0}; k < loop_ub; k++) {
    b[idx[k] - 1] = true;
  }
  c_st.site = &y_emlrtRSI;
  nxout = 0;
  d_st.site = &db_emlrtRSI;
  if (b.size(1) > 2147483646) {
    e_st.site = &cb_emlrtRSI;
    emlrtErrorWithMessageIdR2018a(
        &e_st, &e_emlrtRTEI, "Coder:toolbox:int_forloop_overflow",
        "Coder:toolbox:int_forloop_overflow", 3, 4, 5, "int32");
  }
  for (int32_T k{0}; k < loop_ub; k++) {
    nxout += b[k];
  }
  nxout = e_p.size(1) - nxout;
  k0 = -1;
  c_st.site = &ab_emlrtRSI;
  if (e_p.size(1) > 2147483646) {
    d_st.site = &cb_emlrtRSI;
    emlrtErrorWithMessageIdR2018a(
        &d_st, &e_emlrtRTEI, "Coder:toolbox:int_forloop_overflow",
        "Coder:toolbox:int_forloop_overflow", 3, 4, 5, "int32");
  }
  for (int32_T k{0}; k < loop_ub; k++) {
    if ((k + 1 > b.size(1)) || !b[k]) {
      k0++;
      e_p[k0] = e_p[k];
    }
  }
  if (nxout > e_p.size(1)) {
    emlrtErrorWithMessageIdR2018a(&b_st, &i_emlrtRTEI,
                                  "Coder:builtins:AssertionFailed",
                                  "Coder:builtins:AssertionFailed", 0);
  }
  if (nxout < 1) {
    nxout = 0;
  }
  e_p.set_size(&s_emlrtRTEI, &b_st, e_p.size(0), nxout);
  e_p_not_empty = (e_p.size(1) != 0);
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

static void mu_TB_logger(const emlrtStack &sp, uint16_T v)
{
  if (!e_p_not_empty) {
    e_p.set_size(&s_emlrtRTEI, &sp, 1, 1);
    e_p[0] = v;
    e_p_not_empty = true;
  } else {
    int32_T i;
    i = e_p.size(1);
    e_p.set_size(&s_emlrtRTEI, &sp, e_p.size(0), e_p.size(1) + 1);
    e_p[i] = v;
  }
}

static void pred_y_TB_logger(const emlrtStack &sp, array<int16_T, 2U> &out)
{
  array<int32_T, 1U> idx;
  array<boolean_T, 2U> b;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack e_st;
  emlrtStack st;
  int32_T k0;
  int32_T loop_ub;
  int32_T nxout;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  e_st.prev = &d_st;
  e_st.tls = d_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  if (!f_p_not_empty) {
    emlrtErrorWithMessageIdR2018a(&sp, &k_emlrtRTEI,
                                  "Coder:builtins:AssertionFailed",
                                  "Coder:builtins:AssertionFailed", 0);
  }
  loop_ub = f_p.size(1);
  out.set_size(&t_emlrtRTEI, &sp, 1, f_p.size(1));
  for (int32_T k{0}; k < loop_ub; k++) {
    out[k] = f_p[k];
  }
  st.site = &ib_emlrtRSI;
  idx.set_size(&t_emlrtRTEI, &st, f_p.size(1));
  nxout = (f_p.size(1) / 4) << 2;
  k0 = nxout - 4;
  for (int32_T k{0}; k <= k0; k += 4) {
    _mm_storeu_si128(
        (__m128i *)&idx[k],
        _mm_add_epi32(_mm_add_epi32(_mm_set1_epi32(k),
                                    _mm_loadu_si128((const __m128i *)&iv[0])),
                      _mm_set1_epi32(1)));
  }
  for (int32_T k{nxout}; k < loop_ub; k++) {
    idx[k] = k + 1;
  }
  b_st.site = &v_emlrtRSI;
  f_p_not_empty = true;
  nxout = 0;
  while (nxout <= f_p.size(1) - 1) {
    if (idx[nxout] > f_p.size(1)) {
      f_p_not_empty = false;
      break;
    } else {
      nxout++;
    }
  }
  if (!f_p_not_empty) {
    emlrtErrorWithMessageIdR2018a(&b_st, &c_emlrtRTEI,
                                  "MATLAB:subsdeldimmismatch",
                                  "MATLAB:subsdeldimmismatch", 0);
  }
  b_st.site = &w_emlrtRSI;
  c_st.site = &x_emlrtRSI;
  b.set_size(&t_emlrtRTEI, &c_st, 1, f_p.size(1));
  if (loop_ub - 1 >= 0) {
    std::memset(&b[0], 0, static_cast<uint32_T>(loop_ub) * sizeof(boolean_T));
  }
  d_st.site = &bb_emlrtRSI;
  if (f_p.size(1) > 2147483646) {
    e_st.site = &cb_emlrtRSI;
    emlrtErrorWithMessageIdR2018a(
        &e_st, &e_emlrtRTEI, "Coder:toolbox:int_forloop_overflow",
        "Coder:toolbox:int_forloop_overflow", 3, 4, 5, "int32");
  }
  for (int32_T k{0}; k < loop_ub; k++) {
    b[idx[k] - 1] = true;
  }
  c_st.site = &y_emlrtRSI;
  nxout = 0;
  d_st.site = &db_emlrtRSI;
  if (b.size(1) > 2147483646) {
    e_st.site = &cb_emlrtRSI;
    emlrtErrorWithMessageIdR2018a(
        &e_st, &e_emlrtRTEI, "Coder:toolbox:int_forloop_overflow",
        "Coder:toolbox:int_forloop_overflow", 3, 4, 5, "int32");
  }
  for (int32_T k{0}; k < loop_ub; k++) {
    nxout += b[k];
  }
  nxout = f_p.size(1) - nxout;
  k0 = -1;
  c_st.site = &ab_emlrtRSI;
  if (f_p.size(1) > 2147483646) {
    d_st.site = &cb_emlrtRSI;
    emlrtErrorWithMessageIdR2018a(
        &d_st, &e_emlrtRTEI, "Coder:toolbox:int_forloop_overflow",
        "Coder:toolbox:int_forloop_overflow", 3, 4, 5, "int32");
  }
  for (int32_T k{0}; k < loop_ub; k++) {
    if ((k + 1 > b.size(1)) || !b[k]) {
      k0++;
      f_p[k0] = f_p[k];
    }
  }
  if (nxout > f_p.size(1)) {
    emlrtErrorWithMessageIdR2018a(&b_st, &i_emlrtRTEI,
                                  "Coder:builtins:AssertionFailed",
                                  "Coder:builtins:AssertionFailed", 0);
  }
  if (nxout < 1) {
    nxout = 0;
  }
  f_p.set_size(&t_emlrtRTEI, &b_st, f_p.size(0), nxout);
  f_p_not_empty = (f_p.size(1) != 0);
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

static void pred_y_TB_logger(const emlrtStack &sp, int16_T v)
{
  if (!f_p_not_empty) {
    f_p.set_size(&t_emlrtRTEI, &sp, 1, 1);
    f_p[0] = v;
    f_p_not_empty = true;
  } else {
    int32_T i;
    i = f_p.size(1);
    f_p.set_size(&t_emlrtRTEI, &sp, f_p.size(0), f_p.size(1) + 1);
    f_p[i] = v;
  }
}

static void w_TB_logger(const emlrtStack &sp, array<int16_T, 1U> &out)
{
  array<int32_T, 1U> r;
  emlrtStack st;
  int32_T loop_ub;
  int32_T scalarLB;
  int32_T vectorUB;
  st.prev = &sp;
  st.tls = sp.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  if (!b_p_not_empty) {
    emlrtErrorWithMessageIdR2018a(&sp, &f_emlrtRTEI,
                                  "Coder:builtins:AssertionFailed",
                                  "Coder:builtins:AssertionFailed", 0);
  }
  loop_ub = b_p.size(0);
  out.set_size(&p_emlrtRTEI, &sp, b_p.size(0));
  for (int32_T i{0}; i < loop_ub; i++) {
    out[i] = b_p[i];
  }
  r.set_size(&p_emlrtRTEI, &sp, b_p.size(0));
  scalarLB = (b_p.size(0) / 4) << 2;
  vectorUB = scalarLB - 4;
  for (int32_T i{0}; i <= vectorUB; i += 4) {
    _mm_storeu_si128(
        (__m128i *)&r[i],
        _mm_add_epi32(_mm_add_epi32(_mm_set1_epi32(i),
                                    _mm_loadu_si128((const __m128i *)&iv[0])),
                      _mm_set1_epi32(1)));
  }
  for (int32_T i{scalarLB}; i < loop_ub; i++) {
    r[i] = i + 1;
  }
  st.site = &eb_emlrtRSI;
  internal::nullAssignment(st, b_p, r);
  b_p_not_empty = (b_p.size(0) != 0);
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

static void w_TB_logger(const emlrtStack &sp, const int16_T v[4])
{
  if (!b_p_not_empty) {
    b_p.set_size(&p_emlrtRTEI, &sp, 4);
    b_p[0] = v[0];
    b_p[1] = v[1];
    b_p[2] = v[2];
    b_p[3] = v[3];
    b_p_not_empty = true;
  } else {
    int32_T i;
    i = b_p.size(0);
    b_p.set_size(&p_emlrtRTEI, &sp, b_p.size(0) + 4);
    b_p[i] = v[0];
    b_p[i + 1] = v[1];
    b_p[i + 2] = v[2];
    b_p[i + 3] = v[3];
  }
}

static void w_next_TB_logger(const emlrtStack &sp, const int16_T v[4])
{
  if (!h_p_not_empty) {
    h_p.set_size(&v_emlrtRTEI, &sp, 4);
    h_p[0] = v[0];
    h_p[1] = v[1];
    h_p[2] = v[2];
    h_p[3] = v[3];
    h_p_not_empty = true;
  } else {
    int32_T i;
    i = h_p.size(0);
    h_p.set_size(&v_emlrtRTEI, &sp, h_p.size(0) + 4);
    h_p[i] = v[0];
    h_p[i + 1] = v[1];
    h_p[i + 2] = v[2];
    h_p[i + 3] = v[3];
  }
}

static void w_next_TB_logger(const emlrtStack &sp, array<int16_T, 1U> &out)
{
  array<int32_T, 1U> r;
  emlrtStack st;
  int32_T loop_ub;
  int32_T scalarLB;
  int32_T vectorUB;
  st.prev = &sp;
  st.tls = sp.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  if (!h_p_not_empty) {
    emlrtErrorWithMessageIdR2018a(&sp, &m_emlrtRTEI,
                                  "Coder:builtins:AssertionFailed",
                                  "Coder:builtins:AssertionFailed", 0);
  }
  loop_ub = h_p.size(0);
  out.set_size(&v_emlrtRTEI, &sp, h_p.size(0));
  for (int32_T i{0}; i < loop_ub; i++) {
    out[i] = h_p[i];
  }
  r.set_size(&v_emlrtRTEI, &sp, h_p.size(0));
  scalarLB = (h_p.size(0) / 4) << 2;
  vectorUB = scalarLB - 4;
  for (int32_T i{0}; i <= vectorUB; i += 4) {
    _mm_storeu_si128(
        (__m128i *)&r[i],
        _mm_add_epi32(_mm_add_epi32(_mm_set1_epi32(i),
                                    _mm_loadu_si128((const __m128i *)&iv[0])),
                      _mm_set1_epi32(1)));
  }
  for (int32_T i{scalarLB}; i < loop_ub; i++) {
    r[i] = i + 1;
  }
  st.site = &kb_emlrtRSI;
  internal::nullAssignment(st, h_p, r);
  h_p_not_empty = (h_p.size(0) != 0);
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

static void x_history_TB_logger(const emlrtStack &sp, array<int16_T, 1U> &out)
{
  array<int32_T, 1U> idx;
  array<boolean_T, 2U> b;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack e_st;
  emlrtStack st;
  int32_T k0;
  int32_T loop_ub;
  int32_T nxout;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  e_st.prev = &d_st;
  e_st.tls = d_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  if (!p_not_empty) {
    emlrtErrorWithMessageIdR2018a(&sp, &b_emlrtRTEI,
                                  "Coder:builtins:AssertionFailed",
                                  "Coder:builtins:AssertionFailed", 0);
  }
  loop_ub = p.size(0);
  out.set_size(&o_emlrtRTEI, &sp, p.size(0));
  for (int32_T k{0}; k < loop_ub; k++) {
    out[k] = p[k];
  }
  st.site = &u_emlrtRSI;
  idx.set_size(&o_emlrtRTEI, &st, p.size(0));
  nxout = (p.size(0) / 4) << 2;
  k0 = nxout - 4;
  for (int32_T k{0}; k <= k0; k += 4) {
    _mm_storeu_si128(
        (__m128i *)&idx[k],
        _mm_add_epi32(_mm_add_epi32(_mm_set1_epi32(k),
                                    _mm_loadu_si128((const __m128i *)&iv[0])),
                      _mm_set1_epi32(1)));
  }
  for (int32_T k{nxout}; k < loop_ub; k++) {
    idx[k] = k + 1;
  }
  b_st.site = &v_emlrtRSI;
  p_not_empty = true;
  nxout = 0;
  while (nxout <= p.size(0) - 1) {
    if (idx[nxout] > p.size(0)) {
      p_not_empty = false;
      break;
    } else {
      nxout++;
    }
  }
  if (!p_not_empty) {
    emlrtErrorWithMessageIdR2018a(&b_st, &c_emlrtRTEI,
                                  "MATLAB:subsdeldimmismatch",
                                  "MATLAB:subsdeldimmismatch", 0);
  }
  b_st.site = &w_emlrtRSI;
  c_st.site = &x_emlrtRSI;
  b.set_size(&o_emlrtRTEI, &c_st, 1, p.size(0));
  if (loop_ub - 1 >= 0) {
    std::memset(&b[0], 0, static_cast<uint32_T>(loop_ub) * sizeof(boolean_T));
  }
  d_st.site = &bb_emlrtRSI;
  if (p.size(0) > 2147483646) {
    e_st.site = &cb_emlrtRSI;
    emlrtErrorWithMessageIdR2018a(
        &e_st, &e_emlrtRTEI, "Coder:toolbox:int_forloop_overflow",
        "Coder:toolbox:int_forloop_overflow", 3, 4, 5, "int32");
  }
  for (int32_T k{0}; k < loop_ub; k++) {
    b[idx[k] - 1] = true;
  }
  c_st.site = &y_emlrtRSI;
  nxout = 0;
  d_st.site = &db_emlrtRSI;
  if (b.size(1) > 2147483646) {
    e_st.site = &cb_emlrtRSI;
    emlrtErrorWithMessageIdR2018a(
        &e_st, &e_emlrtRTEI, "Coder:toolbox:int_forloop_overflow",
        "Coder:toolbox:int_forloop_overflow", 3, 4, 5, "int32");
  }
  for (int32_T k{0}; k < loop_ub; k++) {
    nxout += b[k];
  }
  nxout = p.size(0) - nxout;
  k0 = -1;
  c_st.site = &ab_emlrtRSI;
  if (p.size(0) > 2147483646) {
    d_st.site = &cb_emlrtRSI;
    emlrtErrorWithMessageIdR2018a(
        &d_st, &e_emlrtRTEI, "Coder:toolbox:int_forloop_overflow",
        "Coder:toolbox:int_forloop_overflow", 3, 4, 5, "int32");
  }
  for (int32_T k{0}; k < loop_ub; k++) {
    if ((k + 1 > b.size(1)) || !b[k]) {
      k0++;
      p[k0] = p[k];
    }
  }
  if (nxout > p.size(0)) {
    emlrtErrorWithMessageIdR2018a(&b_st, &d_emlrtRTEI,
                                  "Coder:builtins:AssertionFailed",
                                  "Coder:builtins:AssertionFailed", 0);
  }
  if (nxout < 1) {
    nxout = 0;
  }
  p.set_size(&o_emlrtRTEI, &b_st, nxout);
  p_not_empty = (p.size(0) != 0);
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

static void x_history_TB_logger(const emlrtStack &sp, const int16_T v[4])
{
  if (!p_not_empty) {
    p.set_size(&o_emlrtRTEI, &sp, 4);
    p[0] = v[0];
    p[1] = v[1];
    p[2] = v[2];
    p[3] = v[3];
    p_not_empty = true;
  } else {
    int32_T i;
    i = p.size(0);
    p.set_size(&o_emlrtRTEI, &sp, p.size(0) + 4);
    p[i] = v[0];
    p[i + 1] = v[1];
    p[i + 2] = v[2];
    p[i + 3] = v[3];
  }
}

} // namespace coder
void b_TB_logger_emx_free()
{
}

void b_TB_logger_emx_init()
{
}

void b_TB_logger_init()
{
  c_p_not_empty = false;
}

void b_next_TB_logger_emx_free()
{
}

void b_next_TB_logger_emx_init()
{
}

void b_next_TB_logger_init()
{
  i_p_not_empty = false;
}

void c_adaptive_neuron_fixpt_logger_()
{
  iterCount = 0.0;
  iterCount_not_empty = true;
}

namespace coder {
void adaptive_neuron_fixpt_logger(const emlrtStack *sp, struct0_T *loggedData)
{
  emlrtStack st;
  st.prev = sp;
  st.tls = sp->tls;
  if (!iterCount_not_empty) {
    emlrtErrorWithMessageIdR2018a(sp, &emlrtRTEI,
                                  "Coder:builtins:AssertionFailed",
                                  "Coder:builtins:AssertionFailed", 0);
  }
  st.site = &l_emlrtRSI;
  x_history_TB_logger(st, loggedData->inputs.x_history);
  st.site = &m_emlrtRSI;
  w_TB_logger(st, loggedData->inputs.w);
  st.site = &n_emlrtRSI;
  b_TB_logger(st, loggedData->inputs.b);
  st.site = &o_emlrtRSI;
  current_val_TB_logger(st, loggedData->inputs.current_val);
  st.site = &p_emlrtRSI;
  mu_TB_logger(st, loggedData->inputs.mu);
  st.site = &q_emlrtRSI;
  pred_y_TB_logger(st, loggedData->outputs.pred_y);
  st.site = &r_emlrtRSI;
  error_e_TB_logger(st, loggedData->outputs.error_e);
  st.site = &s_emlrtRSI;
  w_next_TB_logger(st, loggedData->outputs.w_next);
  st.site = &t_emlrtRSI;
  b_next_TB_logger(st, loggedData->outputs.b_next);
  loggedData->iterCount = iterCount;
}

void b_adaptive_neuron_fixpt_logger(
    const emlrtStack &sp, const int16_T varargin_1[4],
    const int16_T varargin_2[4], int16_T varargin_3, int16_T varargin_4,
    uint16_T varargin_5, int16_T varargin_6, int16_T varargin_7,
    const int16_T varargin_8[4], int16_T varargin_9)
{
  static const int32_T b_iv[2]{1, 30};
  static const int32_T iv1[2]{1, 34};
  static const char_T b_u[34]{'R', 'e', 't', 'u', 'r', 'n', ' ', 'e', 'a',
                              'r', 'l', 'y', ' ', 'f', 'o', 'r', ' ', 'i',
                              'n', 'p', 'u', 't', ' ', 'c', 'o', 'm', 'p',
                              'u', 't', 'a', 't', 'i', 'o', 'n'};
  static const char_T u[30]{'C', 'o', 'd', 'e', 'r', ':', 'F', 'X', 'P', 'C',
                            'O', 'N', 'V', ':', 'M', 'A', 'T', 'L', 'A', 'B',
                            'S', 'i', 'm', 'B', 'a', 'i', 'l', 'O', 'u', 't'};
  emlrtStack st;
  const mxArray *b_y;
  const mxArray *m;
  const mxArray *y;
  st.prev = &sp;
  st.tls = sp.tls;
  st.site = &c_emlrtRSI;
  x_history_TB_logger(st, varargin_1);
  st.site = &d_emlrtRSI;
  w_TB_logger(st, varargin_2);
  st.site = &e_emlrtRSI;
  b_TB_logger(st, varargin_3);
  st.site = &f_emlrtRSI;
  current_val_TB_logger(st, varargin_4);
  st.site = &g_emlrtRSI;
  mu_TB_logger(st, varargin_5);
  st.site = &h_emlrtRSI;
  pred_y_TB_logger(st, varargin_6);
  st.site = &i_emlrtRSI;
  error_e_TB_logger(st, varargin_7);
  st.site = &j_emlrtRSI;
  w_next_TB_logger(st, varargin_8);
  st.site = &k_emlrtRSI;
  b_next_TB_logger(st, varargin_9);
  iterCount++;
  if (iterCount >= rtInf) {
    y = nullptr;
    m = emlrtCreateCharArray(2, &b_iv[0]);
    emlrtInitCharArrayR2013a((emlrtConstCTX)&sp, 30, m, &u[0]);
    emlrtAssign(&y, m);
    b_y = nullptr;
    m = emlrtCreateCharArray(2, &iv1[0]);
    emlrtInitCharArrayR2013a((emlrtConstCTX)&sp, 34, m, &b_u[0]);
    emlrtAssign(&b_y, m);
    st.site = &mb_emlrtRSI;
    b_throw(st, MException(st, y, b_y, b_emlrtMCI), c_emlrtMCI);
  }
}

} // namespace coder
void current_val_TB_logger_emx_free()
{
}

void current_val_TB_logger_emx_init()
{
}

void current_val_TB_logger_init()
{
  d_p_not_empty = false;
}

void error_e_TB_logger_emx_free()
{
}

void error_e_TB_logger_emx_init()
{
}

void error_e_TB_logger_init()
{
  g_p_not_empty = false;
}

void mu_TB_logger_emx_free()
{
}

void mu_TB_logger_emx_init()
{
}

void mu_TB_logger_init()
{
  e_p_not_empty = false;
}

void pred_y_TB_logger_emx_free()
{
}

void pred_y_TB_logger_emx_init()
{
}

void pred_y_TB_logger_init()
{
  f_p_not_empty = false;
}

void w_TB_logger_emx_free()
{
}

void w_TB_logger_emx_init()
{
}

void w_TB_logger_init()
{
  b_p_not_empty = false;
}

void w_next_TB_logger_emx_free()
{
}

void w_next_TB_logger_emx_init()
{
}

void w_next_TB_logger_init()
{
  h_p_not_empty = false;
}

void x_history_TB_logger_emx_free()
{
}

void x_history_TB_logger_emx_init()
{
}

void x_history_TB_logger_init()
{
  p_not_empty = false;
}
