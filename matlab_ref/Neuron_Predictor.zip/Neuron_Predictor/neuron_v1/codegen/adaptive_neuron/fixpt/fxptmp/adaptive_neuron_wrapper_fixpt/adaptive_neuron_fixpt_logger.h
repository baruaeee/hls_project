#pragma once

#include "adaptive_neuron_wrapper_fixpt_hdl_mex_types.h"
#include "rtwtypes.h"
#include "emlrt.h"
#include "mex.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>

void b_TB_logger_emx_free();

void b_TB_logger_emx_init();

void b_TB_logger_init();

void b_next_TB_logger_emx_free();

void b_next_TB_logger_emx_init();

void b_next_TB_logger_init();

void c_adaptive_neuron_fixpt_logger_();

namespace coder {
void adaptive_neuron_fixpt_logger(const emlrtStack *sp, struct0_T *loggedData);

void b_adaptive_neuron_fixpt_logger(
    const emlrtStack &sp, const int16_T varargin_1[4],
    const int16_T varargin_2[4], int16_T varargin_3, int16_T varargin_4,
    uint16_T varargin_5, int16_T varargin_6, int16_T varargin_7,
    const int16_T varargin_8[4], int16_T varargin_9);

} // namespace coder
void current_val_TB_logger_emx_free();

void current_val_TB_logger_emx_init();

void current_val_TB_logger_init();

void error_e_TB_logger_emx_free();

void error_e_TB_logger_emx_init();

void error_e_TB_logger_init();

void mu_TB_logger_emx_free();

void mu_TB_logger_emx_init();

void mu_TB_logger_init();

void pred_y_TB_logger_emx_free();

void pred_y_TB_logger_emx_init();

void pred_y_TB_logger_init();

void w_TB_logger_emx_free();

void w_TB_logger_emx_init();

void w_TB_logger_init();

void w_next_TB_logger_emx_free();

void w_next_TB_logger_emx_init();

void w_next_TB_logger_init();

void x_history_TB_logger_emx_free();

void x_history_TB_logger_emx_init();

void x_history_TB_logger_init();
