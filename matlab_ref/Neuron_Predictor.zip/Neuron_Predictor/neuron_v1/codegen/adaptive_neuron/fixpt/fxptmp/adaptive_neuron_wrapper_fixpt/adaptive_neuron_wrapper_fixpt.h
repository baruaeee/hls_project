#pragma once

#include "rtwtypes.h"
#include "emlrt.h"
#include "mex.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>

void adaptive_neuron_wrapper_fixpt(const emlrtStack *sp,
                                   const real_T x_history[4], const real_T w[4],
                                   real_T b, real_T current_val, real_T mu,
                                   real_T *pred_y, real_T *error_e,
                                   real_T w_next[4], real_T *b_next);
