#include "_coder_adaptive_neuron_wrapper_fixpt_hdl_mex_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

static const mxArray *c_emlrtMexFcnResolvedFunctionsI();

static const mxArray *c_emlrtMexFcnResolvedFunctionsI()
{
  const mxArray *nameCaptureInfo;
  const char_T *data[8]{
      "789ced59bd731241145f2e2493980f49a152e84c2ac72a28162625811849c0c440248ee3"
      "1c27b79033dc87c781c1c24999ce745a5afa27a4b4f44fb0b1f74f70"
      "ac3ce0168e37bcece503c290db9965efed6feffdde7bbbf776872581643a40089923ad72"
      "106eb5b38e1c725a81741788079c36086456c61d6416e09f9db6a06b",
      "163db05a8226a9b4fda6a219552b5b3768c5164c5ad1cb352a3791a252a65945a519b7f0"
      "bc21a94f5d505b68408de7f81e2dec67aa2a31f72a1d0bcb6ea11d8f"
      "3ce26f90741788c302e301c731bec373f231fdf7387c0c9764c9b0941a15355a35754dfc"
      "604a86414db1a81c1896cb9e5f08df3cd00ff9028ec5e9f866a6254f",
      "34e58a652a5ac9b5de10fd4c26083e0178213fc3c39daedf8233ce5d991d3f111eaf7197"
      "103b42007fbdfa26928e6553b195858469c73f92902c31aeab8698a0"
      "05bb89d41e450aba4c4b548b80398a34e706f676cfdca2eaf0f0d6ef4d8f7e61f19d2593"
      "cd7637f5efdd20f958b92e7cd8f7e1755dde46f842004fbeafd7e3eb",
      "b142746b23b7b659df4e6793d19dd58e1d5b1c1e9e1d049107a57f54bfef8bae8f5b1cbf"
      "180eadba2efb047b6676fc4078bcc6fb15624708e097bf8efcfd6114"
      "f906b53f2cab566a2359dd595f5bce55569ec88f93aab5f56c74f6873cf2feb09ef3ef72"
      "f818de330b8865bd54a2a6db9e51cddf63e472cff925c48e10c02f9e",
      "bf8bf68f3deeb409b4b3f9a0f2ce974f7e1eef27dfa0ce71397d3915cd7c5cdd96e5fd64"
      "ec45e2e5be1aad113f8fc3e2e7f1e1cae341e2e7712f7ef979fc6af9"
      "fc3c7e39fac333bddf9ff2a8ff64bab77e01e004dc7f1cdde8add7ebfd07b65ed8fdc714"
      "c099ccf22e2bcc9ebf53bdf9ce9ecfbbf534ee4172ce3f4ba28bef08",
      "e1e3cd2bf40b9bd7af81d3dfc7f42f054ed72f807141a76fc9aebb76fd66d7b08d2db8ea"
      "03bb4a5abdbdc76105ce3de36715cab0c27b87319caacb2fec5940fa"
      "c7907e987b20df43d7e0398033f98fd39e378fce03198e3f02b800e471a79df0d8ca4427"
      "55f29694093df3b3dbef30b25ebdfa7d87e3f78947bfa73db694a8b6",
      "170d7fe4e6ef222912a56fbd9d381d5f304ef73971626b148b13cb1f5ee3345c71ecfffc"
      "1c22f1f73a3fd8bd3e1bbf0070383facb4cf0fc87ae1ed33502fa6df"
      "e0bc8fe9e79d4fd83e3eecfc7944ff0c879f17df71e4dcebcf677ff927cf796e62fabe23"
      "fa0580c3f3f031a2f7aacec3acfc075590da80",
      ""};
  nameCaptureInfo = nullptr;
  emlrtNameCaptureMxArrayR2016a(&data[0], 9400U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties()
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *epFieldName[7]{
      "QualifiedName",    "NumberOfInputs", "NumberOfOutputs", "ConstantInputs",
      "ResolvedFilePath", "TimeStamp",      "Visible"};
  const char_T *propFieldName[7]{
      "Version",      "ResolvedFunctions", "Checksum", "EntryPoints",
      "CoverageInfo", "IsPolymorphic",     "AuxData"};
  uint8_T v[216]{
      0U,   1U,   73U,  77U,  0U,   0U,   0U,   0U,   14U,  0U,   0U,   0U,
      200U, 0U,   0U,   0U,   6U,   0U,   0U,   0U,   8U,   0U,   0U,   0U,
      2U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,   5U,   0U,   0U,   0U,
      8U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,
      1U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,   5U,   0U,   4U,   0U,
      17U,  0U,   0U,   0U,   1U,   0U,   0U,   0U,   17U,  0U,   0U,   0U,
      67U,  108U, 97U,  115U, 115U, 69U,  110U, 116U, 114U, 121U, 80U,  111U,
      105U, 110U, 116U, 115U, 0U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,
      14U,  0U,   0U,   0U,   112U, 0U,   0U,   0U,   6U,   0U,   0U,   0U,
      8U,   0U,   0U,   0U,   2U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,
      5U,   0U,   0U,   0U,   8U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,
      0U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,
      5U,   0U,   4U,   0U,   14U,  0U,   0U,   0U,   1U,   0U,   0U,   0U,
      56U,  0U,   0U,   0U,   81U,  117U, 97U,  108U, 105U, 102U, 105U, 101U,
      100U, 78U,  97U,  109U, 101U, 0U,   77U,  101U, 116U, 104U, 111U, 100U,
      115U, 0U,   0U,   0U,   0U,   0U,   0U,   0U,   80U,  114U, 111U, 112U,
      101U, 114U, 116U, 105U, 101U, 115U, 0U,   0U,   0U,   0U,   72U,  97U,
      110U, 100U, 108U, 101U, 0U,   0U,   0U,   0U,   0U,   0U,   0U,   0U};
  xEntryPoints =
      emlrtCreateStructMatrix(1, 2, 7, (const char_T **)&epFieldName[0]);
  xInputs = emlrtCreateLogicalMatrix(1, 5);
  emlrtSetField(xEntryPoints, 0, "QualifiedName",
                emlrtMxCreateString("adaptive_neuron_wrapper_fixpt"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(5.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(4.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 0, "ResolvedFilePath",
      emlrtMxCreateString("/MATLAB "
                          "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/"
                          "fixpt/adaptive_neuron_wrapper_fixpt.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp",
                emlrtMxCreateDoubleScalar(740302.0143518519));
  emlrtSetField(xEntryPoints, 0, "Visible", emlrtMxCreateLogicalScalar(true));
  xInputs = emlrtCreateLogicalMatrix(1, 0);
  emlrtSetField(xEntryPoints, 1, "QualifiedName",
                emlrtMxCreateString("adaptive_neuron_fixpt_logger"));
  emlrtSetField(xEntryPoints, 1, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 1, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 1, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 1, "ResolvedFilePath",
      emlrtMxCreateString("/MATLAB "
                          "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/"
                          "fixpt/fxptmp/adaptive_neuron_fixpt_logger.m"));
  emlrtSetField(xEntryPoints, 1, "TimeStamp",
                emlrtMxCreateDoubleScalar(740302.1632291666));
  emlrtSetField(xEntryPoints, 1, "Visible", emlrtMxCreateLogicalScalar(true));
  xResult =
      emlrtCreateStructMatrix(1, 1, 7, (const char_T **)&propFieldName[0]);
  emlrtSetField(xResult, 0, "Version",
                emlrtMxCreateString("26.2.0.3437455 (R2026b) Update 2"));
  emlrtSetField(xResult, 0, "ResolvedFunctions",
                (mxArray *)c_emlrtMexFcnResolvedFunctionsI());
  emlrtSetField(xResult, 0, "Checksum",
                emlrtMxCreateString("vGYRzA8C5XXyiNU2pHIFtD"));
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  emlrtSetField(xResult, 0, "AuxData",
                emlrtMxCreateRowVectorUINT8((const uint8_T *)&v, 216U));
  return xResult;
}
