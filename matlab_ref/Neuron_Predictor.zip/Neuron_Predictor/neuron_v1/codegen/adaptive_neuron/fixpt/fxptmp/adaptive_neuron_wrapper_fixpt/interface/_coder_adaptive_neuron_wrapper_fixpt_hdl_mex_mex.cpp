#include "_coder_adaptive_neuron_wrapper_fixpt_hdl_mex_mex.h"
#include "_coder_adaptive_neuron_wrapper_fixpt_hdl_mex_api.h"
#include "adaptive_neuron_wrapper_fixpt_hdl_mex_data.h"
#include "adaptive_neuron_wrapper_fixpt_hdl_mex_initialize.h"
#include "adaptive_neuron_wrapper_fixpt_hdl_mex_terminate.h"
#include "rt_nonfinite.h"
#include <stdexcept>

void emlrtExceptionBridge();
void emlrtExceptionBridge()
{
  throw std::runtime_error("");
}
void adaptive_neuron_fixpt_logger_mexFunction(int32_T nlhs, mxArray *plhs[1],
                                              int32_T nrhs)
{
  emlrtStack st{nullptr, nullptr, nullptr};
  const mxArray *outputs;
  st.tls = emlrtRootTLSGlobal;

  if (nrhs != 0) {
    emlrtErrMsgIdAndTxt(&st, "EMLRT:runTime:WrongNumberOfInputs", 5, 12, 0, 4,
                        28, "adaptive_neuron_fixpt_logger");
  }
  if (nlhs > 1) {
    emlrtErrMsgIdAndTxt(&st, "EMLRT:runTime:TooManyOutputArguments", 3, 4, 28,
                        "adaptive_neuron_fixpt_logger");
  }

  d_adaptive_neuron_fixpt_logger_(&outputs);

  emlrtReturnArrays(1, &plhs[0], &outputs);
}

void adaptive_neuron_wrapper_fixpt_mexFunction(int32_T nlhs, mxArray *plhs[4],
                                               int32_T nrhs,
                                               const mxArray *prhs[5])
{
  emlrtStack st{nullptr, nullptr, nullptr};
  const mxArray *outputs[4];
  int32_T i;
  st.tls = emlrtRootTLSGlobal;

  if (nrhs != 5) {
    emlrtErrMsgIdAndTxt(&st, "EMLRT:runTime:WrongNumberOfInputs", 5, 12, 5, 4,
                        29, "adaptive_neuron_wrapper_fixpt");
  }
  if (nlhs > 4) {
    emlrtErrMsgIdAndTxt(&st, "EMLRT:runTime:TooManyOutputArguments", 3, 4, 29,
                        "adaptive_neuron_wrapper_fixpt");
  }

  d_adaptive_neuron_wrapper_fixpt(prhs, nlhs, outputs);

  if (nlhs < 1) {
    i = 1;
  } else {
    i = nlhs;
  }
  emlrtReturnArrays(i, &plhs[0], &outputs[0]);
}

void mexFunction(int32_T nlhs, mxArray *plhs[], int32_T nrhs,
                 const mxArray *prhs[])
{
  emlrtStack st{nullptr, nullptr, nullptr};
  const char_T *entryPointTemplateNames[2]{"adaptive_neuron_wrapper_fixpt",
                                           "adaptive_neuron_fixpt_logger"};
  mexAtExit(&adaptive_neuron_wrapper_fixpt_hdl_mex_atexit);
  adaptive_neuron_wrapper_fixpt_hdl_mex_initialize();
  st.tls = emlrtRootTLSGlobal;
  try {
    switch (emlrtGetEntryPointIndexR2016a(
        &st, nrhs, &prhs[0], (const char_T **)&entryPointTemplateNames[0], 2)) {
    case 0:
      adaptive_neuron_wrapper_fixpt_mexFunction(nlhs, plhs, nrhs - 1, &prhs[1]);
      break;
    case 1:
      adaptive_neuron_fixpt_logger_mexFunction(nlhs, plhs, nrhs - 1);
      break;
    }
    adaptive_neuron_wrapper_fixpt_hdl_mex_terminate();
  } catch (...) {
    emlrtCleanupOnException((emlrtCTX *)emlrtRootTLSGlobal);
    throw;
  }
}

emlrtCTX mexFunctionCreateRootTLS()
{
  emlrtCreateRootTLSR2022a(&emlrtRootTLSGlobal, &emlrtContextGlobal, nullptr, 1,
                           (void *)&emlrtExceptionBridge, "UTF-8", true);
  return emlrtRootTLSGlobal;
}
