#include "adaptive_neuron_wrapper_fixpt.h"
#include "adaptive_neuron_fixpt_logger.h"
#include "rt_nonfinite.h"
#include "mwmathutil.h"

static emlrtRSInfo emlrtRSI{13, "adaptive_neuron_wrapper_fixpt",
                            "/MATLAB "
                            "Drive/Dat_Comp_Decomp/v1/codegen/adaptive_neuron/"
                            "fixpt/adaptive_neuron_wrapper_fixpt.m"};

static emlrtRSInfo b_emlrtRSI{5, "adaptive_neuron_fixpt_input_output_logger",
                              "src/LogInputsAndOutputs.cpp:55"};

void adaptive_neuron_wrapper_fixpt(const emlrtStack *sp,
                                   const real_T x_history[4], const real_T w[4],
                                   real_T b, real_T current_val, real_T mu,
                                   real_T *pred_y, real_T *error_e,
                                   real_T w_next[4], real_T *b_next)
{
  emlrtStack b_st;
  emlrtStack st;
  int64_T a1_idx_0;
  int64_T a1_idx_1;
  int64_T a1_idx_2;
  int64_T a1_idx_3;
  int64_T c1_idx_0;
  int64_T c1_idx_1;
  real_T d;
  int32_T w_next_tmp;
  int16_T w_in[4];
  int16_T w_next_out[4];
  int16_T x_history_in[4];
  int16_T b_b;
  int16_T b_current_val;
  int16_T b_next_out;
  int16_T error_e_out;
  int16_T pred_y_out;
  uint16_T b_mu;
  uint16_T y;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  d = muDoubleScalarFloor(x_history[0] * 8192.0);
  if (muDoubleScalarIsNaN(d) || muDoubleScalarIsInf(d)) {
    d = 0.0;
  } else {
    d = muDoubleScalarRem(d, 16384.0);
  }
  if (static_cast<uint16_T>(static_cast<uint16_T>(static_cast<int16_T>(d)) &
                            8192) != 0) {
    x_history_in[0] = static_cast<int16_T>(static_cast<int16_T>(d) | -8192);
  } else {
    x_history_in[0] = static_cast<int16_T>(
        static_cast<uint16_T>(static_cast<int16_T>(d)) & 8191);
  }
  d = muDoubleScalarFloor(w[0] * 1024.0);
  if (muDoubleScalarIsNaN(d) || muDoubleScalarIsInf(d)) {
    d = 0.0;
  } else {
    d = muDoubleScalarRem(d, 16384.0);
  }
  if (static_cast<uint16_T>(static_cast<uint16_T>(static_cast<int16_T>(d)) &
                            8192) != 0) {
    w_in[0] = static_cast<int16_T>(static_cast<int16_T>(d) | -8192);
  } else {
    w_in[0] = static_cast<int16_T>(
        static_cast<uint16_T>(static_cast<int16_T>(d)) & 8191);
  }
  d = muDoubleScalarFloor(x_history[1] * 8192.0);
  if (muDoubleScalarIsNaN(d) || muDoubleScalarIsInf(d)) {
    d = 0.0;
  } else {
    d = muDoubleScalarRem(d, 16384.0);
  }
  if (static_cast<uint16_T>(static_cast<uint16_T>(static_cast<int16_T>(d)) &
                            8192) != 0) {
    x_history_in[1] = static_cast<int16_T>(static_cast<int16_T>(d) | -8192);
  } else {
    x_history_in[1] = static_cast<int16_T>(
        static_cast<uint16_T>(static_cast<int16_T>(d)) & 8191);
  }
  d = muDoubleScalarFloor(w[1] * 1024.0);
  if (muDoubleScalarIsNaN(d) || muDoubleScalarIsInf(d)) {
    d = 0.0;
  } else {
    d = muDoubleScalarRem(d, 16384.0);
  }
  if (static_cast<uint16_T>(static_cast<uint16_T>(static_cast<int16_T>(d)) &
                            8192) != 0) {
    w_in[1] = static_cast<int16_T>(static_cast<int16_T>(d) | -8192);
  } else {
    w_in[1] = static_cast<int16_T>(
        static_cast<uint16_T>(static_cast<int16_T>(d)) & 8191);
  }
  d = muDoubleScalarFloor(x_history[2] * 8192.0);
  if (muDoubleScalarIsNaN(d) || muDoubleScalarIsInf(d)) {
    d = 0.0;
  } else {
    d = muDoubleScalarRem(d, 16384.0);
  }
  if (static_cast<uint16_T>(static_cast<uint16_T>(static_cast<int16_T>(d)) &
                            8192) != 0) {
    x_history_in[2] = static_cast<int16_T>(static_cast<int16_T>(d) | -8192);
  } else {
    x_history_in[2] = static_cast<int16_T>(
        static_cast<uint16_T>(static_cast<int16_T>(d)) & 8191);
  }
  d = muDoubleScalarFloor(w[2] * 1024.0);
  if (muDoubleScalarIsNaN(d) || muDoubleScalarIsInf(d)) {
    d = 0.0;
  } else {
    d = muDoubleScalarRem(d, 16384.0);
  }
  if (static_cast<uint16_T>(static_cast<uint16_T>(static_cast<int16_T>(d)) &
                            8192) != 0) {
    w_in[2] = static_cast<int16_T>(static_cast<int16_T>(d) | -8192);
  } else {
    w_in[2] = static_cast<int16_T>(
        static_cast<uint16_T>(static_cast<int16_T>(d)) & 8191);
  }
  d = muDoubleScalarFloor(x_history[3] * 8192.0);
  if (muDoubleScalarIsNaN(d) || muDoubleScalarIsInf(d)) {
    d = 0.0;
  } else {
    d = muDoubleScalarRem(d, 16384.0);
  }
  if (static_cast<uint16_T>(static_cast<uint16_T>(static_cast<int16_T>(d)) &
                            8192) != 0) {
    x_history_in[3] = static_cast<int16_T>(static_cast<int16_T>(d) | -8192);
  } else {
    x_history_in[3] = static_cast<int16_T>(
        static_cast<uint16_T>(static_cast<int16_T>(d)) & 8191);
  }
  d = muDoubleScalarFloor(w[3] * 1024.0);
  if (muDoubleScalarIsNaN(d) || muDoubleScalarIsInf(d)) {
    d = 0.0;
  } else {
    d = muDoubleScalarRem(d, 16384.0);
  }
  if (static_cast<uint16_T>(static_cast<uint16_T>(static_cast<int16_T>(d)) &
                            8192) != 0) {
    w_in[3] = static_cast<int16_T>(static_cast<int16_T>(d) | -8192);
  } else {
    w_in[3] = static_cast<int16_T>(
        static_cast<uint16_T>(static_cast<int16_T>(d)) & 8191);
  }
  d = muDoubleScalarFloor(b * 4096.0);
  if (muDoubleScalarIsNaN(d) || muDoubleScalarIsInf(d)) {
    d = 0.0;
  } else {
    d = muDoubleScalarRem(d, 16384.0);
  }
  if (static_cast<uint16_T>(static_cast<uint16_T>(static_cast<int16_T>(d)) &
                            8192) != 0) {
    b_b = static_cast<int16_T>(static_cast<int16_T>(d) | -8192);
  } else {
    b_b = static_cast<int16_T>(static_cast<uint16_T>(static_cast<int16_T>(d)) &
                               8191);
  }
  d = muDoubleScalarFloor(current_val * 8192.0);
  if (muDoubleScalarIsNaN(d) || muDoubleScalarIsInf(d)) {
    d = 0.0;
  } else {
    d = muDoubleScalarRem(d, 16384.0);
  }
  if (static_cast<uint16_T>(static_cast<uint16_T>(static_cast<int16_T>(d)) &
                            8192) != 0) {
    b_current_val = static_cast<int16_T>(static_cast<int16_T>(d) | -8192);
  } else {
    b_current_val = static_cast<int16_T>(
        static_cast<uint16_T>(static_cast<int16_T>(d)) & 8191);
  }
  d = muDoubleScalarFloor(mu * 16384.0);
  if (muDoubleScalarIsNaN(d) || muDoubleScalarIsInf(d)) {
    d = 0.0;
  } else {
    d = muDoubleScalarRem(d, 16384.0);
  }
  b_mu = static_cast<uint16_T>(static_cast<uint16_T>(static_cast<int16_T>(d)) &
                               16383);
  st.site = &emlrtRSI;
  b_next_out = static_cast<int16_T>(
      (((b_b >> 1) << 12) + x_history_in[0] * w_in[0]) >> 12);
  if (static_cast<uint16_T>(static_cast<uint16_T>(b_next_out) & 8192) != 0) {
    w_next_tmp = b_next_out | -8192;
  } else {
    w_next_tmp =
        static_cast<uint16_T>(static_cast<uint16_T>(b_next_out) & 8191);
  }
  b_next_out = static_cast<int16_T>(
      ((w_next_tmp << 12) + x_history_in[1] * w_in[1]) >> 12);
  if (static_cast<uint16_T>(static_cast<uint16_T>(b_next_out) & 8192) != 0) {
    w_next_tmp = b_next_out | -8192;
  } else {
    w_next_tmp =
        static_cast<uint16_T>(static_cast<uint16_T>(b_next_out) & 8191);
  }
  b_next_out = static_cast<int16_T>(
      ((w_next_tmp << 12) + x_history_in[2] * w_in[2]) >> 12);
  if (static_cast<uint16_T>(static_cast<uint16_T>(b_next_out) & 8192) != 0) {
    w_next_tmp = b_next_out | -8192;
  } else {
    w_next_tmp =
        static_cast<uint16_T>(static_cast<uint16_T>(b_next_out) & 8191);
  }
  b_next_out = static_cast<int16_T>(
      ((w_next_tmp << 12) + x_history_in[3] * w_in[3]) >> 12);
  if (static_cast<uint16_T>(static_cast<uint16_T>(b_next_out) & 8192) != 0) {
    pred_y_out = static_cast<int16_T>(b_next_out | -8192);
  } else {
    pred_y_out = static_cast<int16_T>(static_cast<uint16_T>(b_next_out) & 8191);
  }
  b_next_out = static_cast<int16_T>((b_current_val - (pred_y_out << 2)) >> 1);
  if (static_cast<uint16_T>(static_cast<uint16_T>(b_next_out) & 8192) != 0) {
    error_e_out = static_cast<int16_T>(b_next_out | -8192);
  } else {
    error_e_out =
        static_cast<int16_T>(static_cast<uint16_T>(b_next_out) & 8191);
  }
  y = static_cast<uint16_T>(
      static_cast<uint32_T>(
          ((static_cast<int64_T>(((x_history_in[0] * x_history_in[0] +
                                   x_history_in[1] * x_history_in[1]) +
                                  x_history_in[2] * x_history_in[2]) +
                                 x_history_in[3] * x_history_in[3])
            << 7) +
           8589L) >>
          21) &
      16383U);
  w_next_tmp = b_mu * error_e_out;
  a1_idx_0 = static_cast<int64_T>(w_next_tmp) * x_history_in[0];
  a1_idx_1 = static_cast<int64_T>(w_next_tmp) * x_history_in[1];
  a1_idx_2 = static_cast<int64_T>(w_next_tmp) * x_history_in[2];
  a1_idx_3 = static_cast<int64_T>(w_next_tmp) * x_history_in[3];
  if (y == 0) {
    if (a1_idx_0 < 0L) {
      c1_idx_0 = -36028797018963968L;
    } else {
      c1_idx_0 = 36028797018963967L;
    }
  } else {
    a1_idx_0 = (a1_idx_0 << 12) / y;
    if ((static_cast<uint64_T>(a1_idx_0) & 36028797018963968UL) != 0UL) {
      c1_idx_0 = a1_idx_0 | -36028797018963968L;
    } else {
      c1_idx_0 = static_cast<int64_T>(static_cast<uint64_T>(a1_idx_0) &
                                      36028797018963967UL);
    }
  }
  if (y == 0) {
    if (a1_idx_1 < 0L) {
      c1_idx_1 = -36028797018963968L;
    } else {
      c1_idx_1 = 36028797018963967L;
    }
  } else {
    a1_idx_0 = (a1_idx_1 << 12) / y;
    if ((static_cast<uint64_T>(a1_idx_0) & 36028797018963968UL) != 0UL) {
      c1_idx_1 = a1_idx_0 | -36028797018963968L;
    } else {
      c1_idx_1 = static_cast<int64_T>(static_cast<uint64_T>(a1_idx_0) &
                                      36028797018963967UL);
    }
  }
  if (y == 0) {
    if (a1_idx_2 < 0L) {
      a1_idx_1 = -36028797018963968L;
    } else {
      a1_idx_1 = 36028797018963967L;
    }
  } else {
    a1_idx_0 = (a1_idx_2 << 12) / y;
    if ((static_cast<uint64_T>(a1_idx_0) & 36028797018963968UL) != 0UL) {
      a1_idx_1 = a1_idx_0 | -36028797018963968L;
    } else {
      a1_idx_1 = static_cast<int64_T>(static_cast<uint64_T>(a1_idx_0) &
                                      36028797018963967UL);
    }
  }
  if (y == 0) {
    if (a1_idx_3 < 0L) {
      a1_idx_0 = -36028797018963968L;
    } else {
      a1_idx_0 = 36028797018963967L;
    }
  } else {
    a1_idx_0 = (a1_idx_3 << 12) / y;
    if ((static_cast<uint64_T>(a1_idx_0) & 36028797018963968UL) != 0UL) {
      a1_idx_0 |= -36028797018963968L;
    } else {
      a1_idx_0 = static_cast<int64_T>(static_cast<uint64_T>(a1_idx_0) &
                                      36028797018963967UL);
    }
  }
  b_next_out = static_cast<int16_T>(
      ((static_cast<int64_T>(w_in[0]) << 29) + c1_idx_0) >> 29);
  if (static_cast<uint16_T>(static_cast<uint16_T>(b_next_out) & 8192) != 0) {
    w_next_out[0] = static_cast<int16_T>(b_next_out | -8192);
  } else {
    w_next_out[0] =
        static_cast<int16_T>(static_cast<uint16_T>(b_next_out) & 8191);
  }
  b_next_out = static_cast<int16_T>(
      ((static_cast<int64_T>(w_in[1]) << 29) + c1_idx_1) >> 29);
  if (static_cast<uint16_T>(static_cast<uint16_T>(b_next_out) & 8192) != 0) {
    w_next_out[1] = static_cast<int16_T>(b_next_out | -8192);
  } else {
    w_next_out[1] =
        static_cast<int16_T>(static_cast<uint16_T>(b_next_out) & 8191);
  }
  b_next_out = static_cast<int16_T>(
      ((static_cast<int64_T>(w_in[2]) << 29) + a1_idx_1) >> 29);
  if (static_cast<uint16_T>(static_cast<uint16_T>(b_next_out) & 8192) != 0) {
    w_next_out[2] = static_cast<int16_T>(b_next_out | -8192);
  } else {
    w_next_out[2] =
        static_cast<int16_T>(static_cast<uint16_T>(b_next_out) & 8191);
  }
  b_next_out = static_cast<int16_T>(
      ((static_cast<int64_T>(w_in[3]) << 29) + a1_idx_0) >> 29);
  if (static_cast<uint16_T>(static_cast<uint16_T>(b_next_out) & 8192) != 0) {
    w_next_out[3] = static_cast<int16_T>(b_next_out | -8192);
  } else {
    w_next_out[3] =
        static_cast<int16_T>(static_cast<uint16_T>(b_next_out) & 8191);
  }
  b_next_out = static_cast<int16_T>(((b_b << 14) + w_next_tmp) >> 14);
  if (static_cast<uint16_T>(static_cast<uint16_T>(b_next_out) & 8192) != 0) {
    b_next_out = static_cast<int16_T>(b_next_out | -8192);
  } else {
    b_next_out = static_cast<int16_T>(static_cast<uint16_T>(b_next_out) & 8191);
  }
  b_st.site = &b_emlrtRSI;
  coder::b_adaptive_neuron_fixpt_logger(b_st, x_history_in, w_in, b_b,
                                        b_current_val, b_mu, pred_y_out,
                                        error_e_out, w_next_out, b_next_out);
  *pred_y = static_cast<real_T>(pred_y_out) * 0.00048828125;
  *error_e = static_cast<real_T>(error_e_out) * 0.000244140625;
  w_next[0] = static_cast<real_T>(w_next_out[0]) * 0.0009765625;
  w_next[1] = static_cast<real_T>(w_next_out[1]) * 0.0009765625;
  w_next[2] = static_cast<real_T>(w_next_out[2]) * 0.0009765625;
  w_next[3] = static_cast<real_T>(w_next_out[3]) * 0.0009765625;
  *b_next = static_cast<real_T>(b_next_out) * 0.000244140625;
}
