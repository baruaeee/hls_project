#pragma once

#include "rtwtypes.h"
#include "coder_array.h"
#include "emlrt.h"

struct struct1_T {
  coder::array<int16_T, 1U> x_history;
  coder::array<int16_T, 1U> w;
  coder::array<int16_T, 2U> b;
  coder::array<int16_T, 2U> current_val;
  coder::array<uint16_T, 2U> mu;
};

struct struct2_T {
  coder::array<int16_T, 2U> pred_y;
  coder::array<int16_T, 2U> error_e;
  coder::array<int16_T, 1U> w_next;
  coder::array<int16_T, 2U> b_next;
};

struct struct0_T {
  struct1_T inputs;
  struct2_T outputs;
  real_T iterCount;
};
