#include "nullAssignment.h"
#include "adaptive_neuron_wrapper_fixpt_hdl_mex_data.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <cstring>

static emlrtRTEInfo x_emlrtRTEI{
    1, 14, "nullAssignment",
    "/MATLAB/toolbox/eml/eml/+coder/+internal/nullAssignment.m"};

namespace coder {
namespace internal {
void nullAssignment(const emlrtStack &sp, array<int16_T, 1U> &x,
                    const array<int32_T, 1U> &idx)
{
  array<boolean_T, 2U> b;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack st;
  int32_T k0;
  int32_T nxin;
  int32_T nxout;
  boolean_T j_p;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  st.site = &v_emlrtRSI;
  j_p = true;
  nxout = 0;
  while (nxout <= idx.size(0) - 1) {
    if (idx[nxout] > x.size(0)) {
      j_p = false;
      break;
    } else {
      nxout++;
    }
  }
  if (!j_p) {
    emlrtErrorWithMessageIdR2018a(&st, &c_emlrtRTEI,
                                  "MATLAB:subsdeldimmismatch",
                                  "MATLAB:subsdeldimmismatch", 0);
  }
  st.site = &w_emlrtRSI;
  nxin = x.size(0);
  b_st.site = &x_emlrtRSI;
  b.set_size(&x_emlrtRTEI, &b_st, 1, nxin);
  if (nxin - 1 >= 0) {
    std::memset(&b[0], 0, static_cast<uint32_T>(nxin) * sizeof(boolean_T));
  }
  nxout = idx.size(0);
  c_st.site = &bb_emlrtRSI;
  if (idx.size(0) > 2147483646) {
    d_st.site = &cb_emlrtRSI;
    emlrtErrorWithMessageIdR2018a(
        &d_st, &e_emlrtRTEI, "Coder:toolbox:int_forloop_overflow",
        "Coder:toolbox:int_forloop_overflow", 3, 4, 5, "int32");
  }
  for (int32_T k{0}; k < nxout; k++) {
    b[idx[k] - 1] = true;
  }
  b_st.site = &y_emlrtRSI;
  nxout = 0;
  c_st.site = &db_emlrtRSI;
  if (b.size(1) > 2147483646) {
    d_st.site = &cb_emlrtRSI;
    emlrtErrorWithMessageIdR2018a(
        &d_st, &e_emlrtRTEI, "Coder:toolbox:int_forloop_overflow",
        "Coder:toolbox:int_forloop_overflow", 3, 4, 5, "int32");
  }
  for (int32_T k{0}; k < nxin; k++) {
    nxout += b[k];
  }
  nxout = x.size(0) - nxout;
  k0 = -1;
  b_st.site = &ab_emlrtRSI;
  if (x.size(0) > 2147483646) {
    c_st.site = &cb_emlrtRSI;
    emlrtErrorWithMessageIdR2018a(
        &c_st, &e_emlrtRTEI, "Coder:toolbox:int_forloop_overflow",
        "Coder:toolbox:int_forloop_overflow", 3, 4, 5, "int32");
  }
  for (int32_T k{0}; k < nxin; k++) {
    if ((k + 1 > b.size(1)) || !b[k]) {
      k0++;
      x[k0] = x[k];
    }
  }
  if (nxout > x.size(0)) {
    emlrtErrorWithMessageIdR2018a(&st, &d_emlrtRTEI,
                                  "Coder:builtins:AssertionFailed",
                                  "Coder:builtins:AssertionFailed", 0);
  }
  if (nxout < 1) {
    nxout = 0;
  }
  x.set_size(&x_emlrtRTEI, &st, nxout);
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

void nullAssignment(const emlrtStack &sp, array<int16_T, 2U> &x,
                    const array<int32_T, 1U> &idx)
{
  array<boolean_T, 2U> b;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack st;
  int32_T k0;
  int32_T nxin;
  int32_T nxout;
  boolean_T j_p;
  st.prev = &sp;
  st.tls = sp.tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  emlrtHeapReferenceStackEnterFcnR2012b((emlrtConstCTX)&sp);
  st.site = &v_emlrtRSI;
  j_p = true;
  nxout = 0;
  while (nxout <= idx.size(0) - 1) {
    if (idx[nxout] > x.size(1)) {
      j_p = false;
      break;
    } else {
      nxout++;
    }
  }
  if (!j_p) {
    emlrtErrorWithMessageIdR2018a(&st, &c_emlrtRTEI,
                                  "MATLAB:subsdeldimmismatch",
                                  "MATLAB:subsdeldimmismatch", 0);
  }
  st.site = &w_emlrtRSI;
  nxin = x.size(1);
  b_st.site = &x_emlrtRSI;
  b.set_size(&x_emlrtRTEI, &b_st, 1, nxin);
  if (nxin - 1 >= 0) {
    std::memset(&b[0], 0, static_cast<uint32_T>(nxin) * sizeof(boolean_T));
  }
  nxout = idx.size(0);
  c_st.site = &bb_emlrtRSI;
  if (idx.size(0) > 2147483646) {
    d_st.site = &cb_emlrtRSI;
    emlrtErrorWithMessageIdR2018a(
        &d_st, &e_emlrtRTEI, "Coder:toolbox:int_forloop_overflow",
        "Coder:toolbox:int_forloop_overflow", 3, 4, 5, "int32");
  }
  for (int32_T k{0}; k < nxout; k++) {
    b[idx[k] - 1] = true;
  }
  b_st.site = &y_emlrtRSI;
  nxout = 0;
  c_st.site = &db_emlrtRSI;
  if (b.size(1) > 2147483646) {
    d_st.site = &cb_emlrtRSI;
    emlrtErrorWithMessageIdR2018a(
        &d_st, &e_emlrtRTEI, "Coder:toolbox:int_forloop_overflow",
        "Coder:toolbox:int_forloop_overflow", 3, 4, 5, "int32");
  }
  for (int32_T k{0}; k < nxin; k++) {
    nxout += b[k];
  }
  nxout = x.size(1) - nxout;
  k0 = -1;
  b_st.site = &ab_emlrtRSI;
  if (x.size(1) > 2147483646) {
    c_st.site = &cb_emlrtRSI;
    emlrtErrorWithMessageIdR2018a(
        &c_st, &e_emlrtRTEI, "Coder:toolbox:int_forloop_overflow",
        "Coder:toolbox:int_forloop_overflow", 3, 4, 5, "int32");
  }
  for (int32_T k{0}; k < nxin; k++) {
    if ((k + 1 > b.size(1)) || !b[k]) {
      k0++;
      x[k0] = x[k];
    }
  }
  if (nxout > x.size(1)) {
    emlrtErrorWithMessageIdR2018a(&st, &i_emlrtRTEI,
                                  "Coder:builtins:AssertionFailed",
                                  "Coder:builtins:AssertionFailed", 0);
  }
  if (nxout < 1) {
    nxout = 0;
  }
  x.set_size(&x_emlrtRTEI, &st, x.size(0), nxout);
  emlrtHeapReferenceStackLeaveFcnR2012b((emlrtConstCTX)&sp);
}

} // namespace internal
} // namespace coder
