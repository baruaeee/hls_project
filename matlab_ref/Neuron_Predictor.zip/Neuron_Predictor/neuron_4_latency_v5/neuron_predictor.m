function [residual, predicted] = neuron_predictor(x_in, reset)
% NEURON_PREDICTOR Optimized LMS predictive coding neuron
% Uses explicit parallel MAC tree + fabric adders for low latency & positive slack.

NUM_TAPS    = 4;
SCALE_UP    = 4096;    % 2^12
INV_SCALE   = 1/4096;  % 2^-12
MU_STEP     = 1/1024; % 2^-14

persistent x_hist w b;

x_val = double(x_in);

if isempty(x_hist) || reset
    x_hist = zeros(NUM_TAPS, 1);
    w = zeros(NUM_TAPS, 1);
    w(1) = SCALE_UP; % 4096 (represents 1.0 in Q12)
    b = 0;
end

% --- HLS Synthesis Directives ---
coder.hdl.literaltext("#pragma HLS ARRAY_PARTITION variable=x_hist complete dim=1");
coder.hdl.literaltext("#pragma HLS ARRAY_PARTITION variable=w complete dim=1");

% --- 1. Parallel Multiplication (Mapped to DSPs) ---
prod = zeros(NUM_TAPS, 1);
coder.hdl.literaltext("#pragma HLS ARRAY_PARTITION variable=prod complete dim=1");

coder.hdl.loopspec('unroll');
for i = 1:NUM_TAPS
    prod(i) = x_hist(i) * w(i);
    coder.hdl.literaltext("#pragma HLS BIND_OP variable=prod op=mul impl=dsp");
end

% --- 2. Balanced Parallel Adder Tree (Mapped to Fabric) ---
sum_01 = prod(1) + prod(2);
sum_23 = prod(3) + prod(4);
acc    = b + (sum_01 + sum_23);
coder.hdl.literaltext("#pragma HLS BIND_OP variable=acc op=add impl=fabric");

predicted = floor(acc * INV_SCALE);

% --- 3. Residual Error ---
residual = x_val - predicted;

% --- 4. Adaptive LMS Update (Power-of-2 scaling -> bit-shifts) ---
b = b + floor((residual * SCALE_UP) * MU_STEP);

coder.hdl.loopspec('unroll');
for i = 1:NUM_TAPS
    grad = residual * x_hist(i);
    coder.hdl.literaltext("#pragma HLS BIND_OP variable=grad op=mul impl=dsp");
    w(i) = w(i) + floor(grad * MU_STEP);
end

% --- 5. Update Delay Line ---
coder.hdl.loopspec('unroll');
for i = NUM_TAPS:-1:2
    x_hist(i) = x_hist(i-1);
end
x_hist(1) = x_val;
end