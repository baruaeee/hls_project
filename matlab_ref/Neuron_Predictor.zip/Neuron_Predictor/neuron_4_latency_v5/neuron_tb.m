% tb_neuron_predictor.m
% Testbench for neuron_predictor.m
% Compares raw sample magnitudes vs. adaptive neural prediction residuals.

clear; clc;

% 1. Load Stimulus Data from Step 1 as double for Fixed-Point Converter
filename = 'stimulus_data.txt';
if ~isfile(filename)
    error('Run generate_stimulus.m first to create %s.', filename);
end
raw_signal = double(load(filename));
num_samples = length(raw_signal);

% Preallocate outputs as double
residuals = zeros(num_samples, 1);
predictions = zeros(num_samples, 1);

% 2. Stream Data Sample-by-Sample through the Hardware Module
for n = 1:num_samples
    rst = (n == 1); % Assert reset on the very first clock cycle
    [residuals(n), predictions(n)] = neuron_predictor(raw_signal(n), rst);
end

% 3. Save Residuals for Step 3 (Golomb-Rice Input)
fid = fopen('residuals_data.txt', 'w');
fprintf(fid, '%d\n', residuals);
fclose(fid);

% 4. Quantitative Comparison (PPA & Compression Readiness)
raw_abs_mean = mean(abs(double(raw_signal)));
res_abs_mean = mean(abs(double(residuals)));
reduction_pct = (1 - (res_abs_mean / raw_abs_mean)) * 100;

% Estimate bit-width savings (Entropy proxy)
raw_bits = ceil(log2(max(abs(double(raw_signal))) + 1)) + 1;
res_bits = ceil(log2(max(abs(double(residuals(10:end)))) + 1)) + 1; % Ignore initial lock transient

fprintf('=== Predictive Coding Performance Comparison ===\n');
fprintf('Mean Absolute Amplitude (Raw Signal) : %.2f\n', raw_abs_mean);
fprintf('Mean Absolute Amplitude (Residuals)  : %.2f\n', res_abs_mean);
fprintf('Signal Magnitude Reduction           : %.2f%%\n', reduction_pct);
fprintf('Peak Bit-Width Needed (Raw vs Res)   : %d bits -> %d bits\n', raw_bits, res_bits);

% 5. Visual Comparison Plot
figure('Name', 'Adaptive Predictive Neuron Verification', 'Position', [100, 100, 900, 600]);

subplot(2,1,1);
plot(1:num_samples, raw_signal, 'b-', 'LineWidth', 1.5); hold on;
plot(1:num_samples, predictions, 'r--', 'LineWidth', 1.2);
title('Original Signal vs. Adaptive Neuron Prediction');
xlabel('Sample Index [n]');
ylabel('Amplitude');
legend('Actual Signal x[n]', 'Neuron Prediction x\_hat[n]');
grid on;

subplot(2,1,2);
plot(1:num_samples, raw_signal, 'Color', [0.7 0.7 0.7], 'LineWidth', 1); hold on;
plot(1:num_samples, residuals, 'g-', 'LineWidth', 1.5);
title('Compression Input Comparison: Raw Signal vs. Residual Error e[n]');
xlabel('Sample Index [n]');
ylabel('Amplitude');
legend('Raw Signal (High Variance)', 'Residual Error (Clustered near 0)');
grid on;