% generate_stimulus.m
% Generates a correlated input stream (e.g., noisy low-frequency sine wave)
% and saves it to a text file for simulation and HLS testbenches.

% • clc: Clears all text and output from the MATLAB Command Window,
% leaving a clean screen (though previous commands can still be recalled
% using the up-arrow key).
% • clear: Removes all variables and data from the MATLAB Workspace to
% free up memory, ensuring your new script starts with a blank slate.
clear; clc;

% 1. Simulation Parameters
num_samples = 256;          % Number of data samples
frequency = 0.05;           % Low frequency for high correlation
%{
• 0:num_samples-1: Generates a row vector of integers starting at 0 and
 incrementing by 1 up to num_samples - 1 (e.g., if num_samples = 5, this
 produces [0, 1, 2, 3, 4]).
• ( ... )': The single quote (') is the transpose operator,
 which converts the horizontal row vector into a vertical column vector
 (num_samples × 1). (Note: For real numbers, ' and .' behave identically;
 for complex numbers, ' takes the complex conjugate transpose).
%}
t = (0:num_samples-1)';

% 2. Generate a correlated signal with mild noise
clean_signal = 1000 * sin(2 * pi * frequency * t); 
noise = 10 * randn(num_samples, 1);
raw_signal = round(clean_signal + noise); % Convert to integer sensor-like values

% Ensure values fit nicely within a standard 16-bit signed range (-32768 to 32767)
raw_signal = max(min(raw_signal, 32767), -32768);

% 3. Write stimulus to a text file (one sample per line)
filename = 'stimulus_data.txt';
fid = fopen(filename, 'w');
if fid == -1
    error('Could not open file %s for writing.', filename);
end

fprintf(fid, '%d\n', raw_signal);
fclose(fid);

disp(['[INFO] Successfully generated ', num2str(num_samples), ' samples and saved to ', filename]);

% 4. Quick plot to visualize the stimulus stream
figure;
plot(raw_signal, '-o', 'LineWidth', 1.5);
title('Input Stimulus Data Stream');
xlabel('Sample Index [n]');
ylabel('Amplitude');
grid on;