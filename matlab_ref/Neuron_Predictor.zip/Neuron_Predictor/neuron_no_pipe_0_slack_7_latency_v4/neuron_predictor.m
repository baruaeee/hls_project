function [residual, predicted] = neuron_predictor(x_in, reset)
% NEURON_PREDICTOR Floating-point reference for HDL Coder Fixed-Point Converter

NUM_TAPS    = 4;
SCALE_UP    = 4096;   % 2^12
INV_SCALE   = 1/4096; % 2^-12
% MU_STEP     = 1/16384;% 2^-14
MU_STEP     = 1/1024;% 2^-10

persistent x_hist w b;

if isempty(x_hist) || reset
    x_hist = zeros(NUM_TAPS, 1);
    w = zeros(NUM_TAPS, 1);
    w(1) = SCALE_UP; % 4096 (represents 1.0 in Q12)
    b = 0;
end

% 1. Forward Pass (Prediction)
acc = b;
coder.hdl.loopspec('unroll');
for i = 1:NUM_TAPS
    acc = acc + (x_hist(i) * w(i));
end
predicted = floor(acc * INV_SCALE);

% 2. Residual Error
residual = x_in - predicted;

% 3. Adaptive LMS Update (Power-of-2 scaling -> synthesizes to bit-shifts)
b = b + floor((residual * SCALE_UP) * MU_STEP);

coder.hdl.loopspec('unroll');
for i = 1:NUM_TAPS
    grad = residual * x_hist(i);
    w(i) = w(i) + floor(grad * MU_STEP);
end

% 4. Update Delay Line
coder.hdl.loopspec('unroll');
for i = NUM_TAPS:-1:2
    x_hist(i) = x_hist(i-1);
end
x_hist(1) = x_in;
end