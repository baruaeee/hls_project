#include "_coder_neuron_predictor_wrapper_fixpt_hdl_mex_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

static const mxArray *c_emlrtMexFcnResolvedFunctionsI();

static const mxArray *c_emlrtMexFcnResolvedFunctionsI()
{
  const mxArray *nameCaptureInfo;
  const char_T *data[8]{
      "789ced593b6f1341105e3b0ee441824102a501a5a48a6344e028839d8488c41c38884084"
      "2e8ebd768ef81e3afb1ca74b4981042525654a4a4a4a4a1a241a247e"
      "023d0d6bfbc68f89277be46119e7465aefcd7e7bf3cdeceecdaebc2cb4bc1a628c4db286"
      "bc996ad4139e1ef5ea30eb148c87bc3a827490610f9940f83bafce5a",
      "669957cb0dc5cc18bcf9a66eda6e796dcfe625a138bc64152b3c5747f27a91afe9064fb7"
      "2ba99a662cb6414da506d59e13db3cbb93760de66c975a1e16db95e6"
      "786c12f14658a7601c0b1e0fdc0ff8f68fc907f66f4af80037b9eb58a6663b3ca767cb96"
      "a3ed3a19dbe68e96d7ab76b9e5cf0f82ef0ab28ff9429ec7ab89c7e9",
      "867ea1ae97ca8e6e165af6ab847dd019815f40bc981ff0a956d3cfb0d7afbd801f5f091e"
      "bfe39e25fc88227c63e1556c757e6d65fec174d2d12b3c96cc94b584"
      "65d85a92674515abdc8965ad1c2f703386e728569f9b43cd9d533763d47964ebf7b2cfb8"
      "a8f19d6023f5faedf73faf7bc907725ef8a8efc3efbabc4ef045117e",
      "6f65cbdd49a52bc9b9bcbdac3ce38a6aa51e255a7ea8121e991f8cd07b657f50bfef5ead"
      "8f434e9d937d029ec18f2f048fdff1de20fc8822fc2cd651b03f0c1e"
      "df49bfff6b045f14e14f8dfbb78b73ebf1eaae1a8fe79ca50553a9a6d8e0ec0f9bc4fbfd"
      "7acebf21e103bc7b12d08a56a1c01d36f8f97b8875e6ef6f048fdf71",
      "d7093fa2083f85fc9d173fa2e39133e865f3dee59f83209f9f295fafce73d5972f8a8aeb"
      "aa05371e9f5dbcab14e69eec3d5c0af23996209ff7573e8fb0209fd7"
      "24c8e7ff075f90cf4fc7feafb1eeef8ffab4bf3fd6dd7e18e10cdd87a8a3ddedfabd0fa1"
      "d60bdc878c221c74c8bf20cdff1f46baf3fd7b5eefb453bb1779eefd",
      "cfa4b5f1a9049f6c5e715cd4bc7e081dfd3e655f091d6d3f8cfa45bc36459475513e8a32"
      "25b0e9b6724b948cb9d7dceb28c1730ffc50b08e0bbe8718a2a93ae2"
      "a29ec344fb10d18e730fe69b6deb3c8970d03f79f571f3e818d2717f15e1614287f3c245"
      "afce318bb96c8b151917c56205b1836759463c77fafff984fe8f4bfc",
      "5ff7e93fd801ff393384f75cc491abffceb0bc88e0702410c7ef13c6715512c77b491cb0"
      "96701ce3a8f61357f73edd5b65e76ebff153f7d5d07f5a123f48335f"
      "12f94c962fb15dcabe2d799fb22fdb67613fea77fe4dc2fe2509bf6c7c8789f35b309f67"
      "cb3f72ccfd1fec1d10f6c308c7e73ac86bfd72ae03f90b90dbb899",
      ""};
  nameCaptureInfo = nullptr;
  emlrtNameCaptureMxArrayR2016a(&data[0], 9104U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties()
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *epFieldName[7]{
      "QualifiedName",    "NumberOfInputs", "NumberOfOutputs", "ConstantInputs",
      "ResolvedFilePath", "TimeStamp",      "Visible"};
  const char_T *propFieldName[7]{
      "Version",      "ResolvedFunctions", "Checksum", "EntryPoints",
      "CoverageInfo", "IsPolymorphic",     "AuxData"};
  uint8_T v[216]{
      0U,   1U,   73U,  77U,  0U,   0U,   0U,   0U,   14U,  0U,   0U,   0U,
      200U, 0U,   0U,   0U,   6U,   0U,   0U,   0U,   8U,   0U,   0U,   0U,
      2U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,   5U,   0U,   0U,   0U,
      8U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,
      1U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,   5U,   0U,   4U,   0U,
      17U,  0U,   0U,   0U,   1U,   0U,   0U,   0U,   17U,  0U,   0U,   0U,
      67U,  108U, 97U,  115U, 115U, 69U,  110U, 116U, 114U, 121U, 80U,  111U,
      105U, 110U, 116U, 115U, 0U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,
      14U,  0U,   0U,   0U,   112U, 0U,   0U,   0U,   6U,   0U,   0U,   0U,
      8U,   0U,   0U,   0U,   2U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,
      5U,   0U,   0U,   0U,   8U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,
      0U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,
      5U,   0U,   4U,   0U,   14U,  0U,   0U,   0U,   1U,   0U,   0U,   0U,
      56U,  0U,   0U,   0U,   81U,  117U, 97U,  108U, 105U, 102U, 105U, 101U,
      100U, 78U,  97U,  109U, 101U, 0U,   77U,  101U, 116U, 104U, 111U, 100U,
      115U, 0U,   0U,   0U,   0U,   0U,   0U,   0U,   80U,  114U, 111U, 112U,
      101U, 114U, 116U, 105U, 101U, 115U, 0U,   0U,   0U,   0U,   72U,  97U,
      110U, 100U, 108U, 101U, 0U,   0U,   0U,   0U,   0U,   0U,   0U,   0U};
  xEntryPoints =
      emlrtCreateStructMatrix(1, 2, 7, (const char_T **)&epFieldName[0]);
  xInputs = emlrtCreateLogicalMatrix(1, 2);
  emlrtSetField(xEntryPoints, 0, "QualifiedName",
                emlrtMxCreateString("neuron_predictor_wrapper_fixpt"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(2.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(2.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 0, "ResolvedFilePath",
      emlrtMxCreateString("/MATLAB "
                          "Drive/Dat_Comp_Decomp/v4/codegen/neuron_predictor/"
                          "fixpt/neuron_predictor_wrapper_fixpt.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp",
                emlrtMxCreateDoubleScalar(740303.1793981482));
  emlrtSetField(xEntryPoints, 0, "Visible", emlrtMxCreateLogicalScalar(true));
  xInputs = emlrtCreateLogicalMatrix(1, 0);
  emlrtSetField(xEntryPoints, 1, "QualifiedName",
                emlrtMxCreateString("neuron_predictor_fixpt_logger"));
  emlrtSetField(xEntryPoints, 1, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 1, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 1, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 1, "ResolvedFilePath",
      emlrtMxCreateString("/MATLAB "
                          "Drive/Dat_Comp_Decomp/v4/codegen/neuron_predictor/"
                          "fixpt/fxptmp/neuron_predictor_fixpt_logger.m"));
  emlrtSetField(xEntryPoints, 1, "TimeStamp",
                emlrtMxCreateDoubleScalar(740303.1797222223));
  emlrtSetField(xEntryPoints, 1, "Visible", emlrtMxCreateLogicalScalar(true));
  xResult =
      emlrtCreateStructMatrix(1, 1, 7, (const char_T **)&propFieldName[0]);
  emlrtSetField(xResult, 0, "Version",
                emlrtMxCreateString("26.2.0.3437455 (R2026b) Update 2"));
  emlrtSetField(xResult, 0, "ResolvedFunctions",
                (mxArray *)c_emlrtMexFcnResolvedFunctionsI());
  emlrtSetField(xResult, 0, "Checksum",
                emlrtMxCreateString("c2g0bw0EZvcNSKM91OIbdE"));
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  emlrtSetField(xResult, 0, "AuxData",
                emlrtMxCreateRowVectorUINT8((const uint8_T *)&v, 216U));
  return xResult;
}
