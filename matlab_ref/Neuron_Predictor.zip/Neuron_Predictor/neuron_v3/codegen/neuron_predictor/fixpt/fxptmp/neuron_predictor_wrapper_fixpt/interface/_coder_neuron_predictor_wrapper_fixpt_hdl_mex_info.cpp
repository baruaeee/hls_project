#include "_coder_neuron_predictor_wrapper_fixpt_hdl_mex_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

static const mxArray *c_emlrtMexFcnResolvedFunctionsI();

static const mxArray *c_emlrtMexFcnResolvedFunctionsI()
{
  const mxArray *nameCaptureInfo;
  const char_T *data[8]{
      "789ced593b73d340103e2b4ec88380a160d2c0a4a48a133201b7894d7086c484b1814086"
      "716cf9ec28b11e23cbc6e9e8a0839292323f819292a1a24c43494f4f"
      "83646b6d69e3cd893c3cc6d17a4ea7bdefb4dfeedd694fe36391b58d0863ec1a6bcbfb99"
      "763dedea31b796985f301e71eb28d241465d641ae11fdc5ad6358b37",
      "adb6a21554de7952d18cba953b3078cd564c5ed3ab0d5e6a2165a5ca738acab35e25e368"
      "eaaa07ea280ee4dc2777b9bc9fadabccdcad753dac7a95ce78ec10f1"
      "46995f308e058f07ee077c6f4fc907f6ef08f800d778ddd4b5bc61f292225bba997f6316"
      "0c839bf9b2d234acae3f4704df0d641ff3455c8f37924fb26d7daca5",
      "d72c53d12a5dfb4dc23ee88cc0c7102fe6077ca6dbf45372fb790bf8f18de0093aee32e1"
      "470ce1db0f5fc7379673ebcb2bb3295369f078aa60e593ba6ae4535c"
      "b6ab7863312eeb255ee15a1ccf51bc3537c79afd5337a7b67844ebf77ac0b8a8f19d66e3"
      "adfafbbb3f7bfde403b92c7cd4fb11745dde22f862087fb05eacef67",
      "b28dd452d9584b3ce3894d3df338d9f56353c023f283117abfec0febfbddaff571cca94b"
      "b24fc03df8f195e0093adedb841f31845fc43a0af787e1e3ebd7fbdf"
      "5c6e6472e53dd32cae64f595f5f9e76a99175787677fd8219e1fd4effcdb023ec07b2781"
      "7c55af54b8c9863f7f8f307ffefe41f0041d7785f02386f073c8df65",
      "fb62773c7106dd6cdebffcf32bcce717cad7b77cfeea653551af6f56ea0b0bf3abf71395"
      "a5a707e947613ec712e6f3c1cae75116e67347c27cfe7ff085f9fc7c"
      "ec1f4df67e7e22a0fde6646ffb12c2193a0f494ff4b61bf43c845a2f701e328170d021ff"
      "82803f5fc67bf3fd7b5ef7db71ce455eb8ff33e53d7c69824f34af38",
      "2e6a5e3f454e7e9eb29f889c6c5f42fda26e5bc22e5b76f96c97191b9bf594bb76296807"
      "9dbd8e123cf7c00f05ebb8e07388119aca1717752f11ed23443bce3d"
      "986fded3f91ac2413f74ebd3e651bc3e70ff34c225421f75eb2b6ead308d596c91dd6355"
      "a6b38aadcbac60df77de9f33fa3d25f07b2ba0df6007fce64c6545fb",
      "5ab27fce758e956ddffd31380271fc3e631c3705717c14c4016b08c73185ea2071f5eed3"
      "bb55f4bd1d347eea9c1afacf0ae207e9ec7f441e13e5496c97b26f08"
      "9ea7ec8bf657d887069d7f87b07f55c02f1adf51e2bb2d9ccf8be51f3fe5be0ff60e910e"
      "22211c7fcf415e1b94ef3990bf2365b863",
      ""};
  nameCaptureInfo = nullptr;
  emlrtNameCaptureMxArrayR2016a(&data[0], 9096U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties()
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *epFieldName[7]{
      "QualifiedName",    "NumberOfInputs", "NumberOfOutputs", "ConstantInputs",
      "ResolvedFilePath", "TimeStamp",      "Visible"};
  const char_T *propFieldName[7]{
      "Version",      "ResolvedFunctions", "Checksum", "EntryPoints",
      "CoverageInfo", "IsPolymorphic",     "AuxData"};
  uint8_T v[216]{
      0U,   1U,   73U,  77U,  0U,   0U,   0U,   0U,   14U,  0U,   0U,   0U,
      200U, 0U,   0U,   0U,   6U,   0U,   0U,   0U,   8U,   0U,   0U,   0U,
      2U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,   5U,   0U,   0U,   0U,
      8U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,
      1U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,   5U,   0U,   4U,   0U,
      17U,  0U,   0U,   0U,   1U,   0U,   0U,   0U,   17U,  0U,   0U,   0U,
      67U,  108U, 97U,  115U, 115U, 69U,  110U, 116U, 114U, 121U, 80U,  111U,
      105U, 110U, 116U, 115U, 0U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,
      14U,  0U,   0U,   0U,   112U, 0U,   0U,   0U,   6U,   0U,   0U,   0U,
      8U,   0U,   0U,   0U,   2U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,
      5U,   0U,   0U,   0U,   8U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,
      0U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,
      5U,   0U,   4U,   0U,   14U,  0U,   0U,   0U,   1U,   0U,   0U,   0U,
      56U,  0U,   0U,   0U,   81U,  117U, 97U,  108U, 105U, 102U, 105U, 101U,
      100U, 78U,  97U,  109U, 101U, 0U,   77U,  101U, 116U, 104U, 111U, 100U,
      115U, 0U,   0U,   0U,   0U,   0U,   0U,   0U,   80U,  114U, 111U, 112U,
      101U, 114U, 116U, 105U, 101U, 115U, 0U,   0U,   0U,   0U,   72U,  97U,
      110U, 100U, 108U, 101U, 0U,   0U,   0U,   0U,   0U,   0U,   0U,   0U};
  xEntryPoints =
      emlrtCreateStructMatrix(1, 2, 7, (const char_T **)&epFieldName[0]);
  xInputs = emlrtCreateLogicalMatrix(1, 2);
  emlrtSetField(xEntryPoints, 0, "QualifiedName",
                emlrtMxCreateString("neuron_predictor_wrapper_fixpt"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(2.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(2.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 0, "ResolvedFilePath",
      emlrtMxCreateString("/MATLAB "
                          "Drive/Dat_Comp_Decomp/v3/codegen/neuron_predictor/"
                          "fixpt/neuron_predictor_wrapper_fixpt.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp",
                emlrtMxCreateDoubleScalar(740302.9490046296));
  emlrtSetField(xEntryPoints, 0, "Visible", emlrtMxCreateLogicalScalar(true));
  xInputs = emlrtCreateLogicalMatrix(1, 0);
  emlrtSetField(xEntryPoints, 1, "QualifiedName",
                emlrtMxCreateString("neuron_predictor_fixpt_logger"));
  emlrtSetField(xEntryPoints, 1, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 1, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 1, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 1, "ResolvedFilePath",
      emlrtMxCreateString("/MATLAB "
                          "Drive/Dat_Comp_Decomp/v3/codegen/neuron_predictor/"
                          "fixpt/fxptmp/neuron_predictor_fixpt_logger.m"));
  emlrtSetField(xEntryPoints, 1, "TimeStamp",
                emlrtMxCreateDoubleScalar(740302.9493171297));
  emlrtSetField(xEntryPoints, 1, "Visible", emlrtMxCreateLogicalScalar(true));
  xResult =
      emlrtCreateStructMatrix(1, 1, 7, (const char_T **)&propFieldName[0]);
  emlrtSetField(xResult, 0, "Version",
                emlrtMxCreateString("26.2.0.3437455 (R2026b) Update 2"));
  emlrtSetField(xResult, 0, "ResolvedFunctions",
                (mxArray *)c_emlrtMexFcnResolvedFunctionsI());
  emlrtSetField(xResult, 0, "Checksum",
                emlrtMxCreateString("zvnBlyJRKXJ8FfR1qazC3"));
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  emlrtSetField(xResult, 0, "AuxData",
                emlrtMxCreateRowVectorUINT8((const uint8_T *)&v, 216U));
  return xResult;
}
