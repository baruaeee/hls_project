#include "neuron_predictor_wrapper_fixpt.h"
#include "neuron_predictor_fixpt_logger.h"
#include "neuron_predictor_wrapper_fixpt_hdl_mex_data.h"
#include "rt_nonfinite.h"

static emlrtRSInfo emlrtRSI{10, "neuron_predictor_wrapper_fixpt",
                            "/MATLAB "
                            "Drive/Dat_Comp_Decomp/v3/codegen/neuron_predictor/"
                            "fixpt/neuron_predictor_wrapper_fixpt.m"};

static emlrtRSInfo b_emlrtRSI{5, "neuron_predictor_fixpt_input_output_logger",
                              "src/LogInputsAndOutputs.cpp:55"};

void neuron_predictor_wrapper_fixpt(const emlrtStack *sp, int32_T x_in,
                                    boolean_T reset, real_T *residual,
                                    real_T *predicted)
{
  static int16_T w[4];
  static int16_T x_hist[4];
  static int16_T b;
  emlrtStack b_st;
  emlrtStack st;
  int32_T i;
  int16_T b_x_in;
  int16_T predicted_out;
  int16_T residual_out;
  int16_T x_in_idx_1;
  int16_T x_in_idx_2;
  int16_T x_in_idx_3;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  if (static_cast<uint16_T>(static_cast<uint16_T>(x_in) & 1024) != 0) {
    b_x_in = static_cast<int16_T>(static_cast<int16_T>(x_in) | -1024);
  } else {
    b_x_in = static_cast<int16_T>(static_cast<uint16_T>(x_in) & 1023);
  }
  st.site = &emlrtRSI;
  if (!x_hist_not_empty || reset) {
    x_hist_not_empty = true;
    x_hist[0] = b_x_in;
    w[0] = 4096;
    x_hist[1] = b_x_in;
    w[1] = 0;
    x_hist[2] = b_x_in;
    w[2] = 0;
    x_hist[3] = b_x_in;
    w[3] = 0;
    b = 0;
  }
  i = x_hist[0] * w[0] + x_hist[1] * w[1];
  if ((static_cast<uint32_T>(i) & 67108864U) != 0U) {
    i |= -67108864;
  } else {
    i = static_cast<int32_T>(static_cast<uint32_T>(i) & 67108863U);
  }
  i += x_hist[2] * w[2];
  if ((static_cast<uint32_T>(i) & 67108864U) != 0U) {
    i |= -67108864;
  } else {
    i = static_cast<int32_T>(static_cast<uint32_T>(i) & 67108863U);
  }
  i += x_hist[3] * w[3];
  if ((static_cast<uint32_T>(i) & 67108864U) != 0U) {
    i |= -67108864;
  } else {
    i = static_cast<int32_T>(static_cast<uint32_T>(i) & 67108863U);
  }
  x_in_idx_1 =
      static_cast<int16_T>((b + (static_cast<int64_T>(i) << 13)) >> 23);
  if (static_cast<uint16_T>(static_cast<uint16_T>(x_in_idx_1) & 8192) != 0) {
    predicted_out = static_cast<int16_T>(x_in_idx_1 | -8192);
  } else {
    predicted_out =
        static_cast<int16_T>(static_cast<uint16_T>(x_in_idx_1) & 8191);
  }
  x_in_idx_1 = static_cast<int16_T>(((b_x_in << 2) - predicted_out) << 2);
  if (static_cast<uint16_T>(static_cast<uint16_T>(x_in_idx_1) & 8192) != 0) {
    residual_out = static_cast<int16_T>(x_in_idx_1 | -8192);
  } else {
    residual_out =
        static_cast<int16_T>(static_cast<uint16_T>(x_in_idx_1) & 8191);
  }
  x_in_idx_1 = static_cast<int16_T>(((b << 14) + (residual_out << 13)) >> 14);
  if (static_cast<uint16_T>(static_cast<uint16_T>(x_in_idx_1) & 8192) != 0) {
    b = static_cast<int16_T>(x_in_idx_1 | -8192);
  } else {
    b = static_cast<int16_T>(static_cast<uint16_T>(x_in_idx_1) & 8191);
  }
  x_in_idx_1 = static_cast<int16_T>(
      ((static_cast<int64_T>(w[0]) << 27) +
       (static_cast<int64_T>(residual_out * x_hist[0]) << 13)) >>
      27);
  if (static_cast<uint16_T>(static_cast<uint16_T>(x_in_idx_1) & 8192) != 0) {
    w[0] = static_cast<int16_T>(x_in_idx_1 | -8192);
  } else {
    w[0] = static_cast<int16_T>(static_cast<uint16_T>(x_in_idx_1) & 8191);
  }
  x_in_idx_1 = static_cast<int16_T>(
      ((static_cast<int64_T>(w[1]) << 27) +
       (static_cast<int64_T>(residual_out * x_hist[1]) << 13)) >>
      27);
  if (static_cast<uint16_T>(static_cast<uint16_T>(x_in_idx_1) & 8192) != 0) {
    w[1] = static_cast<int16_T>(x_in_idx_1 | -8192);
  } else {
    w[1] = static_cast<int16_T>(static_cast<uint16_T>(x_in_idx_1) & 8191);
  }
  x_in_idx_1 = static_cast<int16_T>(
      ((static_cast<int64_T>(w[2]) << 27) +
       (static_cast<int64_T>(residual_out * x_hist[2]) << 13)) >>
      27);
  if (static_cast<uint16_T>(static_cast<uint16_T>(x_in_idx_1) & 8192) != 0) {
    w[2] = static_cast<int16_T>(x_in_idx_1 | -8192);
  } else {
    w[2] = static_cast<int16_T>(static_cast<uint16_T>(x_in_idx_1) & 8191);
  }
  x_in_idx_1 = static_cast<int16_T>(
      ((static_cast<int64_T>(w[3]) << 27) +
       (static_cast<int64_T>(residual_out * x_hist[3]) << 13)) >>
      27);
  if (static_cast<uint16_T>(static_cast<uint16_T>(x_in_idx_1) & 8192) != 0) {
    w[3] = static_cast<int16_T>(x_in_idx_1 | -8192);
  } else {
    w[3] = static_cast<int16_T>(static_cast<uint16_T>(x_in_idx_1) & 8191);
  }
  x_in_idx_1 = x_hist[0];
  x_in_idx_2 = x_hist[1];
  x_in_idx_3 = x_hist[2];
  x_hist[0] = b_x_in;
  x_hist[1] = x_in_idx_1;
  x_hist[2] = x_in_idx_2;
  x_hist[3] = x_in_idx_3;
  b_st.site = &b_emlrtRSI;
  coder::b_neuron_predictor_fixpt_logger(b_st, b_x_in, reset, residual_out,
                                         predicted_out);
  *residual = static_cast<real_T>(residual_out) * 0.0625;
  *predicted = static_cast<real_T>(predicted_out) * 0.25;
}
