function [residual, predicted] = neuron_predictor(x_in, reset)
% NEURON_PREDICTOR Floating-point model compatible with HDL Coder Fixed-Point Conversion.

% --- Hardware Constants ---
NUM_TAPS = 4;
MU = 2^-22; % Power-of-two learning rate (synthesizes as a pure bit-shift)

% --- Persistent State Variables (Initialized as double for range analysis) ---
persistent x_hist;
persistent w;
persistent b;

if isempty(x_hist) || reset
    x_hist = repmat(double(x_in), NUM_TAPS, 1);
    w = [1.0; 0.0; 0.0; 0.0];
    b = 0.0;
end

% --- HDL Synthesis Pragmas ---
coder.hdl.literaltext("#pragma HLS ARRAY_PARTITION variable=x_hist complete dim=1");
coder.hdl.literaltext("#pragma HLS ARRAY_PARTITION variable=w complete dim=1");
coder.hdl.literaltext("#pragma HLS PIPELINE II=1");

% --- 1. Forward Pass (Prediction) ---
predicted = b + sum(x_hist .* w);

% --- 2. Compute Residual Error ---
residual = double(x_in) - predicted;

% --- 3. Adaptive Weight & Bias Update ---
b = b + (residual * MU);
w = w + (residual * x_hist * MU);

% --- 4. Update Delay Line ---
x_hist = [double(x_in); x_hist(1:end-1)];
end