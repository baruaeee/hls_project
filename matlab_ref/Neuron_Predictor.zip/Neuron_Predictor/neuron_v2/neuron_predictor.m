function [residual, predicted] = neuron_predictor(x_in, reset)
% NEURON_PREDICTOR Vectorized adaptive LMS predictive coding neuron (zero loops).

% --- Hardware Constants ---
NUM_TAPS  = 4;
FRAC_BITS = 12;
MU_SHIFT  = 10;

% --- Persistent Hardware Registers ---
persistent x_hist;
persistent w;
persistent b;

x_curr = int32(x_in);

if isempty(x_hist) || reset
    x_hist = repmat(x_curr, NUM_TAPS, 1);
    w = zeros(NUM_TAPS, 1, 'int32');
    w(1) = int32(bitsll(1, FRAC_BITS));
    b = int32(0);
end

% --- HDL Synthesis Pragmas ---
coder.hdl.literaltext("#pragma HLS ARRAY_PARTITION variable=x_hist complete dim=1");
coder.hdl.literaltext("#pragma HLS ARRAY_PARTITION variable=w complete dim=1");
coder.hdl.literaltext("#pragma HLS PIPELINE II=1");

% --- 1. Forward Pass (Replaces Loop 1 via Vector Dot Product) ---
acc = int64(b) + sum(int64(x_hist) .* int64(w));
predicted = int32(bitsra(acc, FRAC_BITS));

% --- 2. Compute Residual Error ---
residual = x_curr - predicted;

% --- 3. Adaptive Weight & Bias Update (Replaces Loop 2 via Element-Wise Vector Math) ---
err_scaled = bitsll(int64(residual), FRAC_BITS);
b = b + int32(bitsra(err_scaled, MU_SHIFT));

grad = int64(residual) .* int64(x_hist);
w = w + int32(bitsra(grad, MU_SHIFT));

% --- 4. Update Delay Line (Replaces Loop 3 via Array Slicing) ---
x_hist = [x_curr; x_hist(1:end-1)];
end