#include "adaptive_neuron_wrapper_fixpt_hdl_mex_terminate.h"
#include "_coder_adaptive_neuron_wrapper_fixpt_hdl_mex_mex.h"
#include "adaptive_neuron_fixpt_logger.h"
#include "adaptive_neuron_wrapper_fixpt_hdl_mex_data.h"
#include "rt_nonfinite.h"

static void b_TB_logger_emx_free_dtor_fcn(void *r);

static void c_b_next_TB_logger_emx_free_dto(void *r);

static void c_current_val_TB_logger_emx_fre(void *r);

static void c_error_e_TB_logger_emx_free_dt(void *r);

static void c_pred_y_TB_logger_emx_free_dto(void *r);

static void c_w_next_TB_logger_emx_free_dto(void *r);

static void c_x_history_TB_logger_emx_free_(void *r);

static void emlrtExitTimeCleanupDtorFcn(void *r);

static void mu_TB_logger_emx_free_dtor_fcn(void *r);

static void w_TB_logger_emx_free_dtor_fcn(void *r);

static void b_TB_logger_emx_free_dtor_fcn(void *r)
{
  b_TB_logger_emx_free();
}

static void c_b_next_TB_logger_emx_free_dto(void *r)
{
  b_next_TB_logger_emx_free();
}

static void c_current_val_TB_logger_emx_fre(void *r)
{
  current_val_TB_logger_emx_free();
}

static void c_error_e_TB_logger_emx_free_dt(void *r)
{
  error_e_TB_logger_emx_free();
}

static void c_pred_y_TB_logger_emx_free_dto(void *r)
{
  pred_y_TB_logger_emx_free();
}

static void c_w_next_TB_logger_emx_free_dto(void *r)
{
  w_next_TB_logger_emx_free();
}

static void c_x_history_TB_logger_emx_free_(void *r)
{
  x_history_TB_logger_emx_free();
}

static void emlrtExitTimeCleanupDtorFcn(void *r)
{
  emlrtExitTimeCleanup(&emlrtContextGlobal);
}

static void mu_TB_logger_emx_free_dtor_fcn(void *r)
{
  mu_TB_logger_emx_free();
}

static void w_TB_logger_emx_free_dtor_fcn(void *r)
{
  w_TB_logger_emx_free();
}

void adaptive_neuron_wrapper_fixpt_hdl_mex_atexit()
{
  emlrtStack st{nullptr, nullptr, nullptr};
  mexFunctionCreateRootTLS();
  st.tls = emlrtRootTLSGlobal;
  try {
    emlrtPushHeapReferenceStackR2021a(&st, false, nullptr,
                                      (void *)&emlrtExitTimeCleanupDtorFcn,
                                      nullptr, nullptr, nullptr);
    emlrtEnterRtStackR2012b(&st);
    emlrtPushHeapReferenceStackR2021a(&st, false, nullptr,
                                      (void *)&c_x_history_TB_logger_emx_free_,
                                      nullptr, nullptr, nullptr);
    emlrtPushHeapReferenceStackR2021a(&st, false, nullptr,
                                      (void *)&w_TB_logger_emx_free_dtor_fcn,
                                      nullptr, nullptr, nullptr);
    emlrtPushHeapReferenceStackR2021a(&st, false, nullptr,
                                      (void *)&b_TB_logger_emx_free_dtor_fcn,
                                      nullptr, nullptr, nullptr);
    emlrtPushHeapReferenceStackR2021a(&st, false, nullptr,
                                      (void *)&c_current_val_TB_logger_emx_fre,
                                      nullptr, nullptr, nullptr);
    emlrtPushHeapReferenceStackR2021a(&st, false, nullptr,
                                      (void *)&mu_TB_logger_emx_free_dtor_fcn,
                                      nullptr, nullptr, nullptr);
    emlrtPushHeapReferenceStackR2021a(&st, false, nullptr,
                                      (void *)&c_pred_y_TB_logger_emx_free_dto,
                                      nullptr, nullptr, nullptr);
    emlrtPushHeapReferenceStackR2021a(&st, false, nullptr,
                                      (void *)&c_error_e_TB_logger_emx_free_dt,
                                      nullptr, nullptr, nullptr);
    emlrtPushHeapReferenceStackR2021a(&st, false, nullptr,
                                      (void *)&c_w_next_TB_logger_emx_free_dto,
                                      nullptr, nullptr, nullptr);
    emlrtPushHeapReferenceStackR2021a(&st, false, nullptr,
                                      (void *)&c_b_next_TB_logger_emx_free_dto,
                                      nullptr, nullptr, nullptr);
    x_history_TB_logger_emx_free();
    w_TB_logger_emx_free();
    b_TB_logger_emx_free();
    current_val_TB_logger_emx_free();
    mu_TB_logger_emx_free();
    pred_y_TB_logger_emx_free();
    error_e_TB_logger_emx_free();
    w_next_TB_logger_emx_free();
    b_next_TB_logger_emx_free();
    emlrtDestroyRootTLS(&emlrtRootTLSGlobal);
    emlrtExitTimeCleanup(&emlrtContextGlobal);
    emlrtDestroyArray(&eml_mx);
    emlrtDestroyArray(&b_eml_mx);
    emlrtDestroyArray(&c_eml_mx);
    emlrtDestroyArray(&d_eml_mx);
    emlrtDestroyArray(&e_eml_mx);
  } catch (...) {
    emlrtCleanupOnException((emlrtCTX *)emlrtRootTLSGlobal);
    throw;
  }
}

void adaptive_neuron_wrapper_fixpt_hdl_mex_terminate()
{
  emlrtDestroyRootTLS(&emlrtRootTLSGlobal);
}
