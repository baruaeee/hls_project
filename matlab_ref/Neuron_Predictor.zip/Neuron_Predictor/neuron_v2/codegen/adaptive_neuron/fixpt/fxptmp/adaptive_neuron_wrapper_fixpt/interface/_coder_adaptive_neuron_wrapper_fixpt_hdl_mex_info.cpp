#include "_coder_adaptive_neuron_wrapper_fixpt_hdl_mex_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

static const mxArray *c_emlrtMexFcnResolvedFunctionsI();

static const mxArray *c_emlrtMexFcnResolvedFunctionsI()
{
  const mxArray *nameCaptureInfo;
  const char_T *data[8]{
      "789ced59cd4f1341149f9642403e2c07b5319a70329ea8e247f08814932a05b40534c62c"
      "4b775a16ba1f6eb705e420476e72f4e8d13f81a347ff042fdefd138c"
      "27b7edbe76fbd2c72cd096a6ec24d3d937bfd9f77befcdec9b49878592a910636c82d5ca"
      "5eacd68ebb72d46dc3acb9603ce4b611244319749171847f71dbaca1",
      "db7ccfae09baacf1fa9baa6e96ecccbec98b8e60f1a2512873a58ae4d402cfa81a4f7b85"
      "a58aa4bdf04075a102559ee7b77876275dd298b5556c5858f00af578"
      "6c10fe465873c1382e381e781cf01d9e930ff4df15f0012e2bb269ab652ee9bc6419bab4"
      "6bc9a6c92d29a7ee99b6c79e5f04df24d28ff942aec5a9f9e5744d1e",
      "aaca45db52f5bc67bd11fa4166043e8478313fe0b146d7efb03bce5bc18e9f048fdfb8cb"
      "841d5184bf5ff8104fcd6516e79e4f252c27fef1846c4bf386664a09"
      "9e759a7879269e35149ee77a1ccd51bc3a37b8b779e6a6359747b47eaffbf48b8aef381b"
      "aeb6b70ffe6d77930fca55e1a3be0fbfebf226c11745f8aeb2643f31",
      "5732abc9c7cba69edc4dad29ab0f171a76ac087844763042ee96fe7efdbe2fba3e6e08fc"
      "021c5b7555f60978063b7e103c7ee3fd8eb0238af0f6afa3607fe847"
      "be6e7dff5a62f9d5a2f27173fde5d32c7f94cd6ca70b658df5cffeb041bcdfabe7fc3b02"
      "3ec05b6601a960e4f3dcf2dad3aff97b80b5f79c9f27ec8822fce2f9",
      "3be7fc38e34e9b40279b772bef1c7c0ef27827f9ba95c7d78d678b33e94f0b6f14652739"
      "f73ab1b6a3cd945990c77109f2786fe5f1080bf2b81fbf823c7eb97c"
      "411e6f8ffed858ebf7477cea3f196dad3f8c7086ee3f8eaeb5d6ebf7fe835a2f70ff3182"
      "709021ef42017bfe8eb4e63b7b3e6fd653b9075977ff59923c7c4704",
      "9f685eb15fd4bc7e0d9dfe3ea57f3674bafe301a1771fb669dfad6a9df9c1a73b0294fbd"
      "ef5459dfafef7154c1730ffc50b18c2bbe7718a0a99afca29ec344ff"
      "00d18f730fe67be0193c817090ffb8ed79f3e82492f1f8238487913ce8b6433e5b8519ac"
      "c4365981f1333f7bfd8e11ebd5afdfb7047e9ff8f47bd467cb99e678",
      "51f147a9fe4eb31c533bd6db88d3f105e3744f102758a3549c207ff88d536fc5b1f3f373"
      "48c4dfeffc50f7fa307e0ae1787ea0d4cf0fc47a11ed33582fa5df14"
      "bc4fe9179d4f601fef75fe0d42ff98805f14df41e2dc1bcc6767f987cf796e027ddf09fd"
      "6184e3f3f031a1f7b2cec350fe034b29dac7",
      ""};
  nameCaptureInfo = nullptr;
  emlrtNameCaptureMxArrayR2016a(&data[0], 9400U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties()
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *epFieldName[7]{
      "QualifiedName",    "NumberOfInputs", "NumberOfOutputs", "ConstantInputs",
      "ResolvedFilePath", "TimeStamp",      "Visible"};
  const char_T *propFieldName[7]{
      "Version",      "ResolvedFunctions", "Checksum", "EntryPoints",
      "CoverageInfo", "IsPolymorphic",     "AuxData"};
  uint8_T v[216]{
      0U,   1U,   73U,  77U,  0U,   0U,   0U,   0U,   14U,  0U,   0U,   0U,
      200U, 0U,   0U,   0U,   6U,   0U,   0U,   0U,   8U,   0U,   0U,   0U,
      2U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,   5U,   0U,   0U,   0U,
      8U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,
      1U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,   5U,   0U,   4U,   0U,
      17U,  0U,   0U,   0U,   1U,   0U,   0U,   0U,   17U,  0U,   0U,   0U,
      67U,  108U, 97U,  115U, 115U, 69U,  110U, 116U, 114U, 121U, 80U,  111U,
      105U, 110U, 116U, 115U, 0U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,
      14U,  0U,   0U,   0U,   112U, 0U,   0U,   0U,   6U,   0U,   0U,   0U,
      8U,   0U,   0U,   0U,   2U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,
      5U,   0U,   0U,   0U,   8U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,
      0U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,
      5U,   0U,   4U,   0U,   14U,  0U,   0U,   0U,   1U,   0U,   0U,   0U,
      56U,  0U,   0U,   0U,   81U,  117U, 97U,  108U, 105U, 102U, 105U, 101U,
      100U, 78U,  97U,  109U, 101U, 0U,   77U,  101U, 116U, 104U, 111U, 100U,
      115U, 0U,   0U,   0U,   0U,   0U,   0U,   0U,   80U,  114U, 111U, 112U,
      101U, 114U, 116U, 105U, 101U, 115U, 0U,   0U,   0U,   0U,   72U,  97U,
      110U, 100U, 108U, 101U, 0U,   0U,   0U,   0U,   0U,   0U,   0U,   0U};
  xEntryPoints =
      emlrtCreateStructMatrix(1, 2, 7, (const char_T **)&epFieldName[0]);
  xInputs = emlrtCreateLogicalMatrix(1, 5);
  emlrtSetField(xEntryPoints, 0, "QualifiedName",
                emlrtMxCreateString("adaptive_neuron_wrapper_fixpt"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(5.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(4.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 0, "ResolvedFilePath",
      emlrtMxCreateString("/MATLAB "
                          "Drive/Dat_Comp_Decomp/v2/codegen/adaptive_neuron/"
                          "fixpt/adaptive_neuron_wrapper_fixpt.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp",
                emlrtMxCreateDoubleScalar(740302.1528935186));
  emlrtSetField(xEntryPoints, 0, "Visible", emlrtMxCreateLogicalScalar(true));
  xInputs = emlrtCreateLogicalMatrix(1, 0);
  emlrtSetField(xEntryPoints, 1, "QualifiedName",
                emlrtMxCreateString("adaptive_neuron_fixpt_logger"));
  emlrtSetField(xEntryPoints, 1, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 1, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 1, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 1, "ResolvedFilePath",
      emlrtMxCreateString("/MATLAB "
                          "Drive/Dat_Comp_Decomp/v2/codegen/adaptive_neuron/"
                          "fixpt/fxptmp/adaptive_neuron_fixpt_logger.m"));
  emlrtSetField(xEntryPoints, 1, "TimeStamp",
                emlrtMxCreateDoubleScalar(740302.1658680555));
  emlrtSetField(xEntryPoints, 1, "Visible", emlrtMxCreateLogicalScalar(true));
  xResult =
      emlrtCreateStructMatrix(1, 1, 7, (const char_T **)&propFieldName[0]);
  emlrtSetField(xResult, 0, "Version",
                emlrtMxCreateString("26.2.0.3437455 (R2026b) Update 2"));
  emlrtSetField(xResult, 0, "ResolvedFunctions",
                (mxArray *)c_emlrtMexFcnResolvedFunctionsI());
  emlrtSetField(xResult, 0, "Checksum",
                emlrtMxCreateString("Hqn5VDSXBJlVU0d7j3Hhz"));
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  emlrtSetField(xResult, 0, "AuxData",
                emlrtMxCreateRowVectorUINT8((const uint8_T *)&v, 216U));
  return xResult;
}
