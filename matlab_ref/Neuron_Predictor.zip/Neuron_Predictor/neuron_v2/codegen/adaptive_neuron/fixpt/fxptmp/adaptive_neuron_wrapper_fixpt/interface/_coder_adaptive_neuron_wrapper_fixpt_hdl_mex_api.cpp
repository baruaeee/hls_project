#include "_coder_adaptive_neuron_wrapper_fixpt_hdl_mex_api.h"
#include "adaptive_neuron_fixpt_logger.h"
#include "adaptive_neuron_wrapper_fixpt.h"
#include "adaptive_neuron_wrapper_fixpt_hdl_mex_data.h"
#include "adaptive_neuron_wrapper_fixpt_hdl_mex_types.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

static real_T b_emlrt_marshallIn(const emlrtStack &sp, const mxArray *b_nullptr,
                                 const char_T *identifier);

static real_T b_emlrt_marshallIn(const emlrtStack &sp, const mxArray *u,
                                 const emlrtMsgIdentifier *parentId);

static real_T (*c_emlrt_marshallIn(const emlrtStack &sp, const mxArray *src,
                                   const emlrtMsgIdentifier *msgId))[4];

static real_T d_emlrt_marshallIn(const emlrtStack &sp, const mxArray *src,
                                 const emlrtMsgIdentifier *msgId);

static real_T (*emlrt_marshallIn(const emlrtStack &sp, const mxArray *b_nullptr,
                                 const char_T *identifier))[4];

static real_T (*emlrt_marshallIn(const emlrtStack &sp, const mxArray *u,
                                 const emlrtMsgIdentifier *parentId))[4];

static const mxArray *emlrt_marshallOut(const emlrtStack &sp,
                                        const struct0_T &u);

static const mxArray *emlrt_marshallOut(const coder::array<int16_T, 2U> &u);

static const mxArray *emlrt_marshallOut(real_T u[4]);

static const mxArray *emlrt_marshallOut(const real_T u);

static real_T b_emlrt_marshallIn(const emlrtStack &sp, const mxArray *b_nullptr,
                                 const char_T *identifier)
{
  emlrtMsgIdentifier thisId;
  real_T y;
  thisId.fIdentifier = const_cast<const char_T *>(identifier);
  thisId.fParent = nullptr;
  thisId.bParentIsCell = false;
  y = b_emlrt_marshallIn(sp, emlrtAlias(b_nullptr), &thisId);
  emlrtDestroyArray(&b_nullptr);
  return y;
}

static real_T b_emlrt_marshallIn(const emlrtStack &sp, const mxArray *u,
                                 const emlrtMsgIdentifier *parentId)
{
  real_T y;
  y = d_emlrt_marshallIn(sp, emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}

static real_T (*c_emlrt_marshallIn(const emlrtStack &sp, const mxArray *src,
                                   const emlrtMsgIdentifier *msgId))[4]
{
  static const int32_T dims{4};
  real_T(*ret)[4];
  int32_T i;
  boolean_T b{false};
  emlrtCheckVsBuiltInR2012b((emlrtConstCTX)&sp, msgId, src, "double", false, 1U,
                            (const void *)&dims, &b, &i);
  ret = (real_T(*)[4])emlrtMxGetData(src);
  emlrtDestroyArray(&src);
  return ret;
}

static real_T d_emlrt_marshallIn(const emlrtStack &sp, const mxArray *src,
                                 const emlrtMsgIdentifier *msgId)
{
  static const int32_T dims{0};
  real_T ret;
  emlrtCheckBuiltInR2012b((emlrtConstCTX)&sp, msgId, src, "double", false, 0U,
                          (const void *)&dims);
  ret = *static_cast<real_T *>(emlrtMxGetData(src));
  emlrtDestroyArray(&src);
  return ret;
}

static real_T (*emlrt_marshallIn(const emlrtStack &sp, const mxArray *b_nullptr,
                                 const char_T *identifier))[4]
{
  emlrtMsgIdentifier thisId;
  real_T(*y)[4];
  thisId.fIdentifier = const_cast<const char_T *>(identifier);
  thisId.fParent = nullptr;
  thisId.bParentIsCell = false;
  y = emlrt_marshallIn(sp, emlrtAlias(b_nullptr), &thisId);
  emlrtDestroyArray(&b_nullptr);
  return y;
}

static real_T (*emlrt_marshallIn(const emlrtStack &sp, const mxArray *u,
                                 const emlrtMsgIdentifier *parentId))[4]
{
  real_T(*y)[4];
  y = c_emlrt_marshallIn(sp, emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}

static const mxArray *emlrt_marshallOut(const emlrtStack &sp,
                                        const struct0_T &u)
{
  static const char_T *sv1[5]{"x_history", "w", "b", "current_val", "mu"};
  static const char_T *sv2[4]{"pred_y", "error_e", "w_next", "b_next"};
  static const char_T *sv[3]{"inputs", "outputs", "iterCount"};
  const mxArray *b_y;
  const mxArray *c_y;
  const mxArray *d_y;
  const mxArray *e_y;
  const mxArray *f_y;
  const mxArray *g_y;
  const mxArray *h_y;
  const mxArray *i_y;
  const mxArray *j_y;
  const mxArray *k_y;
  const mxArray *l_y;
  const mxArray *m;
  const mxArray *m_y;
  const mxArray *n_y;
  const mxArray *o_y;
  const mxArray *p_y;
  const mxArray *y;
  int32_T b_iv[2];
  int32_T i;
  int16_T *pData;
  uint16_T *b_pData;
  y = nullptr;
  emlrtAssign(&y, emlrtCreateStructMatrix(1, 1, 3, (const char_T **)&sv[0]));
  b_y = nullptr;
  emlrtAssign(&b_y, emlrtCreateStructMatrix(1, 1, 5, (const char_T **)&sv1[0]));
  c_y = nullptr;
  d_y = nullptr;
  m = emlrtCreateNumericArray(
      1, (const_cast<coder::array<int16_T, 1U> *>(&u.inputs.x_history))->size(),
      mxINT16_CLASS, mxREAL);
  pData = static_cast<int16_T *>(emlrtMxGetData(m));
  i = 0;
  for (int32_T b_i{0}; b_i < u.inputs.x_history.size(0); b_i++) {
    pData[i] = u.inputs.x_history[b_i];
    i++;
  }
  emlrtAssign(&d_y, m);
  emlrtAssign(&c_y, emlrtCreateFIR2013b((emlrtCTX)&sp, eml_mx, b_eml_mx,
                                        "simulinkarray", d_y, true, false));
  emlrtSetFieldR2017b(b_y, 0, "x_history", c_y, 0);
  e_y = nullptr;
  f_y = nullptr;
  m = emlrtCreateNumericArray(
      1, (const_cast<coder::array<int16_T, 1U> *>(&u.inputs.w))->size(),
      mxINT16_CLASS, mxREAL);
  pData = static_cast<int16_T *>(emlrtMxGetData(m));
  i = 0;
  for (int32_T b_i{0}; b_i < u.inputs.w.size(0); b_i++) {
    pData[i] = u.inputs.w[b_i];
    i++;
  }
  emlrtAssign(&f_y, m);
  emlrtAssign(&e_y, emlrtCreateFIR2013b((emlrtCTX)&sp, eml_mx, c_eml_mx,
                                        "simulinkarray", f_y, true, false));
  emlrtSetFieldR2017b(b_y, 0, "w", e_y, 1);
  g_y = nullptr;
  emlrtAssign(&g_y, emlrtCreateFIR2013b(
                        (emlrtCTX)&sp, eml_mx, d_eml_mx, "simulinkarray",
                        emlrt_marshallOut(u.inputs.b), true, false));
  emlrtSetFieldR2017b(b_y, 0, "b", g_y, 2);
  h_y = nullptr;
  emlrtAssign(&h_y, emlrtCreateFIR2013b(
                        (emlrtCTX)&sp, eml_mx, b_eml_mx, "simulinkarray",
                        emlrt_marshallOut(u.inputs.current_val), true, false));
  emlrtSetFieldR2017b(b_y, 0, "current_val", h_y, 3);
  i_y = nullptr;
  j_y = nullptr;
  b_iv[0] = 1;
  b_iv[1] = u.inputs.mu.size(1);
  m = emlrtCreateNumericArray(2, &b_iv[0], mxUINT16_CLASS, mxREAL);
  b_pData = static_cast<uint16_T *>(emlrtMxGetData(m));
  i = 0;
  for (int32_T b_i{0}; b_i < u.inputs.mu.size(1); b_i++) {
    b_pData[i] = u.inputs.mu[b_i];
    i++;
  }
  emlrtAssign(&j_y, m);
  emlrtAssign(&i_y, emlrtCreateFIR2013b((emlrtCTX)&sp, eml_mx, e_eml_mx,
                                        "simulinkarray", j_y, true, false));
  emlrtSetFieldR2017b(b_y, 0, "mu", i_y, 4);
  emlrtSetFieldR2017b(y, 0, "inputs", b_y, 0);
  k_y = nullptr;
  emlrtAssign(&k_y, emlrtCreateStructMatrix(1, 1, 4, (const char_T **)&sv2[0]));
  l_y = nullptr;
  emlrtAssign(&l_y, emlrtCreateFIR2013b(
                        (emlrtCTX)&sp, eml_mx, d_eml_mx, "simulinkarray",
                        emlrt_marshallOut(u.outputs.pred_y), true, false));
  emlrtSetFieldR2017b(k_y, 0, "pred_y", l_y, 0);
  m_y = nullptr;
  emlrtAssign(&m_y, emlrtCreateFIR2013b(
                        (emlrtCTX)&sp, eml_mx, d_eml_mx, "simulinkarray",
                        emlrt_marshallOut(u.outputs.error_e), true, false));
  emlrtSetFieldR2017b(k_y, 0, "error_e", m_y, 1);
  n_y = nullptr;
  o_y = nullptr;
  m = emlrtCreateNumericArray(
      1, (const_cast<coder::array<int16_T, 1U> *>(&u.outputs.w_next))->size(),
      mxINT16_CLASS, mxREAL);
  pData = static_cast<int16_T *>(emlrtMxGetData(m));
  i = 0;
  for (int32_T b_i{0}; b_i < u.outputs.w_next.size(0); b_i++) {
    pData[i] = u.outputs.w_next[b_i];
    i++;
  }
  emlrtAssign(&o_y, m);
  emlrtAssign(&n_y, emlrtCreateFIR2013b((emlrtCTX)&sp, eml_mx, c_eml_mx,
                                        "simulinkarray", o_y, true, false));
  emlrtSetFieldR2017b(k_y, 0, "w_next", n_y, 2);
  p_y = nullptr;
  emlrtAssign(&p_y, emlrtCreateFIR2013b(
                        (emlrtCTX)&sp, eml_mx, d_eml_mx, "simulinkarray",
                        emlrt_marshallOut(u.outputs.b_next), true, false));
  emlrtSetFieldR2017b(k_y, 0, "b_next", p_y, 3);
  emlrtSetFieldR2017b(y, 0, "outputs", k_y, 1);
  emlrtSetFieldR2017b(y, 0, "iterCount", emlrt_marshallOut(u.iterCount), 2);
  return y;
}

static const mxArray *emlrt_marshallOut(const coder::array<int16_T, 2U> &u)
{
  const mxArray *m;
  const mxArray *y;
  int32_T b_iv[2];
  int32_T i;
  int16_T *pData;
  y = nullptr;
  b_iv[0] = 1;
  b_iv[1] = u.size(1);
  m = emlrtCreateNumericArray(2, &b_iv[0], mxINT16_CLASS, mxREAL);
  pData = static_cast<int16_T *>(emlrtMxGetData(m));
  i = 0;
  for (int32_T b_i{0}; b_i < u.size(1); b_i++) {
    pData[i] = u[b_i];
    i++;
  }
  emlrtAssign(&y, m);
  return y;
}

static const mxArray *emlrt_marshallOut(real_T u[4])
{
  static const int32_T i{0};
  static const int32_T i1{4};
  const mxArray *m;
  const mxArray *y;
  void *existingData;
  y = nullptr;
  m = emlrtCreateNumericArray(1, (const void *)&i, mxDOUBLE_CLASS, mxREAL);
  existingData = emlrtMxGetData((mxArray *)m);
  if (existingData != (void *)&u[0]) {
    emlrtFreeMex(existingData);
  }
  emlrtMxSetData((mxArray *)m, &u[0]);
  emlrtSetDimensions((mxArray *)m, &i1, 1);
  emlrtAssign(&y, m);
  return y;
}

static const mxArray *emlrt_marshallOut(const real_T u)
{
  const mxArray *m;
  const mxArray *y;
  y = nullptr;
  m = emlrtCreateDoubleScalar(u);
  emlrtAssign(&y, m);
  return y;
}

void d_adaptive_neuron_fixpt_logger_(const mxArray **plhs)
{
  emlrtStack st{nullptr, nullptr, nullptr};
  struct0_T loggedData;
  st.tls = emlrtRootTLSGlobal;
  emlrtHeapReferenceStackEnterFcnR2012b(&st);

  coder::adaptive_neuron_fixpt_logger(&st, &loggedData);

  *plhs = emlrt_marshallOut(st, loggedData);
  emlrtHeapReferenceStackLeaveFcnR2012b(&st);
}

void d_adaptive_neuron_wrapper_fixpt(const mxArray *const prhs[5], int32_T nlhs,
                                     const mxArray *plhs[4])
{
  emlrtStack st{nullptr, nullptr, nullptr};
  real_T(*w)[4];
  real_T(*w_next)[4];
  real_T(*x_history)[4];
  real_T b;
  real_T b_next;
  real_T current_val;
  real_T error_e;
  real_T mu;
  real_T pred_y;
  st.tls = emlrtRootTLSGlobal;
  w_next = (real_T(*)[4])mxMalloc(sizeof(real_T[4]));

  x_history = emlrt_marshallIn(st, emlrtAlias(prhs[0]), "x_history");
  w = emlrt_marshallIn(st, emlrtAlias(prhs[1]), "w");
  b = b_emlrt_marshallIn(st, emlrtAliasP(prhs[2]), "b");
  current_val = b_emlrt_marshallIn(st, emlrtAliasP(prhs[3]), "current_val");
  mu = b_emlrt_marshallIn(st, emlrtAliasP(prhs[4]), "mu");

  adaptive_neuron_wrapper_fixpt(&st, *x_history, *w, b, current_val, mu,
                                &pred_y, &error_e, *w_next, &b_next);

  plhs[0] = emlrt_marshallOut(pred_y);
  if (nlhs > 1) {
    plhs[1] = emlrt_marshallOut(error_e);
  }
  if (nlhs > 2) {
    plhs[2] = emlrt_marshallOut(*w_next);
  }
  if (nlhs > 3) {
    plhs[3] = emlrt_marshallOut(b_next);
  }
}
