#include "adaptive_neuron_wrapper_fixpt_hdl_mex_data.h"
#include "rt_nonfinite.h"

emlrtCTX emlrtRootTLSGlobal{nullptr};

const mxArray *eml_mx{nullptr};

const mxArray *b_eml_mx{nullptr};

const mxArray *c_eml_mx{nullptr};

const mxArray *d_eml_mx{nullptr};

const mxArray *e_eml_mx{nullptr};

emlrtContext emlrtContextGlobal{
    true,
    false,
    131691U,
    nullptr,
    "adaptive_neuron_wrapper_fixpt_hdl_mex",
    nullptr,
    false,
    {1511293120U, 2570482084U, 1335128479U, 330037357U},
    nullptr};

emlrtRSInfo v_emlrtRSI{
    13, "nullAssignment",
    "/MATLAB/toolbox/eml/eml/+coder/+internal/nullAssignment.m"};

emlrtRSInfo w_emlrtRSI{
    17, "nullAssignment",
    "/MATLAB/toolbox/eml/eml/+coder/+internal/nullAssignment.m"};

emlrtRSInfo x_emlrtRSI{
    168, "onearg_null_assignment",
    "/MATLAB/toolbox/eml/eml/+coder/+internal/nullAssignment.m"};

emlrtRSInfo y_emlrtRSI{
    170, "onearg_null_assignment",
    "/MATLAB/toolbox/eml/eml/+coder/+internal/nullAssignment.m"};

emlrtRSInfo ab_emlrtRSI{
    173, "onearg_null_assignment",
    "/MATLAB/toolbox/eml/eml/+coder/+internal/nullAssignment.m"};

emlrtRSInfo bb_emlrtRSI{
    266, "make_bitarray",
    "/MATLAB/toolbox/eml/eml/+coder/+internal/nullAssignment.m"};

emlrtRSInfo cb_emlrtRSI{
    21, "eml_int_forloop_overflow_check",
    "/MATLAB/toolbox/eml/lib/matlab/eml/eml_int_forloop_overflow_check.m"};

emlrtRSInfo db_emlrtRSI{
    133, "num_true",
    "/MATLAB/toolbox/eml/eml/+coder/+internal/nullAssignment.m"};

emlrtRTEInfo c_emlrtRTEI{
    86, 27, "validate_inputs",
    "/MATLAB/toolbox/eml/eml/+coder/+internal/nullAssignment.m"};

emlrtRTEInfo d_emlrtRTEI{
    182, 9, "onearg_null_assignment",
    "/MATLAB/toolbox/eml/eml/+coder/+internal/nullAssignment.m"};

emlrtRTEInfo e_emlrtRTEI{
    11, 1, "eml_int_forloop_overflow_error",
    "/MATLAB/toolbox/eml/lib/matlab/eml/eml_int_forloop_overflow_error.m"};

emlrtRTEInfo i_emlrtRTEI{
    189, 9, "onearg_null_assignment",
    "/MATLAB/toolbox/eml/eml/+coder/+internal/nullAssignment.m"};
