#include "adaptive_neuron_wrapper_fixpt.h"
#include "adaptive_neuron_fixpt_logger.h"
#include "rt_nonfinite.h"
#include "mwmathutil.h"

static emlrtRSInfo emlrtRSI{13, "adaptive_neuron_wrapper_fixpt",
                            "/MATLAB "
                            "Drive/Dat_Comp_Decomp/v2/codegen/adaptive_neuron/"
                            "fixpt/adaptive_neuron_wrapper_fixpt.m"};

static emlrtRSInfo b_emlrtRSI{5, "adaptive_neuron_fixpt_input_output_logger",
                              "src/LogInputsAndOutputs.cpp:55"};

void adaptive_neuron_wrapper_fixpt(const emlrtStack *sp,
                                   const real_T x_history[4], const real_T w[4],
                                   real_T b, real_T current_val, real_T mu,
                                   real_T *pred_y, real_T *error_e,
                                   real_T w_next[4], real_T *b_next)
{
  emlrtStack b_st;
  emlrtStack st;
  real_T d;
  uint64_T var1;
  int32_T i;
  int16_T w_in[4];
  int16_T w_next_out[4];
  int16_T x_history_in[4];
  int16_T a;
  int16_T b_b;
  int16_T b_current_val;
  int16_T b_next_out;
  int16_T error_e_out;
  int16_T pred_y_out;
  uint16_T b_mu;
  uint16_T c_b;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  d = muDoubleScalarFloor(x_history[0] * 8192.0);
  if (muDoubleScalarIsNaN(d) || muDoubleScalarIsInf(d)) {
    d = 0.0;
  } else {
    d = muDoubleScalarRem(d, 16384.0);
  }
  if (static_cast<uint16_T>(static_cast<uint16_T>(static_cast<int16_T>(d)) &
                            8192) != 0) {
    x_history_in[0] = static_cast<int16_T>(static_cast<int16_T>(d) | -8192);
  } else {
    x_history_in[0] = static_cast<int16_T>(
        static_cast<uint16_T>(static_cast<int16_T>(d)) & 8191);
  }
  d = muDoubleScalarFloor(w[0] * 256.0);
  if (muDoubleScalarIsNaN(d) || muDoubleScalarIsInf(d)) {
    d = 0.0;
  } else {
    d = muDoubleScalarRem(d, 16384.0);
  }
  if (static_cast<uint16_T>(static_cast<uint16_T>(static_cast<int16_T>(d)) &
                            8192) != 0) {
    w_in[0] = static_cast<int16_T>(static_cast<int16_T>(d) | -8192);
  } else {
    w_in[0] = static_cast<int16_T>(
        static_cast<uint16_T>(static_cast<int16_T>(d)) & 8191);
  }
  d = muDoubleScalarFloor(x_history[1] * 8192.0);
  if (muDoubleScalarIsNaN(d) || muDoubleScalarIsInf(d)) {
    d = 0.0;
  } else {
    d = muDoubleScalarRem(d, 16384.0);
  }
  if (static_cast<uint16_T>(static_cast<uint16_T>(static_cast<int16_T>(d)) &
                            8192) != 0) {
    x_history_in[1] = static_cast<int16_T>(static_cast<int16_T>(d) | -8192);
  } else {
    x_history_in[1] = static_cast<int16_T>(
        static_cast<uint16_T>(static_cast<int16_T>(d)) & 8191);
  }
  d = muDoubleScalarFloor(w[1] * 256.0);
  if (muDoubleScalarIsNaN(d) || muDoubleScalarIsInf(d)) {
    d = 0.0;
  } else {
    d = muDoubleScalarRem(d, 16384.0);
  }
  if (static_cast<uint16_T>(static_cast<uint16_T>(static_cast<int16_T>(d)) &
                            8192) != 0) {
    w_in[1] = static_cast<int16_T>(static_cast<int16_T>(d) | -8192);
  } else {
    w_in[1] = static_cast<int16_T>(
        static_cast<uint16_T>(static_cast<int16_T>(d)) & 8191);
  }
  d = muDoubleScalarFloor(x_history[2] * 8192.0);
  if (muDoubleScalarIsNaN(d) || muDoubleScalarIsInf(d)) {
    d = 0.0;
  } else {
    d = muDoubleScalarRem(d, 16384.0);
  }
  if (static_cast<uint16_T>(static_cast<uint16_T>(static_cast<int16_T>(d)) &
                            8192) != 0) {
    x_history_in[2] = static_cast<int16_T>(static_cast<int16_T>(d) | -8192);
  } else {
    x_history_in[2] = static_cast<int16_T>(
        static_cast<uint16_T>(static_cast<int16_T>(d)) & 8191);
  }
  d = muDoubleScalarFloor(w[2] * 256.0);
  if (muDoubleScalarIsNaN(d) || muDoubleScalarIsInf(d)) {
    d = 0.0;
  } else {
    d = muDoubleScalarRem(d, 16384.0);
  }
  if (static_cast<uint16_T>(static_cast<uint16_T>(static_cast<int16_T>(d)) &
                            8192) != 0) {
    w_in[2] = static_cast<int16_T>(static_cast<int16_T>(d) | -8192);
  } else {
    w_in[2] = static_cast<int16_T>(
        static_cast<uint16_T>(static_cast<int16_T>(d)) & 8191);
  }
  d = muDoubleScalarFloor(x_history[3] * 8192.0);
  if (muDoubleScalarIsNaN(d) || muDoubleScalarIsInf(d)) {
    d = 0.0;
  } else {
    d = muDoubleScalarRem(d, 16384.0);
  }
  if (static_cast<uint16_T>(static_cast<uint16_T>(static_cast<int16_T>(d)) &
                            8192) != 0) {
    x_history_in[3] = static_cast<int16_T>(static_cast<int16_T>(d) | -8192);
  } else {
    x_history_in[3] = static_cast<int16_T>(
        static_cast<uint16_T>(static_cast<int16_T>(d)) & 8191);
  }
  d = muDoubleScalarFloor(w[3] * 256.0);
  if (muDoubleScalarIsNaN(d) || muDoubleScalarIsInf(d)) {
    d = 0.0;
  } else {
    d = muDoubleScalarRem(d, 16384.0);
  }
  if (static_cast<uint16_T>(static_cast<uint16_T>(static_cast<int16_T>(d)) &
                            8192) != 0) {
    w_in[3] = static_cast<int16_T>(static_cast<int16_T>(d) | -8192);
  } else {
    w_in[3] = static_cast<int16_T>(
        static_cast<uint16_T>(static_cast<int16_T>(d)) & 8191);
  }
  d = muDoubleScalarFloor(b * 512.0);
  if (muDoubleScalarIsNaN(d) || muDoubleScalarIsInf(d)) {
    d = 0.0;
  } else {
    d = muDoubleScalarRem(d, 16384.0);
  }
  if (static_cast<uint16_T>(static_cast<uint16_T>(static_cast<int16_T>(d)) &
                            8192) != 0) {
    b_b = static_cast<int16_T>(static_cast<int16_T>(d) | -8192);
  } else {
    b_b = static_cast<int16_T>(static_cast<uint16_T>(static_cast<int16_T>(d)) &
                               8191);
  }
  d = muDoubleScalarFloor(current_val * 8192.0);
  if (muDoubleScalarIsNaN(d) || muDoubleScalarIsInf(d)) {
    d = 0.0;
  } else {
    d = muDoubleScalarRem(d, 16384.0);
  }
  if (static_cast<uint16_T>(static_cast<uint16_T>(static_cast<int16_T>(d)) &
                            8192) != 0) {
    b_current_val = static_cast<int16_T>(static_cast<int16_T>(d) | -8192);
  } else {
    b_current_val = static_cast<int16_T>(
        static_cast<uint16_T>(static_cast<int16_T>(d)) & 8191);
  }
  d = muDoubleScalarFloor(mu * 16384.0);
  if (muDoubleScalarIsNaN(d) || muDoubleScalarIsInf(d)) {
    d = 0.0;
  } else {
    d = muDoubleScalarRem(d, 16384.0);
  }
  b_mu = static_cast<uint16_T>(static_cast<uint16_T>(static_cast<int16_T>(d)) &
                               16383);
  st.site = &emlrtRSI;
  b_next_out =
      static_cast<int16_T>(((b_b << 12) + x_history_in[0] * w_in[0]) >> 12);
  if (static_cast<uint16_T>(static_cast<uint16_T>(b_next_out) & 8192) != 0) {
    i = b_next_out | -8192;
  } else {
    i = static_cast<uint16_T>(static_cast<uint16_T>(b_next_out) & 8191);
  }
  b_next_out =
      static_cast<int16_T>(((i << 12) + x_history_in[1] * w_in[1]) >> 12);
  if (static_cast<uint16_T>(static_cast<uint16_T>(b_next_out) & 8192) != 0) {
    i = b_next_out | -8192;
  } else {
    i = static_cast<uint16_T>(static_cast<uint16_T>(b_next_out) & 8191);
  }
  b_next_out =
      static_cast<int16_T>(((i << 12) + x_history_in[2] * w_in[2]) >> 12);
  if (static_cast<uint16_T>(static_cast<uint16_T>(b_next_out) & 8192) != 0) {
    i = b_next_out | -8192;
  } else {
    i = static_cast<uint16_T>(static_cast<uint16_T>(b_next_out) & 8191);
  }
  b_next_out =
      static_cast<int16_T>(((i << 12) + x_history_in[3] * w_in[3]) >> 12);
  if (static_cast<uint16_T>(static_cast<uint16_T>(b_next_out) & 8192) != 0) {
    pred_y_out = static_cast<int16_T>(b_next_out | -8192);
  } else {
    pred_y_out = static_cast<int16_T>(static_cast<uint16_T>(b_next_out) & 8191);
  }
  b_next_out = static_cast<int16_T>((b_current_val - (pred_y_out << 4)) >> 4);
  if (static_cast<uint16_T>(static_cast<uint16_T>(b_next_out) & 8192) != 0) {
    error_e_out = static_cast<int16_T>(b_next_out | -8192);
  } else {
    error_e_out =
        static_cast<int16_T>(static_cast<uint16_T>(b_next_out) & 8191);
  }
  c_b = static_cast<uint16_T>(
      static_cast<uint32_T>(
          ((static_cast<int64_T>(((x_history_in[0] * x_history_in[0] +
                                   x_history_in[1] * x_history_in[1]) +
                                  x_history_in[2] * x_history_in[2]) +
                                 x_history_in[3] * x_history_in[3])
            << 7) +
           8589L) >>
          21) &
      16383U);
  if (c_b == 0) {
    var1 = 274877906943UL;
  } else {
    var1 = (static_cast<uint64_T>(b_mu) << 22) / c_b;
  }
  b_next_out = static_cast<int16_T>(
      (error_e_out * static_cast<int32_T>(var1 >> 29)) >> 4);
  if (static_cast<uint16_T>(static_cast<uint16_T>(b_next_out) & 8192) != 0) {
    a = static_cast<int16_T>(b_next_out | -8192);
  } else {
    a = static_cast<int16_T>(static_cast<uint16_T>(b_next_out) & 8191);
  }
  b_next_out =
      static_cast<int16_T>(((w_in[0] << 5) + a * x_history_in[0]) >> 5);
  if (static_cast<uint16_T>(static_cast<uint16_T>(b_next_out) & 8192) != 0) {
    w_next_out[0] = static_cast<int16_T>(b_next_out | -8192);
  } else {
    w_next_out[0] =
        static_cast<int16_T>(static_cast<uint16_T>(b_next_out) & 8191);
  }
  b_next_out =
      static_cast<int16_T>(((w_in[1] << 5) + a * x_history_in[1]) >> 5);
  if (static_cast<uint16_T>(static_cast<uint16_T>(b_next_out) & 8192) != 0) {
    w_next_out[1] = static_cast<int16_T>(b_next_out | -8192);
  } else {
    w_next_out[1] =
        static_cast<int16_T>(static_cast<uint16_T>(b_next_out) & 8191);
  }
  b_next_out =
      static_cast<int16_T>(((w_in[2] << 5) + a * x_history_in[2]) >> 5);
  if (static_cast<uint16_T>(static_cast<uint16_T>(b_next_out) & 8192) != 0) {
    w_next_out[2] = static_cast<int16_T>(b_next_out | -8192);
  } else {
    w_next_out[2] =
        static_cast<int16_T>(static_cast<uint16_T>(b_next_out) & 8191);
  }
  b_next_out =
      static_cast<int16_T>(((w_in[3] << 5) + a * x_history_in[3]) >> 5);
  if (static_cast<uint16_T>(static_cast<uint16_T>(b_next_out) & 8192) != 0) {
    w_next_out[3] = static_cast<int16_T>(b_next_out | -8192);
  } else {
    w_next_out[3] =
        static_cast<int16_T>(static_cast<uint16_T>(b_next_out) & 8191);
  }
  b_next_out = static_cast<int16_T>(((b_b << 14) + b_mu * error_e_out) >> 14);
  if (static_cast<uint16_T>(static_cast<uint16_T>(b_next_out) & 8192) != 0) {
    b_next_out = static_cast<int16_T>(b_next_out | -8192);
  } else {
    b_next_out = static_cast<int16_T>(static_cast<uint16_T>(b_next_out) & 8191);
  }
  b_st.site = &b_emlrtRSI;
  coder::b_adaptive_neuron_fixpt_logger(b_st, x_history_in, w_in, b_b,
                                        b_current_val, b_mu, pred_y_out,
                                        error_e_out, w_next_out, b_next_out);
  *pred_y = static_cast<real_T>(pred_y_out) * 0.001953125;
  *error_e = static_cast<real_T>(error_e_out) * 0.001953125;
  w_next[0] = static_cast<real_T>(w_next_out[0]) * 0.00390625;
  w_next[1] = static_cast<real_T>(w_next_out[1]) * 0.00390625;
  w_next[2] = static_cast<real_T>(w_next_out[2]) * 0.00390625;
  w_next[3] = static_cast<real_T>(w_next_out[3]) * 0.00390625;
  *b_next = static_cast<real_T>(b_next_out) * 0.001953125;
}
