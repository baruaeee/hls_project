% neuron_tb.m
% Testbench for the predictive coding neuron using stimulus_data.txt

clear; clc;

% 1. Load the stimulus data generated from Step 1
filename = 'stimulus_data.txt';
if ~exist(filename, 'file')
    error('Stimulus file %s not found. Please run generate_stimulus.m first.', filename);
end

raw_signal = importdata(filename);
num_samples = numel(raw_signal);

% 2. Define filter weights (w) and bias (b)
% Order corresponds to past samples: [x[n-1], x[n-2], x[n-3], x[n-4]]
w = [0.5, 0.3, 0.1, 0.05]; 
b = 0;
order = numel(w);

% Preallocate arrays for results
predictions = zeros(num_samples, 1);
residuals = zeros(num_samples, 1);

% 3. Stream processing simulation loop
% We need a delay line buffer to store past samples
delay_line = zeros(1, order);

disp('[INFO] Running streaming neuron prediction test...');

for n = 1:num_samples
    current_sample = raw_signal(n);

    % If we have enough history, compute the prediction
    if n > order
        % x contains past samples [x[n-1], x[n-2], ..., x[n-order]]
        predicted_val = neuron(delay_line, w, b);
        predictions(n) = predicted_val;

        % Compute residual error: actual - predicted
        residuals(n) = current_sample - round(predicted_val);
    else
        predictions(n) = 0;
        residuals(n) = current_sample; % Startup transient
    end

    % Update the delay line for the next cycle (shift right, insert current)
    delay_line = [current_sample, delay_line(1:end-1)];
end

disp('[INFO] Simulation completed successfully.');

% 4. Plot the results to verify predictive performance
figure;
subplot(2,1,1);
plot(raw_signal, 'k', 'LineWidth', 1.2); hold on;
plot(predictions, 'r--', 'LineWidth', 1.5);
legend('Actual Signal (Stimulus)', 'Neuron Prediction');
title('Predictive Coding Neuron Performance');
xlabel('Sample Index [n]');
ylabel('Amplitude');
grid on;

subplot(2,1,2);
plot(residuals, 'b', 'LineWidth', 1);
title('Residual Errors (To be fed into Golomb-Rice Compressor)');
xlabel('Sample Index [n]');
ylabel('Error Amplitude');
grid on;

% Notice how the residual errors have a much smaller variance/amplitude 
% compared to the original signal—this is why compression works so well here!