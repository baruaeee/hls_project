% neuron_tb.m (Adaptive LMS Version)
clear; clc;

% 1. Load the stimulus data
filename = 'stimulus_data.txt';
if ~exist(filename, 'file')
    error('Stimulus file %s not found. Please run generate_stimulus.m first.', filename);
end

raw_signal = importdata(filename);
num_samples = numel(raw_signal);

% 2. Initialize weights and bias (can start near zero or small random values)
order = 4;
w = zeros(1, order); 
b = 0;

% LMS Adaptation Step Size (mu)
% Note: In hardware, mu is usually chosen as a power of 2 (e.g., 2^-12) 
% so multiplications become simple bit-shifts!
mu = 5e-8; 

% Preallocate arrays
predictions = zeros(num_samples, 1);
residuals = zeros(num_samples, 1);
delay_line = zeros(1, order);

disp('[INFO] Running Adaptive Streaming Neuron (LMS) simulation...');

% 3. Streaming simulation with on-the-fly weight adaptation
for n = 1:num_samples
    current_sample = raw_signal(n);

    if n > order
        % Predict current sample using current weights and delay line
        predicted_val = sum(delay_line .* w) + b;
        predictions(n) = predicted_val;

        % Compute residual error
        e = current_sample - predicted_val;
        residuals(n) = e;

        % LMS Weight & Bias Adaptation
        % w_new = w_old + (mu * error * inputs)
        w = w + mu * e * delay_line;
        b = b + mu * e;
    else
        predictions(n) = 0;
        residuals(n) = current_sample;
    end

    % Update the hardware-style delay line buffer
    delay_line = [current_sample, delay_line(1:end-1)];
end

disp('[INFO] Simulation completed. Weights successfully adapted.');
disp('Final adapted weights:');
disp(w);

% 4. Plot results to visualize the drastic improvement
figure;
subplot(2,1,1);
plot(raw_signal, 'k', 'LineWidth', 1.2); hold on;
plot(predictions, 'r--', 'LineWidth', 1.5);
legend('Actual Signal (Stimulus)', 'Adaptive Neuron Prediction');
title('Adaptive Predictive Coding Neuron Performance');
xlabel('Sample Index [n]');
ylabel('Amplitude');
grid on;

subplot(2,1,2);
plot(residuals, 'b', 'LineWidth', 1);
title('Adapted Residual Errors (Tightly clustered around zero!)');
xlabel('Sample Index [n]');
ylabel('Error Amplitude');
grid on;