function y = neuron(x, w, b)
    % NEURON Predictive coding core
    %   x: vector of past input samples [x[n-1], x[n-2], ...]
    %   w: filter weights corresponding to past samples
    %   b: bias term

    % HDL Coder pragmas / literal text for HLS translation hints
    coder.hdl.literaltext("#pragma HLS ARRAY_PARTITION variable=x complete dim=1");
    coder.hdl.literaltext("#pragma HLS ARRAY_PARTITION variable=w complete dim=1");
    coder.hdl.literaltext("#pragma HLS BIND_OP variable=y op=add impl=fabric");

    y = b;

    % Unroll the loop for hardware pipelining & parallel MAC operations
    coder.hdl.loopspec('unroll');
    for i = 1:numel(x)
        y = y + (x(i) * w(i));
    end
end